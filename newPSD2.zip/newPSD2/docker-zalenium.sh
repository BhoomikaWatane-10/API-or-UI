#!/bin/bash

#NOTICE: latest version is at:
# https://bitbucket.luminorgroup.com/projects/LUMTA/repos/project-template/browse/docker-zalenium.sh

# PRECONDITION: test your docker app installation - $ docker info

# stop all docker containers
echo "*** stopping all docker containers ***"
docker rm $(docker kill $(docker ps -aq) &> /dev/null) &> /dev/null

# *** install docker image if needed
# https://opensource.zalando.com/zalenium/
echo "*** checking if Zalenium images exist ***"
IMAGE_ELGALU="elgalu/selenium"
if [[ "$(docker images -q $IMAGE_ELGALU:latest 2> /dev/null)" == "" ]]; then
    echo "Downloading image: $IMAGE_ELGALU"
    docker pull $IMAGE_ELGALU
fi
IMAGE_DOSEL="dosel/zalenium"
if [[ "$(docker images -q $IMAGE_DOSEL:latest 2> /dev/null)" == "" ]]; then
    echo "Downloading image: $IMAGE_DOSEL"
    docker pull $IMAGE_DOSEL
fi

# run docker container - Zalenium
echo "*** starting Zalenium if needed***"
docker run -d --rm --name zalenium -p 4444:4444 \
      -v /var/run/docker.sock:/var/run/docker.sock \
      -v /tmp/videos:/home/seluser/videos \
      --privileged dosel/zalenium start