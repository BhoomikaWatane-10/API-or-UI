package com.luminor.tests.regression;

import static org.assertj.core.api.Assertions.assertThat;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.Accounts;
import com.luminor.api.endpoints.Consent;
import com.luminor.api.endpoints.Payments;
import com.luminor.api.enums.Error;
import com.luminor.api.enums.Token;
import com.luminor.taf.Taf;
import com.luminor.utils.DateHelper;
import com.luminor.utils.enums.AuthTypes;
import io.restassured.RestAssured;
import io.restassured.specification.FilterableRequestSpecification;
import java.util.Map;
import org.apache.http.HttpStatus;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ValidateAuthErrorsTest extends BasePsd2Test {

  @DataProvider
  public Object[][] aspspData() {
    return Taf.utils().excel().loadRandomSingleRow(testDataFile(), "validateAuthErrors");
  }

  @Test(dataProvider = "aspspData", description = "Consent/Access token errors should be validated")
  public void validateConsentAccessTokenErrors(Map<String, String> dp) {
    FilterableRequestSpecification psd2Spec = psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    String accessToken = psd2Spec.getHeaders().getValue("Authorization");
    String consentId = Consent.createConsentCheckErrorsSign(dp).getConsentId();

    log.info("Attempt to get account info with consent which belongs to another user");
    psd2Spec.header("Consent-ID", CONSENT_RANDOM);
    Taf.api().rest().setSpecification(psd2Spec);
    assertThat(Accounts.checkAccountsUnavailable(HttpStatus.SC_UNAUTHORIZED).getText())
        .as("Error should be returned: '" + Error.SERVICE_BLOCKED.getValue() + "'")
        .contains(Error.SERVICE_BLOCKED.getValue());

    log.info("Attempt to get account info with consent which is not valid UUID");
    psd2Spec.replaceHeader("Consent-ID", Taf.utils().numbers().getRandomNumberWithNDigits(10));
    Taf.api().rest().setSpecification(psd2Spec);
    assertThat(Accounts.checkAccountsUnavailable(HttpStatus.SC_BAD_REQUEST).getText())
        .as("Error should be returned: '" + Error.CONSENT_INVALID_UUID.getValue() + "'")
        .contains(Error.CONSENT_INVALID_UUID.getValue());

    log.info("Setting up valid consent ID");
    psd2Spec.replaceHeader("Consent-ID", consentId);
    Taf.api().rest().setSpecification(psd2Spec);

    log.info("Attempt create payment using incorrect request format");
    assertThat(
        Payments.checkPaymentCreationUnavailable("", HttpStatus.SC_BAD_REQUEST).getText())
        .as("Error should be returned: '" + Error.FORMAT_ERROR.getValue() + "'")
        .contains(Error.FORMAT_ERROR.getValue());

    log.info("Attempt to get account info with expired token");
    psd2Spec.replaceHeader("Authorization", Token.TOKEN_EXPIRED.getValue());
    Taf.api().rest().setSpecification(psd2Spec);
    assertThat(Accounts.checkAccountsUnavailable(HttpStatus.SC_UNAUTHORIZED).getText())
        .as("Error should be returned: '" + Error.TOKEN_EXPIRED.getValue() + "'")
        .contains(Error.TOKEN_EXPIRED.getValue());

    log.info("Attempt to get account info with invalid (not parsable) token");
    psd2Spec.replaceHeader("Authorization", Token.TOKEN_INVALID.getValue());
    Taf.api().rest().setSpecification(psd2Spec);
    assertThat(Accounts.checkAccountsUnavailable(HttpStatus.SC_UNAUTHORIZED).getText())
        .as("Error should be returned: '" + Error.TOKEN_INVALID.getValue() + "'")
        .contains(Error.TOKEN_INVALID.getValue());

    psd2Spec.replaceHeader("Authorization", accessToken);
    Taf.api().rest().setSpecification(psd2Spec);
    Accounts.getAccountInfo(dp.get("debtorAccount"));
  }

  @Test(dataProvider = "aspspData", description = "Transaction list errors should be validated")
  public void validateTransactionListErrors(Map<String, String> dp) {
    FilterableRequestSpecification psd2Spec = psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent.createAndSignConsent(dp);
    String resourceId = Accounts.getAccountInfo(dp.get("debtorAccount")).getResourceId();

    assertThat(Accounts
        .checkTransactionListUnavailable("2020-01-01",
            DateHelper.getFutureDate(0, "yyyy-MM-dd"),
            resourceId, "booked", 400)
        .getText())
        .as("Error should be returned: '" + Error.TRANSACTIONS_PERIOD_INVALID.getValue() + "'")
        .contains(Error.TRANSACTIONS_PERIOD_INVALID.getValue());

    RestAssured.reset();
    Taf.api().rest().setSpecification(psd2Spec);
    assertThat(Accounts
        .checkTransactionListUnavailable(
            DateHelper.getFutureDate(0, "yyyy-MM-dd"),
            DateHelper.getFutureDate(0, "yyyy-MM-dd"),
            resourceId, "bookeda", 400)
        .getText())
        .as("Error should be returned: '"
            + Error.TRANSACTIONS_PARAMETER_NOT_SUPPORTED.getValue()
            + "'")
        .contains(Error.TRANSACTIONS_PARAMETER_NOT_SUPPORTED.getValue());
  }
}