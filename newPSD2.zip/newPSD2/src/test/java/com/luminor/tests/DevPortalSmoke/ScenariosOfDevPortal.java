package com.luminor.tests.DevPortalSmoke;

import com.codeborne.selenide.Selenide;
import com.luminor.BasePsd2Test;
import com.luminor.DevportalUi.DevportalLogin;
import com.luminor.pageobjectsDevportal.*;
import com.luminor.taf.Taf;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Map;

public class ScenariosOfDevPortal extends BasePsd2Test {


    DevPortalLoginPage d = new DevPortalLoginPage();
    DevPortalWelComePage w = new DevPortalWelComePage();
    DevPortalAPIExplorerPage APIExplorer = new DevPortalAPIExplorerPage();
    DevPortalAPIExplorerConsentPage consent = new DevPortalAPIExplorerConsentPage();
    DevPortalAPIExplorerPaymentPage payment = new DevPortalAPIExplorerPaymentPage();
    DownloadSpecificationsPage downloadSpecifications = new DownloadSpecificationsPage();

    @DataProvider
    public Object[][] aspspData() {
        return Taf.utils().excel().loadAllRows(testDataFile(), "DevPortalTestData");
    }
/*
    @Test(priority = 0,dataProvider = "aspspData",description = "Login Page")
    public void loginScenario(Map<String,String> dp){

        devportalloginurl();
        d.setLoginDetails();
        d.closeWindow();
        // DevportalLogin.devportalLogin();
    }

    @Test(priority = 1,dataProvider = "aspspData",description = "Welcome Page")
    public void welcomeScenario(Map<String,String> dp) throws InterruptedException {

        devportalloginurl();
        d.setLoginDetails();
        w.verifyWelcomePage();
       d.closeWindow();
        // DevportalLogin.devportalLogin();
    }
    @Test(priority = 2,dataProvider = "aspspData",description = "TPP Registration Page")
    public void DP_05_newTPPRegistation_Funationality(Map<String,String> dp) throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        APIExplorer.newTPPRegistation();
        d.closeWindow();
    }

    @Test(priority = 3,dataProvider = "aspspData", description = "Login Page")
    public void DP_05_userLogin_Functionality(Map<String,String> dp) throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        APIExplorer.userLoginPage();
       d.closeWindow();
    }

    @Test(priority = 4,dataProvider = "aspspData", description = "List of available accounts Page")
    public void DP_09_getListOfAvailableAccounts_Functionality(Map<String, String> map) throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        APIExplorer.getListOfAvailableAccounts();
       d.closeWindow();
    }
*/
    @Test(priority = 5,dataProvider = "aspspData", description = "Create Consent")
    public void DP_10_createConsentedAuthorizedGetAccountInformationTppRedirectFalse_Functionality(
            Map<String, String> map) throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        consent.createConsentViaAPI();
        consent.getConsentDetails();
        consent.geConsentStatus();

        consent.initiateconsentAuthorization();
        consent.getconsentAuthorization();
        consent.getconsentAuthorizationDetails();
        consent.updateConsentAuthorizationDetails();
        consent.getConsentAuthorizationStatus();

        consent.AcoountInformation();
        d.closeWindow();
    }

    @Test(priority = 6,dataProvider = "aspspData", description = "Create Consent via UI")
    public void DP_11_fundsAvailableOnAccountConfirmation_Functionality(Map<String, String> map) throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        consent.createConsentViaAPI();
        consent.getConsentDetails();
        consent.geConsentStatus();

        consent.initiateconsentAuthorization();
        consent.getconsentAuthorization();
        consent.getconsentAuthorizationDetails();
        consent.updateConsentAuthorizationDetails();
        consent.getConsentAuthorizationStatus();

        consent.confirmFundsAvailabilityOnAccount();
        d.closeWindow();
    }

    @Test(priority = 7,dataProvider = "aspspData", description = "Create and Authorize payment")
    public void DP_12_PaymentInitiationAndAuthorization_TppRedirectTrue_functionality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        payment.initatePayment();
        payment.getPaymentStatus();
        //*payment.getPaymentFee();
        payment.getinitiatePaymentAuthorization();
        payment.getPaymentAuthorization();
        payment.getPaymentAuthorizationDetail();
        payment.updatePaymentAuthorizationDetail();
        payment.getPaymentAuthorizationStatus();
       d.closeWindow();
    }
    @Test(priority = 8,dataProvider = "aspspData", description = "Create and Authorize payment via API")
    public void DP_13_PaymentIntiationAndAuthorization_TppRedirectFalse_functionality(Map<String, String> map)
            throws Exception {

        devportalloginurl();
        d.setLoginDetails();
        payment.initatePaymentAPI();
        // payment.getPaymentStatus();
        // payment.getPaymentFee();
        payment.getinitiatePaymentAuthorization();
        payment.getPaymentAuthorization();
        payment.getPaymentAuthorizationDetail();
        payment.updatePaymentAuthorizationDetail();
        payment.getPaymentAuthorizationStatus();
        d.closeWindow();
    }

    @Test(priority = 9,dataProvider = "aspspData", description = "Create and Authorize consent via UI")
    public void DP_13_createConsentandGetAccountInformationTppRedirectTrue_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        consent.createConsentViaUI();
        consent.getConsentDetails();
        consent.geConsentStatus();
        // consent.AcoountInformation();
        d.closeWindow();
    }


    @Test(priority = 10,dataProvider = "aspspData", description = "File download")
    public void DP_14_downloadSpecifications_TPPRegistration_JSON_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("TPP registration");
        d.closeWindow();
    }



    @Test(priority = 11,dataProvider = "aspspData", description = "File Download")
    public void DP_15_downloadSpecifications_LoginPage_JSON_Funationality(Map<String, String> map) throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("Login page");
       d.closeWindow();
    }

    @Test(priority = 12,dataProvider = "aspspData", description = "file download")
    public void DP_16_downloadSpecifications_UserAuthentication_JSON_Funationality(Map<String, String> map) throws IOException {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("User authentication");
        d.closeWindow();
    }

    @Test(priority = 13,dataProvider = "aspspData", description = "file download")
    public void DP_17_downloadSpecifications_ListOfAvailableAccounts_JSON_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("List of available accounts");
        d.closeWindow();
    }

    @Test(priority = 14,dataProvider = "aspspData", description = "file download")
    public void DP_18_downloadSpecifications_Consents_JSON_Funationality(Map<String, String> map) throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("Consents");
        d.closeWindow();
    }

    @Test(priority = 15,dataProvider = "aspspData", description = "file download")
    public void DP_19_downloadSpecifications_consentAuthorisation_JSON_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("Consent authorisation");
        d.closeWindow();
    }

    @Test(priority = 16,dataProvider = "aspspData", description = "file download")
    public void DP_20_downloadSpecifications_AcountInformation_JSON_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("Account information");
       d.closeWindow();
    }

    @Test(priority = 17,dataProvider = "aspspData", description = "file download")
    public void DP_21_downloadSpecifications_PaymentInitiationAndInformation_JSON_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("Payment initiation and information");
        d.closeWindow();
    }

    @Test(priority = 18,dataProvider = "aspspData", description = "file download")
    public void DP_22_downloadSpecifications_PaymentAuthorisation_JSON_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("Payment authorisation");
        d.closeWindow();
    }

    @Test(priority = 19,dataProvider = "aspspData", description = "file download")
    public void DP_23_downloadSpecifications_fundConfirmation_JSON_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("Funds Confirmation");
       d.closeWindow();
    }


    @Test(priority = 20,dataProvider = "aspspData", description = "file download")
    public void DP_24_downloadSpecifications_TPPRegistration_YAML_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforYAML("TPP registration");
        d.closeWindow();
    }

   /* @Test(priority = 11,dataProvider = "aspspData", description = "file download")
    public void DP_25_downloadSpecifications_LoginPage_YAML_Funationality(Map<String, String> map) throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforYAML("Login page");
        Selenide.closeWebDriver();
    }

    @Test(priority = 12,dataProvider = "aspspData", description = "file download")
    public void DP_26_downloadSpecifications_UserAuthentication_YAML_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforYAML("User authentication");
        Selenide.closeWebDriver();
    }


    @Test(priority = 13,dataProvider = "aspspData", description = "file download")
    public void DP_27_downloadSpecifications_ListOfAvailableAccounts_YAML_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforYAML("List of available accounts");
        Selenide.closeWebDriver();
    }

    @Test(priority = 14,dataProvider = "aspspData", description = "file download")
    public void DP_28_downloadSpecifications_Consents_YAML_Funationality(Map<String, String> map) throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforYAML("Consents");
        Selenide.closeWebDriver();
    }

    @Test(priority = 15,dataProvider = "aspspData", description = "file download")
    public void DP_29_downloadSpecifications_consentAuthorisation_YAML_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("Consent authorisation");
        Selenide.closeWebDriver();
    }

    @Test(priority = 16,dataProvider = "aspspData", description = "file download")
    public void DP_30_downloadSpecifications_AcountInformation_YAML_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforJSON("Account information");
        Selenide.closeWebDriver();
    }

    @Test(priority = 17,dataProvider = "aspspData", description = "file download")
    public void DP_31_downloadSpecifications_PaymentInitiationAndInformation_YAML_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforYAML("Payment initiation and information");
        Selenide.closeWebDriver();
    }

    @Test(priority = 18,dataProvider = "aspspData", description = "file download")
    public void DP_32_downloadSpecifications_PaymentAuthorisation_YAML_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforYAML("Payment authorisation");
        Selenide.closeWebDriver();
    }


    @Test(priority = 19,dataProvider = "aspspData", description = "file download")
    public void DP_33_downloadSpecifications_fundConfirmation_YAML_Funationality(Map<String, String> map)
            throws Exception {
        devportalloginurl();
        d.setLoginDetails();
        downloadSpecifications.downloadSpecificationsforYAML("Funds Confirmation");
        Selenide.closeWebDriver();
    }
*/
}


