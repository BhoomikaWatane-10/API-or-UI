package com.luminor.tests.InstantPayment;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.*;
import com.luminor.taf.Taf;
import com.luminor.utils.enums.AuthTypes;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Map;


public class InstantPaymentScenarios extends BasePsd2Test {
    InstantPayments instantPayments = new InstantPayments();

    public InstantPaymentScenarios() throws IOException {
    }

    @DataProvider
    public Object[][] aspspData() {
        return Taf.utils().excel().loadAllRows(testDataFile(), "createConsentCreatePayment");
    }


    @Test(priority = 0, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Currency")
    public void BPSD_4564_4555_InstantPayment_InvalidMissingCurrency(Map<String, String> dp) throws IOException {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMisingCurrency("AM11");
    }


    @Test(priority = 1, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing debitor Id Type")
    public void BPSD_4568_InstantPayment_InvalidMissingDebitorIdType(Map<String, String> dp) throws IOException {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMissingDebitorIdType("BE16");
    }

    @Test(priority = 2, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing debitor Country")
    public void BPSD_4570_InstantPayment_InvalidMissingDebtorCountry(Map<String, String> dp) throws IOException {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMissingDebitorCountry("BE10");
    }

    @Test(priority = 3, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Ultimate Debitor Namr")
    public void BPSD_4572_InstantPayment_MissingUltimateDebitorName(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.missingUltimateDebitorName("BE21");
    }

    @Test(priority = 4, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Credior Name")
    public void BPSD_4574_InstantPayment_InvalidMissingCreditorName(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMissingCreditorName("BE22");
    }

    @Test(priority = 5, dataProvider = "aspspData", enabled = false, description = "instant  payment validation- Missing Credior Id")
    public void BPSD_4577_InstantPayment_MissingCreditorId(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.MissingCreditorId("BE17");
    }

    @Test(priority = 6, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Credior Type")
    public void BPSD_4578_InstantPayment_InvalidMissingCreditorType(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMissingCreditorType("BE17");
    }

    @Test(priority = 7, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Credior Type")
    public void BPSD_4566_InstantPayment_InvalidMissingDebtorType(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMissingDebtorType("BE15");
    }

    @Test(priority = 8, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Credior Type")
    public void BPSD_4579_InstantPayment_InvalidMissingCreditorIdType(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMissingCreditorIdType("BE17");
    }

    @Test(priority = 9, dataProvider = "aspspData", enabled = false, description = "Creating, signing Instant payment via API")
    public void BPSD_4519_4559_4558_4548_createPaymentAndSignViaApi(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.createAndSignInstantSepaPayment(dp);
    }


    @Test(priority = 10, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Credior Type")
    public void BPSD_4590_InstantPayment_InvalidMissingPurposeCode(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMissingPurposeCode("FF07");
    }

    @Test(priority = 11, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Credior Type")
    public void BPSD_4585_InstantPayment_InvalidMissingRequestExecutionDate(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMissingRequestExecutionDate("CH03");
    }

    @Test(priority = 12, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Charge Bearer")
    public void BPSD_4584_InstantPayment_InvalidMissingChargeBearer(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMissingChargeBearer("BE19");
    }

    @Test(priority = 13, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Payment service level")
    public void BPSD_4583_InstantPayment_InvalidMissingPaymentServiceLevel(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMissingPaymentServiceLevel("FF04");
    }

    @Test(priority = 14, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Missing Currency")
    public void BPSD_4582_4556_InstantPayment_InvalidInstructedAccountObjectValidation(Map<String, String> dp) throws IOException {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMisingCurrency("AM11");
        instantPayments.AmountTobeZero("AM01");
        instantPayments.amountTobeMissing("AM12");
    }

    @Test(priority = 15, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Exceeds 35 character debtor Id")
    public void BPS_4567_InstantPayment_Exceeds35CharacterDebtorId(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.debtorIdExceeds35Character("BE16");
    }

    @Test(priority = 16, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Exceeds 70 character debtor Name")
    public void BPS_4571_InstantPayment_Exceeds70UtlimateDebtorName(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.UltimateDebtorNameExceeds70Character("BE20");
    }

    @Test(priority = 17, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Exceeds 70 character Creditor Name")
    public void BPS_4573_InstantPayment_Exceeds70CreditorName(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.CreditorNameExceeds70Character("BE20");
    }

    @Test(priority = 18, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Exceeds 35 character instruction Id")
    public void BPS_4587_InstantPayment_Exceeds35CharacterInstructionId(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InstructionIdExceeds35Character("DS04");
    }

    @Test(priority = 19, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Exceeds 70 character Debtor Address Street")
    public void BPS_4569_InstantPayment_Exceeds70DebtorAddressStreet(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.DebtorAddressStreetExceeds70Character("BE07");
    }

    @Test(priority = 20, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Exceeds 70 character EndToEndIdentification")
    public void BPS_4586_InstantPayment_Exceeds70DebtorEndToEndIdentification(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.EndToEndNotifcationExceeds35Character("FF08");
    }

    @Test(priority = 21, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Exceeds 70 character RemittanceInformationUnstructured")
    public void BPS_4588_InstantPayment_MissingOrExceeds140ChracterRemittanceInformationUnstructured(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.MissingOrExceeds140ChracterRemittanceInformationUnstructured("RR07");
    }

    @Test(priority = 22, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Exceeds 35 character debtor Id")
    public void BPS_4589_InstantPayment_MissingOrExceedsChracterRemittanceInformationStructured(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.MissingOrExceeds140ChracterRemittanceInformationStructured("RR09");
    }

    @Test(priority = 23, dataProvider = "aspspData", enabled = false, description = "Creating, signing payment via Browser")
    public void BPSD_4508_createPaymentAndSignViaUi(Map<String, String> dp) throws IOException {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments
                .openCreatedInstantPaymentFromBrowser()
                .instantsignPayment()
                .verifySuccessMessageIsDisplayed();
    }


    //not executed- need to execute
    @Test(priority = 9, dataProvider = "aspspData", enabled = false, description = "Creating, signing payment via Browser")
    public void BPSD_4700_4510_createPaymentAndSignViaUiForBlankedIBAN(Map<String, String> dp) throws IOException {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments
                .openCreatedInstantPaymentFromBrowserForBlankIBANUsingUI()
                .signPaymentForBlankedIBAN()
                .verifySuccessMessageIsDisplayed();
    }

    @Test(priority = 24, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Exceeds 70 character Creditor Street")
    public void BPS_4580_InstantPayment_MissingOrExceedsCreditorCountryStreet(Map<String, String> dp) throws Exception {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.InvalidMisingExceedsCreditorStreet("BE04");
        instantPayments.InvalidMisingExceedsCreditorCountry("BE11");
    }

    @Test(priority = 25, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-Invalid Debtor IBAN")
    public void BPS_4563_4511_InstantPayment_InvalidMissingDebtorIban(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.invalidMissingDebtorIban("AC02");

    }

    @Test(priority = 26, dataProvider = "aspspData", enabled = false, description = "instant  payment validation-invalid creditor IBAN")
    public void BPSD_4553_4552_InstantPayment_InvalidCreditorIban(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.invalidCreditorIban("AC03");

    }

    /*//*
    /need to check
        @Test(priority = 0, dataProvider = "aspspData" ,enabled = false,description = "instant  payment validation-Corporate IBAN")
        public void BPSD_4549_InstantPayment_CorporateLT(Map<String, String> dp) {
            psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
            instantPayments.DebtorIBANForCorporateIBAN("INSTANT_PAYMENTS_NOT_AVAILABLE");

        }*//*

//Login to EE
    @Test(priority = 0, dataProvider = "aspspData" ,enabled = false,description = "instant  payment validation-Corporate IBAN")
    public void BPSD_4529_InstantPayment_EEIBAN(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.DebtorIBANForEEIBAN("INSTANT_PAYMENTS_NOT_AVAILABLE");

    }
//Login to LV
    @Test(priority = 0, dataProvider = "aspspData" ,enabled = false,description = "instant  payment validation-Corporate IBAN")
    public void BPSD_4528_InstantPayment_LVIBAN(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.DebtorIBANForLVIBAN("INSTANT_PAYMENTS_NOT_AVAILABLE");

    }*/
    @Test(priority = 27, dataProvider = "aspspData", enabled = false, description = "Creating, delete Instant payment via API")
    public void BPSD_4518_createAndDeletePayment(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.createAndDeletePayment("CANC");
    }

    @Test(priority = 28, dataProvider = "aspspData", enabled = false, description = "Verify instant flag value -true")
    public void BPSD_4550_VerifyInstantFlagValuesTrue(Map<String, String> dp) throws IOException {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.createInstantSepaPaymentwithInstantHeaders("true", 201);
    }

    @Test(priority = 29, dataProvider = "aspspData", enabled = false, description = "Verify instant flag value -true")
    public void BPSD_4550_VerifyInstantFlagValuesFalse(Map<String, String> dp) throws IOException {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.createInstantSepaPaymentwithInstantHeaders("false", 403);
    }

    @Test(priority = 30, dataProvider = "aspspData", enabled = false, description = "Creating, signing payment via Browser for insuffcient Funds")
    public void BPSD_4514_createPaymentAndSignViaUiForInsuffientFund(Map<String, String> dp) throws IOException {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments
                .openCreatedInstantPaymentFromBrowserForInsufficientFunds()
                .instantsignPaymentForSufficientFund()
                .verifySuccessMessageIsDisplayedForInsufficientFund();
    }

    //need to execute
    @Test(priority = 31, dataProvider = "aspspData", enabled = false, description = "Creating, signing Instant payment via API")
    public void BPSD_4520_createPaymentAndSignViaApiForInsuffientFunds(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.createAndSignInstantSepaPaymentForInsufficientFunds(dp);
    }


/*//*
/need to execute-not automate fully as Corp IBAN required
    @Test(priority = 8, dataProvider = "aspspData",enabled = false,description = "Creating, signing Instant payment via API")
    public void BPSD_4513_createPaymentAndSignViaApiForBlockedIBAN(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.createAndSignInstantSepaPaymentForBlockedIBANViaAPI(dp);
    }*/


    @Test(priority = 32, dataProvider = "aspspData", enabled = false, description = "Creating, signing Instantand delete payment via API")
    public void BPSD_4509_createAndDeleteSignedPayment(Map<String, String> dp) {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.createAndDeleteSignedPayment(dp);
    }

    @Test(priority = 33, dataProvider = "aspspData", enabled = false, description = "Creating, signing Instantand delete payment via API")
    public void BPSD_4515_createAndDeleteSignedPaymentViaUi(Map<String, String> dp) throws Exception {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.openDeleteInstantPaymentFromBrowser("CANC");

    }

    @Test(priority = 34, dataProvider = "aspspData", enabled = false, description = "Creating, signing Transaction History via API")
    public void BPSD_4517_InstantPayment_createTransactionHistoryViaApi(Map<String, String> dp) throws Exception {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.createAndSignInstantSepaPayment(dp);
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        TransactionHistory.createAndSignTransactionHistory(dp);
    }

    @Test(priority = 35, dataProvider = "aspspData", enabled = false, description = "Creating, signing Transaction History via UI")
    public void BPSD_4516_InstantPayment_createTransactionHistoryViaUI(Map<String, String> dp) throws Exception {
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        instantPayments.createAndSignInstantSepaPayment(dp);
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        TransactionHistory
                .createTransactionHistoryFromBrowser(dp)
                .signTransaction()
                .verifySuccessMessageIsDisplayed();
        Taf.web().browser().stopProxy();


    }
    @Test(priority = 10, dataProvider = "aspspData", description = "Creating, signing Transaction History and cancelled via Browser")
    public void BPSD_4660_CreateAndDoNotSignedPayment(Map<String, String> dp) {
        Taf.web().browser().startProxy();
        psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
        Payments.createAndDoNotSignSepaPaymentCheckPaymentStatus(dp.get("creditorAccount"));
        Taf.web().browser().stopProxy();
    }

}






