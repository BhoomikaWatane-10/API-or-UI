package com.luminor.tests.regression;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.Accounts;
import com.luminor.api.endpoints.Blob;
import com.luminor.api.endpoints.Consent;
import com.luminor.api.endpoints.Tpp;
import com.luminor.api.models.blob.BlobModel;
import com.luminor.taf.Taf;
import com.luminor.utils.BlobHelper;
import com.luminor.utils.enums.AuthTypes;
import io.restassured.specification.RequestSpecification;
import java.util.List;
import java.util.Map;
import org.apache.http.HttpStatus;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CheckTppClientStatusTest extends BasePsd2Test {

  RequestSpecification cccSpec;

  @DataProvider
  public Object[][] tppStatusValidationData() {
    return Taf.utils().excel().loadAllRows(testDataFile(), "checkTppClientStatus");
  }


  @Test(dataProvider = "tppStatusValidationData", description = "Account information should not be available after Tpp status is changed to 'BLOCKED_BY_BANK'")
  public void checkAccountInformationUnavailable(Map<String, String> dp) {
    RequestSpecification psd2Spec = psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    String consentId = Consent.createAndSignConsent(dp).getConsentId();
    Accounts.getAccountInfo(dp.get("debtorAccount"));
    cccSpec = authenticateCCC();

    List<BlobModel> blobList = Blob.getJsonBlob(dp.get("clientIdBlob"));
    BlobModel blob = BlobHelper.getLatestBlob(blobList);
    String clientId = blob.getId();

    Tpp.changeTppStatus(clientId, Tpp.TPP_STATUS_BLOCKED);
    Taf.api().rest().setSpecification(psd2Spec).addHeader("Consent-ID", consentId);
    Accounts.checkAccountsUnavailable(HttpStatus.SC_CONFLICT);
  }
}