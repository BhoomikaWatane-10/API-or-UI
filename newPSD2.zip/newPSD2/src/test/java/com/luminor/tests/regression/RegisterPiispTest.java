package com.luminor.tests.regression;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.Consent;
import com.luminor.api.endpoints.Funds;
import com.luminor.api.endpoints.Tpp;
import com.luminor.api.endpoints.TppAccess;
import com.luminor.taf.Taf;
import com.luminor.utils.enums.AuthTypes;
import java.util.Map;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class RegisterPiispTest extends BasePsd2Test {

  @DataProvider
  public Object[][] piispData() {
    return Taf.utils().excel().loadRandomSingleRow(testDataFile(), "registerPiisp");
  }

  @AfterMethod(alwaysRun = true)
  public void deleteConsent() {
    if(Consent.getConsentId() != null || Consent.getConsentId() != ""){
      Consent.deleteConsent(Consent.getConsentId());
    }
  }

  @Test(dataProvider = "piispData", description = "PIISP should be registered, available funds should be confirmed")
  public void registerPiispCreateConsentCheckAvailableFunds(Map<String, String> dp) {
    Tpp.createEditAndActivateNewTpp();
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent.createAndSignConsent(dp);
    Funds.checkAvailableFunds();
    TppAccess.checkServiceAccessUnavailable();
  }
}