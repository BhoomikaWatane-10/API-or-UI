package com.luminor.tests.regression;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.Accounts;
import com.luminor.api.endpoints.Consent;
import com.luminor.api.endpoints.Funds;
import com.luminor.api.endpoints.Payments;
import com.luminor.api.endpoints.Tpp;
import com.luminor.api.enums.TransactionStatus;
import com.luminor.taf.Taf;
import com.luminor.utils.enums.AuthTypes;
import java.util.Map;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class RegisterAspspTest extends BasePsd2Test {

  @DataProvider
  public Object[][] aspspData() {
    return Taf.utils().excel().loadRandomSingleRow(testDataFile(), "registerAspsp");
  }

  @AfterMethod(alwaysRun = true)
  public void deleteConsent() {
    if(Consent.getConsentId() != null || Consent.getConsentId() != ""){
      Consent.deleteConsent(Consent.getConsentId());
    }
  }

  @Test(dataProvider = "aspspData", description = "ASPSP should be registered, consent should be created, payment should be created and signed, available funds should be checked")
  public void registerAspspCreateConsentCreateAndSignPaymentCheckAvailableFunds(
      Map<String, String> dp) {
    Tpp.createEditAndActivateNewTpp();
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent.createAndSignConsent(dp);
    Accounts.getAccountInfo(dp.get("debtorAccount"));
    String paymentId = Payments.createAndSignSepaPayment(dp);
    Payments.checkPaymentTransactionStatus(paymentId, TransactionStatus.ACSP);
    Funds.checkAvailableFunds();
  }
}