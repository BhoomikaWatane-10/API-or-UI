package com.luminor.tests.PSD2Regression;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.*;
import com.luminor.taf.Taf;
import com.luminor.utils.enums.AuthTypes;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Map;

public class RegressionTest extends BasePsd2Test {


  public RegressionTest() throws IOException {
  }

  @DataProvider
  public Object[][] aspspData() {
    return Taf.utils().excel().loadAllRows(testDataFile(), "createConsentCreatePayment");
  }

  @Test( dataProvider = "aspspData",description = "Creating, signing consent via API")
  public void createConsentAndSignViaApi(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent.createAndSignConsent(dp);
  }

  @Test(priority = 1, dataProvider = "aspspData",description = "Creating, signing payment via API")
  public void createPaymentAndSignViaApi(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent.createAndSignConsent(dp);
    Accounts.getAccountInfo(dp.get("debtorAccount"));
    Payments.createAndSignSepaPayment(dp);
  }

  @Test(priority = 2, dataProvider = "aspspData",description = "Creating, signing consent via Browser")
  public void createConsentAndSignViaUi(Map<String, String> dp) {
    Taf.web().browser().startProxy();
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent
            .createConsentFromBrowser(dp.get("debtorAccount"))
            .signConsent()
            .verifySuccessMessageIsDisplayed();
    Taf.web().browser().stopProxy();
  }

  @Test(priority = 3, dataProvider = "aspspData",description = "Creating, signing payment via Browser")
  public void createPaymentAndSignViaUi(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Payments
            .openCreatedPaymentFromBrowser(dp.get("debtorAccount"), dp.get("creditorAccount"))
            .signPayment()
            .verifySuccessMessageIsDisplayed();
  }
  @Test(priority = 4, dataProvider = "aspspData",description = "Creating, signing Transaction History via API")
  public void createTransactionHistoryViaApi(Map<String, String> dp) throws InterruptedException {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    TransactionHistory.createAndSignTransactionHistory(dp);
  }


  @Test(priority = 5, dataProvider = "aspspData",description = "Creating, signing Transaction via Browser")
  public void createTransactionHistoryAndSignViaUi(Map<String, String> dp) {
    Taf.web().browser().startProxy();
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    TransactionHistory
            .createTransactionHistoryFromBrowser(dp)
            .signTransaction()
            .verifySuccessMessageIsDisplayed();
    Taf.web().browser().stopProxy();
  }
  @Test(priority = 6, dataProvider = "aspspData",description = "Confirm Funds Available")
  public void confirmFundsAvailable(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent.createAndSignConsent(dp);
    Funds.checkAvailableFunds();
  }

  @Test(priority = 0, dataProvider = "aspspData",description = "Creating, signing payment via Browser-Blanked IBAN")
  public void createPaymentAndSignViaUiForBlankedIBAN(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Payments
            .openCreatedPaymentFromBrowserForBlankedIBAN( dp.get("creditorAccount"))
            .signPaymentForBlankedIBAN()
            .verifySuccessMessageIsDisplayed();
  }

  @Test(priority = 8, dataProvider = "aspspData",description = "Creating, signing  and delete payment via API")
  public void CreateAndDeleteSignedPaymentViaUi(Map<String, String> dp) throws Exception{
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Payments.openCancelPaymentPaymentFromBrowser(dp.get("debtorAccount"),dp.get("creditorAccount"),"CANC");

  }
  @Test(priority = 9, dataProvider = "aspspData", description = "Creating, signing consent and cancelled via Browser")
  public void CreateAndDeleteSignedConsentViaUi(Map<String, String> dp) {
    Taf.web().browser().startProxy();
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent.openCancelConsentFromBrowser(dp.get("debtorAccount"), "revokedByPsu");
    Taf.web().browser().stopProxy();
  }

  @Test(priority = 10, dataProvider = "aspspData", description = "Creating, signing Transaction History and cancelled via Browser")
  public void CreateAndDeleteSignedStatementViaUi(Map<String, String> dp) {
    Taf.web().browser().startProxy();
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    TransactionHistory.openCancelTransactionHistoryFromBrowser(dp,dp.get("debtorAccount"), "rejected");
    Taf.web().browser().stopProxy();
  }

  @Test(priority = 10, dataProvider = "aspspData", description = "Creating, signing Transaction History and cancelled via Browser")
  public void BPSD_4660_CreateAndDoNotSignedPayment(Map<String, String> dp) {
    Taf.web().browser().startProxy();
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Payments.createAndDoNotSignSepaPaymentCheckPaymentStatus(dp.get("creditorAccount"));
    Taf.web().browser().stopProxy();
  }


}