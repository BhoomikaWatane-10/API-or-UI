package com.luminor.tests.regression;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.TppAccess;
import com.luminor.taf.Taf;
import com.luminor.utils.enums.AuthTypes;
import java.util.Map;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CheckUserRightsTest extends BasePsd2Test {

  @DataProvider
  public Object[][] userRightsValidationData() {
    return Taf.utils().excel().loadAllRows(testDataFile(), "checkUserRights");
  }

  @Test(dataProvider = "userRightsValidationData", description = "Services access should be available according to specific user rights set")
  public void checkServiceAvailabilityDifferentUserRights(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Taf.api().rest().addHeader("Consent-ID", dp.get("consentId"));
    TppAccess.checkUserRightsValidations(dp.get("consentIban"));
  }
}