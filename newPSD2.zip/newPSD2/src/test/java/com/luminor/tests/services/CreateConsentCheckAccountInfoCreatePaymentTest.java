package com.luminor.tests.services;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.Accounts;
import com.luminor.api.endpoints.Payments;
import com.luminor.api.enums.TransactionStatus;
import com.luminor.taf.Taf;
import com.luminor.utils.enums.AuthTypes;
import java.util.Map;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CreateConsentCheckAccountInfoCreatePaymentTest extends BasePsd2Test {

  @DataProvider
  public Object[][] aspspAllCountriesData() {
    return Taf.utils().excel().loadAllRows(testDataFile(), "aspspAllCountries");
  }

  @Test(dataProvider = "aspspAllCountriesData", description = "Payment should be created and signed, account related information should be checked")
  public void createAndSignPaymentCheckAccountInfo(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);

    Taf.api().rest().addHeader("Consent-ID", dp.get("consentId"));
    String resourceId = Accounts.getAccountInfo(dp.get("debtorAccount")).getResourceId();
    Payments.getPaymentFee(dp.get("debtorAccount"), dp.get("creditorAccount"));
    String paymentId = Payments.createAndSignSepaPayment(dp);
    Payments.getPaymentDetails(paymentId);

    Accounts.checkAccountDetails(resourceId);
    Accounts.checkAccountBalances(resourceId);
    Accounts.checkAccountTransactionList(resourceId);

    //checking payment status, when processed in core (might need to wait 2 mins until checking)
    Payments.checkPaymentTransactionStatus(paymentId, TransactionStatus.ACSC);
    Accounts.checkTransactionListContainsParticularTransaction(
        Payments.getPaymentDetails(paymentId).getRemittanceInformationUnstructured());
  }
}