package com.luminor.tests.regression;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.Accounts;
import com.luminor.api.endpoints.Consent;
import com.luminor.api.endpoints.Funds;
import com.luminor.taf.Taf;
import com.luminor.utils.enums.AuthTypes;
import java.util.Map;
import org.apache.http.HttpStatus;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CheckProductTest extends BasePsd2Test {

  @DataProvider
  public Object[][] productValidationData() {
    return Taf.utils().excel().loadAllRows(testDataFile(), "checkProduct");
  }

  @Test(dataProvider = "productValidationData", description = "Consent and account services should not be available when 'PSD2 compliance' product access role is set to 'No access'")
  public void checkProduct(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Taf.api().rest().addHeader("Consent-ID", dp.get("consentId"));
    Consent.checkAccountListUnavailable();
    Accounts.checkAccountsUnavailable(HttpStatus.SC_UNAUTHORIZED);
    Funds.checkAvailableFundsUnavailable(HttpStatus.SC_UNAUTHORIZED);
  }
}