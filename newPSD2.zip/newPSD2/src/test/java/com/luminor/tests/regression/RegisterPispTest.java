package com.luminor.tests.regression;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.Payments;
import com.luminor.api.endpoints.Tpp;
import com.luminor.api.endpoints.TppAccess;
import com.luminor.api.enums.TransactionStatus;
import com.luminor.taf.Taf;
import com.luminor.utils.enums.AuthTypes;
import java.util.Map;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class RegisterPispTest extends BasePsd2Test {

  @DataProvider
  public Object[][] pispData() {
    return Taf.utils().excel().loadRandomSingleRow(testDataFile(), "registerPisp");
  }

  @Test(dataProvider = "pispData", description = "PISP should be registered, payment should be created and signed")
  public void registerPispCreateConsentCreateAndSignPayment(Map<String, String> dp) {
    Tpp.createEditAndActivateNewTpp();
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    String paymentId = Payments.createAndSignSepaPayment(dp);
    Payments.checkPaymentTransactionStatus(paymentId, TransactionStatus.ACSP);
    TppAccess.checkServiceAccessUnavailable();
  }
}