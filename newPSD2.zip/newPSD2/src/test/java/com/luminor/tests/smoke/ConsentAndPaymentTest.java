package com.luminor.tests.smoke;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.*;
import com.luminor.taf.Taf;
import com.luminor.utils.enums.AuthTypes;
import java.util.Map;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ConsentAndPaymentTest extends BasePsd2Test {

  @DataProvider
  public Object[][] aspspData() {
    return Taf.utils().excel().loadAllRows(testDataFile(), "createConsentCreatePayment");
  }



  @Test(priority = 2, dataProvider = "aspspData", description = "Creating, signing consent via API")
  public void createConsentAndSignViaApi(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent.createAndSignConsent(dp);
  }

  @Test(priority = 1, dataProvider = "aspspData",description = "Creating, signing payment via API")
  public void createPaymentAndSignViaApi(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent.createAndSignConsent(dp);
    Accounts.getAccountInfo(dp.get("debtorAccount"));
    Payments.createAndSignSepaPayment(dp);
  }

  @Test(priority = 0, dataProvider = "aspspData", description = "Creating, signing consent via Browser")
  public void createConsentAndSignViaUi(Map<String, String> dp) {
    Taf.web().browser().startProxy();
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent
            .createConsentFromBrowser(dp.get("debtorAccount"))
            .signConsent()
            .verifySuccessMessageIsDisplayed();
    Taf.web().browser().stopProxy();
  }

  @Test(priority = 3, dataProvider = "aspspData", description = "Creating, signing payment via Browser")
  public void createPaymentAndSignViaUi(Map<String, String> dp) {
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Payments
            .openCreatedPaymentFromBrowser(dp.get("debtorAccount"), dp.get("creditorAccount"))
            .signPayment()
            .verifySuccessMessageIsDisplayed();
  }

}