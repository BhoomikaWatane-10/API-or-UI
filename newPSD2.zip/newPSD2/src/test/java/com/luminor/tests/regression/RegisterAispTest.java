package com.luminor.tests.regression;

import com.luminor.BasePsd2Test;
import com.luminor.api.endpoints.Accounts;
import com.luminor.api.endpoints.Consent;
import com.luminor.api.endpoints.Tpp;
import com.luminor.api.endpoints.TppAccess;
import com.luminor.taf.Taf;
import com.luminor.utils.enums.AuthTypes;
import java.util.Map;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class RegisterAispTest extends BasePsd2Test {

  @DataProvider
  public Object[][] aispData() {
    return Taf.utils().excel().loadRandomSingleRow(testDataFile(), "registerAisp");
  }

  @AfterMethod(alwaysRun = true)
  public void deleteConsent() {
    if(Consent.getConsentId() != null || Consent.getConsentId() != ""){
      Consent.deleteConsent(Consent.getConsentId());
    }
  }

  @Test(dataProvider = "aispData", description = "AISP should be registered, consent should be created, account related information should be received")
  public void registerAispCreateConsentCheckAccountInformation(Map<String, String> dp) {
    Tpp.createEditAndActivateNewTpp();
    psd2AuthenticationWithoutBypass(AuthTypes.Web, dp);
    Consent.createAndSignConsent(dp);
    String resourceId = Accounts.getAccountInfo(dp.get("debtorAccount")).getResourceId();
    Accounts.checkAccountDetails(resourceId);
    Accounts.checkAccountBalances(resourceId);
    Accounts.checkAccountTransactionList(resourceId);
    TppAccess.checkServiceAccessUnavailable();
  }
}