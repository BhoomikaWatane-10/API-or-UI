package com.luminor;

import com.luminor.taf.Taf;
import com.luminor.taf.test.web.BaseWebPage;
import com.luminor.taf.test.web.BrowserApi;

public class Psd2 extends BaseWebPage {

  protected final BrowserApi browser = Taf.web().browser();
}
