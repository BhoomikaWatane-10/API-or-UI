package com.luminor;

import static com.luminor.utils.SslConfigUtils.getSslConfig;
import static io.restassured.config.RestAssuredConfig.newConfig;
import static java.util.UUID.randomUUID;

import com.codeborne.selenide.Selenide;
import com.luminor.api.endpoints.Blob;
import com.luminor.api.models.blob.BlobModel;
import com.luminor.api.pojo.ccc.AuthenticationResponse;
import com.luminor.pageobjects.ActiveDirectoryLoginPage;
import com.luminor.taf.BaseTest;
import com.luminor.taf.Taf;
import com.luminor.taf.test.web.auth.MsProxy;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.ApiAuthentication;
import com.luminor.utils.Authorization;
import com.luminor.utils.BlobHelper;
import com.luminor.utils.RetryAnalyzerUtil;
import com.luminor.utils.enums.AuthTypes;
import com.luminor.utils.models.AuthDataModel;
import io.qameta.allure.Step;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.RequestSpecification;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class BasePsd2Test extends BaseTest {

  protected static final String CONSENT_RANDOM = "0cf915a0-0967-11eb-8648-53a9f7692ef9";

  private static String idToken = null;
  private static String accessToken = null;
  public static Properties prop;
  public static ExcelDataProviderApi excel = Taf.utils().excel();

  @BeforeSuite(alwaysRun = true)
  public void beforeSuite(ITestContext context) {
    for (ITestNGMethod method : context.getAllTestMethods()) {
      method.setRetryAnalyzerClass(RetryAnalyzerUtil.class);
    }
  }

  public static void setPsd2specification() {
    Taf.utils().log().debug("Building request specification for TPP registration in PSD2");
    RequestSpecification requestSpecification =
        new RequestSpecBuilder()
            .setBaseUri(config.getEnvironmentProperty("openam.url"))
            .setConfig(
                newConfig()
                    .sslConfig(getSslConfig(excel.getValueForCurrentIteration("tppType"))))
            .setContentType(ContentType.JSON)
            .addHeader("X-Request-ID", randomUUID().toString())
            .addFilter(new AllureRestAssured())
            .build();

    Taf.api().rest().setSpecification(requestSpecification);
  }

  public static RequestSpecification authenticateCCC() {
    Taf.utils().log().info("Building request specification for TPP activation in CCC");
    if (Taf.utils().config().isEnvironmentStage() && accessToken == null) {
      MsProxy msproxy = new MsProxy();
      msproxy.startProxy();
      msproxy.setAuthTokensFilter();
      Taf.web().browser().openCurrentEnvApp("ccc");
      loginThroughActiveDirectory();
      msproxy.stopProxy();
      Selenide.closeWebDriver();
      msproxy.checkAuthenticationTokens();
      idToken = msproxy.getAuthToken();
      accessToken = msproxy.getMsToken();
    } else if (Taf.utils().config().isEnvironmentDev() || Taf.utils().config()
        .isEnvironmentTest() && accessToken == null) {
      AuthenticationResponse authResponse = ApiAuthentication.getToken();
      idToken = authResponse.getIdToken();
      accessToken = authResponse.getAccessToken();
    }
    RequestSpecification requestSpecification = new RequestSpecBuilder()
        .setBaseUri(config.getEnvironmentProperty("ccc.api.url"))
        .setBasePath(config.getEnvironmentProperty("ccc.api.path"))
        .addHeader("Authorization", "Bearer " + idToken)
        .addHeader("MS-TOKEN", accessToken)
        .addHeader("Content-Type", "application/json")
        .addFilter(new AllureRestAssured())
        .build();

    Taf.api().rest().setSpecification(requestSpecification);

    return requestSpecification;
  }

  @Step("Authenticate psd2 using: {0} authentication")
  public static FilterableRequestSpecification psd2AuthenticationWithoutBypass(AuthTypes type, Map<String, String> dp) {
    RequestSpecification requestSpecification = buildRequestSpec(type, dp);
    Taf.api().rest().setSpecification(requestSpecification);

    return (FilterableRequestSpecification) requestSpecification;
  }

  @Step("Building request specification for authentication to PSD2")
  private static RequestSpecification buildRequestSpec(AuthTypes type, Map<String, String> dp){
    String clientId;
    if(dp.containsKey("clientId")){
      clientId = dp.get("clientId");
    }else{
      List<BlobModel> blobList = Blob.getJsonBlob(dp.get("clientIdBlob"));
      BlobModel blob = BlobHelper.getFirst24hValidBlob(blobList);
      clientId = blob.getId();
    }

    AuthDataModel model = new AuthDataModel(
        dp.get("username"),
        dp.get("personalCode"),
        dp.get("authMethodRef"),
        dp.get("tppType"),
        clientId,
        config.getEnvironmentProperty("redirect.url"),
        dp.get("country"));

    String authorization = type.equals(AuthTypes.Web)
        ? Authorization.retrieveAccessTokenWeb(model)
        : Authorization.retrieveAccessTokenApi(model);

    return new RequestSpecBuilder()
        .setBaseUri(config.getEnvironmentProperty("url"))
        .setConfig(
            newConfig()
                .sslConfig(getSslConfig(excel.getValueForCurrentIteration("tppType"))))
        .addHeader("Authorization", "Bearer " + authorization)
        .addHeader("X-Request-ID", randomUUID().toString())
        .addHeader("PSU-IP-Address", "122.122.122")
        .setContentType(ContentType.JSON)
        .addHeader("Tpp-Redirect-Preferred", "true")
        .addHeader("Tpp-Redirect-URI", "https://localhost/success")
        .addHeader("Tpp-Nok-Redirect-URI", "https://localhost/fail")
        .addFilter(new AllureRestAssured())
        .build();
  }

  @Step("Login through active directory")
  public static void loginThroughActiveDirectory() {
    Taf.utils().log().info(
        "Logging in as default user '" + Taf.utils().config().getEnvironmentProperty("user") + "'");

    new ActiveDirectoryLoginPage()
        .enterAndSubmitDefaultUsername()
        .enterAndSubmitDefaultPassword()
        .ignoreStayLoggedInOption()
        .waitForApplicationToLoad();
  }

  public static String testDataFile() {
    return Taf.utils().config().getProperty("project.environment.name") + "Data" +
        System.getProperty("project.country").toUpperCase() + ".xlsx";
  }

  public static void devportalloginurl(){

   Selenide.open(config.getEnvironmentProperty("devportal.url"));

  }


  public static String getPropertyFromFile(String param) throws IOException {
    prop = new Properties();
    System.out.println(System.getProperty("user.dir"));
    FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\testData.properties");
    try {
      prop.load(fis);
      return prop.getProperty(param);


    } catch (IOException e1) {

      e1.printStackTrace();
    }
    return null;
  }
    /*public static String getPropertyFromFile(String param){
     return prop.getProperty(param);

    }*/

     }


