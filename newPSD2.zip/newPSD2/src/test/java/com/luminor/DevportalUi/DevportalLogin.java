package com.luminor.DevportalUi;

import com.luminor.pageobjectsDevportal.DevPortalLoginPage;

public class DevportalLogin {

    public static DevPortalLoginPage devportalLogin(){
        return new DevPortalLoginPage();
    }
}
