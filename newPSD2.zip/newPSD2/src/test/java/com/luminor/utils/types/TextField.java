package com.luminor.utils.types;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.luminor.utils.enums.ElementTypes;
import com.luminor.utils.interfaces.Field;
import io.qameta.allure.Step;

public class TextField implements Field {

  public SelenideElement element;

  public TextField(ElementTypes type, String attribute) {
    if (type.equals(ElementTypes.Id)) {
      element = $("input[id*='" + attribute + "']");

      if(!element.exists()){
        element = $("textarea[id*='" + attribute + "']");
      }
    }

    if (type.equals(ElementTypes.Name)) {
      ElementsCollection elements = $$("input[name*='" + attribute + "']");
      element = elements.find(Condition.visible);

      if(!element.exists()){
        element = $("textarea[name*='" + attribute + "']");
      }
    }
  }

  @Step("Set input value: {0}")
  public void setValue(String value) {
    element.is(Condition.exist);

    element.setValue(value);
  }
}
