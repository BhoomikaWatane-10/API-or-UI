package com.luminor.utils.enums.forms;

import com.luminor.utils.enums.AuthMethodOptions;
import com.luminor.utils.enums.ElementTypes;
import com.luminor.utils.interfaces.Field;
import com.luminor.utils.types.RadioField;
import com.luminor.utils.types.TextField;

public enum LoginForm {
  Username(new TextField(ElementTypes.Id, "idToken2"), "username"),
  AuthMethod(new RadioField("callback_3", AuthMethodOptions.values()), "authMethod"),
  PersonalCode(new TextField(ElementTypes.Id, "idToken6"), "personalCode"),
  DialCode(new TextField(ElementTypes.Id, "idToken9"), "dialCode"),
  MobileNumber(new TextField(ElementTypes.Id, "idToken10"), "mobileNumber");

  private Field field;
  private String excelField;

  LoginForm(Field field, String excelField) {
    this.field = field;
    this.excelField = excelField;
  }

  public Field getField() {
    return field;
  }

  public String getExcelField() {
    return excelField;
  }
}
