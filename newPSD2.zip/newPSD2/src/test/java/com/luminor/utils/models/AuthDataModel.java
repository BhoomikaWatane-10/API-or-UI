package com.luminor.utils.models;

public class AuthDataModel {

  private final String username;
  private final String personalCode;
  private final String authMethodRef;
  private final String tppType;
  private final String clientId;
  private final String redirectUri;
  private final String country;

  public AuthDataModel(String username,
                       String personalCode,
                       String authMethodRef,
                       String tppType,
                       String clientId,
                       String redirectUri,
                       String country) {
    this.username = username;
    this.personalCode = personalCode;
    this.authMethodRef = authMethodRef;
    this.tppType = tppType;
    this.clientId = clientId;
    this.redirectUri = redirectUri;
    this.country = country;
  }

  public String getUsername() {
    return username;
  }

  public String getPersonalCode() {
    return personalCode;
  }

  public String getAuthMethodRef() {
    return authMethodRef;
  }

  public String getTppType() {
    return tppType;
  }

  public String getClientId() {
    return clientId;
  }

  public String getRedirectUri() {
    return redirectUri;
  }

  public String getCountry() {
    return country;
  }



}
