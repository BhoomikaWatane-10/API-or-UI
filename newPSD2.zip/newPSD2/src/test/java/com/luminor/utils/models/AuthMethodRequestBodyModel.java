package com.luminor.utils.models;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.qameta.allure.Step;
import java.util.Map;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthMethodRequestBodyModel {

  @JsonProperty("authenticationMethodId")
  private String authMethod;

  @JsonCreator
  public AuthMethodRequestBodyModel(Map<String, String> dp) {
    this.authMethod = getPaymentType(dp.get("authMethod"));
  }

  @Step("convert {0} to body request string")
  private String getPaymentType(String paymentType) {
    String result = "SMART_ID";

    if (paymentType.contains("SmartId")) {
      result = "SMART_ID";
    }

    if (paymentType.contains("MobileId")) {
      result = "MOBILE_ID";
    }

    if (paymentType.contains("CardId")) {
      result = "IDCARD";
    }

    return result;
  }
}
