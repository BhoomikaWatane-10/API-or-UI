package com.luminor.utils;

import com.luminor.taf.Taf;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateHelper {

  public static String getFutureDate(int daysToAdd, String dateFormat) {
    DateFormat pattern = new SimpleDateFormat(dateFormat);
    String date = pattern.format(new Date());
    Calendar c = Calendar.getInstance();
    try {
      c.setTime(pattern.parse(date));
    } catch (ParseException e) {
      Taf.utils().log().debug(
          pattern.format(c.getTime()) + " parsing unsuccessful." + "\nDays added: " + daysToAdd
              + "\nPattern used: "
              + dateFormat);
      e.printStackTrace();
    }
    c.add(Calendar.DATE, daysToAdd);
    return pattern.format(c.getTime());
  }

  /**
   * Get date in yyyy-MM-dd format
   *
   * @return String date
   */
  public static String getCurrentDateInLtFormat(Date date) {
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    return dateFormat.format(date);
  }

  /**
   * Gets current month first day's date.
   *
   * @return String date
   */
  public static Date getCurrentMonthFirstDay() {
    Calendar c = Calendar.getInstance();
    setZeroTime(c);
    c.set(Calendar.DAY_OF_MONTH, 1);

    return c.getTime();
  }

  private static void setZeroTime(Calendar c) {
    c.set(Calendar.HOUR_OF_DAY, 0);
    c.set(Calendar.MINUTE, 0);
    c.set(Calendar.SECOND, 0);
    c.set(Calendar.MILLISECOND, 0);
  }
}