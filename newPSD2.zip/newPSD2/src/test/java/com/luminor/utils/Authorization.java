package com.luminor.utils;

import static com.luminor.utils.SslConfigUtils.getSslConfig;
import static io.restassured.RestAssured.given;
import static io.restassured.config.RestAssuredConfig.newConfig;
import static java.util.UUID.randomUUID;

import com.codeborne.selenide.Selenide;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.api.pojo.auth.AuthenticationResponse;
import com.luminor.api.pojo.auth.Value;
import com.luminor.pageobjects.*;
import com.luminor.taf.Taf;
import com.luminor.taf.controllers.FrameworkException;
import com.luminor.taf.utils.ConfigApi;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.models.AuthDataModel;
import io.qameta.allure.Step;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.response.Response;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.client.utils.URLEncodedUtils;


public class Authorization {

  private static String tokenId;
  private static String location;
  private static String accessToken;
  private static ConfigApi config = Taf.utils().config();
  private static final String AM_URI = config.getEnvironmentProperty("am.url");
  private static final String OPENAM_URI = config.getEnvironmentProperty("openam.url");
  private static final String OPENAM_PATH = config.getEnvironmentProperty("openam.path");
  private static final String REDIRECT_URI = config.getEnvironmentProperty("redirect.url");
  private static final String REALM = config.getEnvironmentProperty("realm");
  private static final String AUTH_METHOD = config.getEnvironmentProperty("auth.method");
  private static final String BYPASS = config.getEnvironmentProperty("bypass");
  private static final String GRANT_TYPE = config.getEnvironmentProperty("grant.type");
  private static final String MANDATE_TYPE = config.getEnvironmentProperty("mandate.type");
  private static final String DEVPORTAL_URI=config.getEnvironmentProperty("devportal.url");

  private static ExcelDataProviderApi excel = Taf.utils().excel();

  private Authorization() {
  }

  @Step("Retrieve access token from api calls")
  public static String retrieveAccessTokenApi(AuthDataModel model) {
    authenticate(model.getUsername(), model.getPersonalCode(), model.getClientId(),
        model.getAuthMethodRef());
    authorize(model.getClientId(), model.getRedirectUri());
    String code = extractCodeFormHeader();

    try {
      extractAccessToken(model.getClientId(), model.getRedirectUri(), model.getTppType(), code);
    } catch (Exception e) {
      e.printStackTrace();
    }

    return accessToken;
  }

  @Step("Login to application via browser")
  public static ConsentPage loginToSignConsent(){
    login().selectCustomerForConsentSigning();

    return new ConsentPage();
  }

  @Step("Login to application via browser")
  public static PaymentPage loginToSignPayment(){
    login().selectCustomerForPaymentSigning();

    return new PaymentPage();
  }
  @Step("Login to application via browser")
  public static BlankedIBANPaymentPage loginToSignPaymentForBlankedIBAN(){
    login().selectCustomerForPaymentSigningForBlankedIBAN();

    return new BlankedIBANPaymentPage();
  }
  @Step("Login to application via browser")
  public static InstantPaymentPage loginToSignInstantPayment() throws IOException {
    login().selectCustomerForInstantPaymentSigning();

    return new InstantPaymentPage();
  }

  @Step("Login to application via browser")
  public static InstantPaymentInsufficientPage loginToSignInstantPaymentForInsufficientPage() throws IOException {
    login().selectCustomerForInstantPaymentSigningForInsufficientPage();

    return new InstantPaymentInsufficientPage();
  }

  @Step("Retrieve access token from web login")
  public static String retrieveAccessTokenWeb(AuthDataModel model) {
    String code =
        openPsd2AuthPage(model.getCountry(), model.getClientId())
            .setLoginDetails()
            .pressLoginButton()
            .selectCustomer()
            .getCodeFromUrl(model.getRedirectUri());
    Selenide.closeWebDriver();

    try {
      extractAccessToken(model.getClientId(), model.getRedirectUri(), model.getTppType(), code);
    } catch (Exception e) {
      e.printStackTrace();
    }

    return accessToken;
  }

  @Step("Call api post json/authenticate")
  private static void authenticate(String username, String personalCode, String clientId,
      String authMethodRef) {
    String path = "/json/authenticate";
    Taf.utils().log()
        .info("Attempt to authorize user: '" + username + "' with personal code: '" + personalCode
            + "' at endpoint: " + AM_URI + path);
    Response response = given()
        .filter(new AllureRestAssured())
        .log()
        .all()
        .baseUri(AM_URI)
        .header("Accept-API-Version", "resource=2.1")
        .queryParam("username", username)
        .queryParam("person_serial", personalCode)
        .queryParam("client_id", clientId)
        .queryParam("auth_method", AUTH_METHOD)
        .queryParam("auth_method_reference", authMethodRef)
        .queryParam("bypass", BYPASS)
        .queryParam("realm", REALM)
        .queryParam("bank_country",
            excel.getValueForCurrentIteration("country").toLowerCase())
        .header("X-Request-ID", randomUUID().toString())
        .post(path).then().log().all().extract().response();

    if (response.getStatusCode() != 200) {
      Taf.utils().log().error(
          "Response status should be 200, but was " + response
              .getStatusCode() + ". Response body '" + response.getBody().prettyPrint() + "'");
    } else if (response.then().extract().body().as(AuthenticationResponse.class).getAuthId()
        != null) {
      response = given()
          .filter(new AllureRestAssured())
          .log()
          .all()
          .baseUri(AM_URI)
          .header("Accept-API-Version", "resource=2.1")
          .queryParam("username", username)
          .queryParam("person_serial", personalCode)
          .queryParam("client_id", clientId)
          .queryParam("auth_method", AUTH_METHOD)
          .queryParam("auth_method_reference", authMethodRef)
          .queryParam("bypass", BYPASS)
          .queryParam("realm", REALM)
          .queryParam("mandate",
              extractMandateFromAuthenticateResponse(response, MANDATE_TYPE.toUpperCase()))
          .queryParam("bank_country",
              excel.getValueForCurrentIteration("country").toLowerCase())
          .header("X-Request-ID", randomUUID().toString())
          .post(path).then().log().all().extract().response();
    }

    tokenId = response.jsonPath()
        .getString("tokenId");

    Taf.utils().log().info("Generated tokenId: '" + tokenId + "'");

    if (tokenId == null) {
      Taf.utils().log().error(
          "User not found!\n\t Server response:\n\t "
              + response.then()
              .extract().body().asString());
    }
  }

  @Step("Call api post /oauth2/authorize")
  private static void authorize(String clientId, String redirectUri) {
    Response response = given()
        .filter(new AllureRestAssured())
        .log()
        .all()
        .redirects()
        .follow(false)
        .baseUri(AM_URI)
        .header("Cookie", "tgtcookie=" + tokenId)
        .queryParam("response_type", "code")
        .queryParam("client_id", clientId)
        .queryParam("redirect_uri", redirectUri) //Redirect URI must match with the URI value used in tpp registration
        .queryParam("realm", REALM)
        .queryParam("locale", "et")
        .header("X-Request-ID", randomUUID().toString())
        .get("/oauth2/authorize");

    if (response.getStatusCode() != 302) {
      Taf.utils().log().error(
          "Response status should be 302, but was " + response
              .getStatusCode() + ". Response body '" + response.getBody().prettyPrint() + "'");
    }

    location = response.getHeader("Location");

    if (location == null) {
      Taf.utils().log().error(
          String.format(
              "Was not able to retrieve \"Location\" header from response!\n\t "
                  + "Server responded with:\n\t %s",
              response.then()
                  .extract().headers().toString()));
    }
  }

  @Step("Extract access token from api oauth2/access_token")
  private static void extractAccessToken(String clientId, String redirectUri, String tppType,
      String code) {
    Taf.utils().log().info("Extracted code from authorize request: '" + code + "'");

    Response response =
        given()
            .filter(new AllureRestAssured())
            .log()
            .all()
            .redirects()
            .follow(false)
            .baseUri(OPENAM_URI)
            .basePath(OPENAM_PATH)
            .contentType("application/x-www-form-urlencoded")
            .config(newConfig().sslConfig(getSslConfig(tppType)))
            .queryParam("realm", REALM)
            .queryParam("client_id", clientId)
            .queryParam("grant_type", GRANT_TYPE)
            .queryParam("code", code)
            .queryParam("redirect_uri", redirectUri)
            .post("/oauth2/access_token");

    if (response.getStatusCode() != 200) {
      Taf.utils().log().error(
          "Response status should be 200, but was " + response
              .getStatusCode() + ". Response body '" + response.getBody().prettyPrint() + "'");
    }

    accessToken = response.then()
        .extract()
        .jsonPath()
        .getString("access_token");

    if (accessToken == null) {
      Taf.utils().log().error(
          "Was not able to retrieve accessToken!\n\t Server responded with:\n\t "
              + response.then()
              .extract().body().asString());
    } else {
      Taf.utils().log().info("User successfully authorized. Access token: " + accessToken);
    }
  }

  @Step("Extract code from header")
  private static String extractCodeFormHeader() {
    List<NameValuePair> params;
    try {
      params = URLEncodedUtils.parse(new URI(location), StandardCharsets.UTF_8);
    } catch (URISyntaxException e) {
      throw new FrameworkException("Failed to parse location header. " + e.getMessage());
    }
    return params.stream()
        .filter(x -> x.getName().equals("code"))
        .findFirst()
        .orElseThrow(() -> new FrameworkException("Failed to extract code from Location header"))
        .getValue();
  }

  @Step("Extract mandate from response")
  private static String extractMandateFromAuthenticateResponse(Response response,
      String mandateType) {
    JsonNode nodeList = response
        .then()
        .extract()
        .body()
        .as(AuthenticationResponse.class)
        .getCallbacks()
        .stream()
        .filter(x -> x.getType().equals("ChoiceCallback"))
        .findFirst()
        .orElseThrow(() -> new FrameworkException(
            "Response body '" + response.getBody().prettyPrint() + "'"))
        .getOutput()
        .stream()
        .filter(x -> x.getName().equals("choices"))
        .findFirst()
        .orElseThrow(
            () -> new FrameworkException(
                "Response body '" + response.getBody().prettyPrint() + "'"))
        .getValue();

    List<String> mandateList = null;
    try {
      mandateList = (Arrays
          .asList(new ObjectMapper().readValue(nodeList.toString(), String[].class)));
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }
    return mandateList.stream().filter(x -> {
      try {
        return new ObjectMapper().readValue(x, Value.class).getCustomerType().equals(mandateType);
      } catch (JsonProcessingException e) {
        e.printStackTrace();
      }
      return false;
    }).findFirst()
        .map((Function<? super String, ? extends String>) x -> {
          try {
            return new ObjectMapper().readValue(x, Value.class).getMandateId();
          } catch (JsonProcessingException e) {
            e.printStackTrace();
          }
          return null;
        }).get();
  }

  @Step("Open /oauth2/authorize web page")
  private static AuthPage openPsd2AuthPage(String bankCountry, String clientId) {
    String methodRef = getMethodRef();
    URIBuilder builder = new URIBuilder();
    builder
        .setHost(AM_URI)
        .setPath("/oauth2/authorize")
        .addParameter("realm", REALM)
        .addParameter("bank_country", bankCountry)
        .addParameter("client_id", clientId)
        .addParameter("redirect_uri", REDIRECT_URI)
        .addParameter("response_type", "code")
        .addParameter("state", "ttr2TU")
        .addParameter("locale", "en")
        .addParameter("inf_logo_label", "inf_logo_value")
        .addParameter("auth_method_reference", methodRef);

    Selenide.closeWebDriver();

    Taf.web().browser().open(builder.toString().substring(2));

    return new AuthPage();
  }

  @Step("Select method reference")
  private static String getMethodRef(){
    String authMethod = excel.getValueForCurrentIteration("authMethod");
    String result = "";

    if(authMethod.contains("SmartId")){
      result = excel.getValueForCurrentIteration("authMethodRef");
    }

    if(authMethod.contains("MobileId")){
      result = excel.getValueForCurrentIteration("mobileNumber");
    }

    return result;
  }

  private static AuthPage login(){
    return new AuthPage()
        .setLoginDetails()
        .pressLoginButton();
  }

  @Step("Login to application via browser")
  public static TransactionHistoryPage loginToSignTransactionHistory(){
    login().selectCustomerForTransactionSigning();

    return new TransactionHistoryPage();
  }


}