package com.luminor.utils.enums;

public enum AuthTypes {
  Api,
  Web;
}
