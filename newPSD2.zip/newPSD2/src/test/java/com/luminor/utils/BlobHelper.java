package com.luminor.utils;

import com.luminor.api.models.blob.BlobModel;
import io.qameta.allure.Step;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class BlobHelper {

  @Step("Get first valid blob, at least 24h or if not found get oldest inserted blob")
  public static BlobModel getFirst24hValidBlob(List<BlobModel> blobList) {
    Stream<BlobModel> filteredList = blobList.stream().filter(blob -> {
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
      LocalDateTime blobDate = LocalDateTime.parse(blob.getDate(), formatter);
      LocalDateTime now = LocalDateTime.now();

      Duration duration = Duration.between(now, blobDate);
      long diff = Math.abs(duration.toDays());

      return diff >= 1;
    });

    return filteredList.findFirst().orElse(getOldestBlob(blobList));
  }

  @Step("Get latest inserted blob")
  public static BlobModel getLatestBlob(List<BlobModel> blobList) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    Optional<BlobModel> optionalBlob = blobList.stream()
        .max(Comparator.comparing(item -> LocalDateTime.parse(item.getDate(), formatter)));
    BlobModel result = optionalBlob.get();
    return result;
  }

  @Step("Get oldest inserted blob")
  public static BlobModel getOldestBlob(List<BlobModel> blobList) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    Optional<BlobModel> optionalBlob = blobList.stream()
        .min(Comparator.comparing(item -> LocalDateTime.parse(item.getDate(), formatter)));
    BlobModel result = optionalBlob.get();
    return result;
  }
}
