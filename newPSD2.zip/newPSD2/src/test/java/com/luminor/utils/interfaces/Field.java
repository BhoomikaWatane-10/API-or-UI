package com.luminor.utils.interfaces;

public interface Field {

  void setValue(String value);
}
