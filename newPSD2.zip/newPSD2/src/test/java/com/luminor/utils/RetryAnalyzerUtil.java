package com.luminor.utils;

import com.luminor.taf.Taf;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryAnalyzerUtil implements IRetryAnalyzer {

  private int retryCount = 0;
  private int maxRetryCount = Taf.utils().config().getIntPropertyValue("test.retry.attempts");

  public boolean retry(ITestResult result) {
    if (retryCount < maxRetryCount) {
      retryCount++;
      return true;
    }
    return false;
  }
}
