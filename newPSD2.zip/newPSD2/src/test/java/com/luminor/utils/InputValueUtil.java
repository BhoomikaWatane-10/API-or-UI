package com.luminor.utils;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.Keys;

public class InputValueUtil {

  public static void setInputValue(SelenideElement inputElement, String value) {
    int length = inputElement.getValue().length();
    for (int i = 0; i < length + 1; i++) {
      inputElement.sendKeys(Keys.BACK_SPACE);
    }
    inputElement.sendKeys(value);
  }
}
