package com.luminor.utils.enums;

import com.luminor.utils.interfaces.Radio;

public enum AuthMethodOptions implements Radio {
  SmartId("0"),
  MobileId("1"),
  CardId("2");

  private String value;

  AuthMethodOptions(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}