package com.luminor.utils.interfaces;

public interface Radio {

  String getValue();
}
