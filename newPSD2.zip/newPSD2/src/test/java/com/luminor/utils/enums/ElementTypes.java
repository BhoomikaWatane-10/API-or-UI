package com.luminor.utils.enums;

public enum ElementTypes {
  Id,
  Name,
  For
}
