package com.luminor.utils;

import com.luminor.taf.Taf;

public class RandomValueGenerator {

  public static String generateRandomValueWithinRange(int minNumber, int maxNumber) {
    return String
        .valueOf((Taf.utils().numbers()
            .getRandomNumberInRange(minNumber, maxNumber)));
  }
}