package com.luminor.utils.types;

import static com.codeborne.selenide.Selenide.$$;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.luminor.utils.interfaces.Field;
import com.luminor.utils.interfaces.Radio;
import io.qameta.allure.Step;

public class RadioField implements Field {

  Radio[] radioConstants;
  ElementsCollection radioElements;

  public RadioField(String name, Radio[] radio) {
    this.radioConstants = radio;
    this.radioElements = $$("input[name*='" + name + "']");
  }

  @Step("Select radio button, name: {0}")
  public void setValue(String radioName) {
    //remove empty space in string
    radioName = radioName.replaceAll("\\s+", "");

    for (Radio radioConstant : radioConstants) {
      if (radioConstant.toString().equals(radioName)) {
        String value = radioConstant.getValue();

        for (SelenideElement radio : radioElements) {
          if (radio.has(Condition.value(value))) {
            radio.parent().click();
            break;
          }
        }
        break;
      }
    }
  }
}