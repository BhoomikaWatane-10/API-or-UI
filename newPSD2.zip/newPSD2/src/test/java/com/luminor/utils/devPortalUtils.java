package com.luminor.utils;

import com.codeborne.selenide.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.api.pojo.consents.ConsentCreationPayload;
import com.luminor.taf.Taf;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import static com.codeborne.selenide.Selenide.*;

public class devPortalUtils {
    SelenideElement ExploreSymbol = $x("//div[@role='button']/span");
    SelenideElement agreeButton = $x("//*[text()='AGREE']");
    SelenideElement ibanValue = $x("//span[text()='\"iban\"']//following-sibling::span[@class='ace_string']");

    // click on the object
    public boolean clickOn(SelenideElement element, String objectName) {

        boolean flag = false;

        try {
            if (element.shouldBe(Condition.visible.because(objectName + " should be displayed")).exists()) {
                // scrollToViewElement(element);
                element.click();
                flag = true;


                Taf.utils().log().info("element is not displayed");
            } else {

                Assert.assertTrue(false);

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        if (flag)
            return true;
        else
            return false;
    }

    // enter the text in the field
    public void setText(SelenideElement element, String objectName, String valueToEnter) {
        try {

            if (element.shouldBe(Condition.visible.because(objectName + " should be displayed")).exists()) {
                // element.click();
                element.clear();

                sleep(2000);
                element.sendKeys(valueToEnter);
                String actualValue = element.getAttribute("value");

                if (actualValue.equalsIgnoreCase(valueToEnter)) {
                    Assert.assertEquals(actualValue, valueToEnter);
                    System.out.println(actualValue);
                    System.out.println(valueToEnter);
                    Taf.utils().log().info("value entered" + valueToEnter);

                } else
                    Taf.utils().log().info("value not entered");

            } else {
                Taf.utils().log().info("value not entered");
            }

        } catch (Exception ex) {
            ex.printStackTrace();

        }
    }

    // enter the text in the field
    public void clearElement(SelenideElement element, String objectName) {
        try {
            Thread.sleep(1000);
            if ((element).exists()) {
                element.clear();

                String actualValue = element.getAttribute("value");

            } else {
                Taf.utils().log().info("value not entered");

            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public String getText(SelenideElement element, String objectName) {
        String currentMsg = "";

        try {

            currentMsg = element.getText();

        } catch (Exception e) {

            e.printStackTrace();
        }
        return currentMsg;
    }

    public void clickOnUsingTxt(String text) {
        // String xpathValue="";
        SelenideElement element = $x("//*[text()='" + text + "']");
        try {
            if (text != null) {
                if (element.shouldBe(Condition.visible.because(text + " is displayed")).exists())
                    element.click();

                Assert.assertTrue(true, "xpath is present and clicked.");

            } else {

                Assert.assertTrue(false, "value is not present");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void clickOnExploreSymbol() {

        clickOn(ExploreSymbol, "ExploreSymbol");

    }

    public void selectElementFromList(String element, String objectName, String valueToSelect) {
        String ValueToSelectfromList = "";

        try {

            List<WebElement> select = WebDriverRunner.getWebDriver().findElements(By.xpath(element));
            for (int i = 1; i <= select.size(); i++) {
                System.out.println(select.size());
                WebElement elementTobeSelected = $x(element + "[" + i + "]");
                if ((elementTobeSelected.isDisplayed())) {

                    ValueToSelectfromList = elementTobeSelected.getText();
                    System.out.println(ValueToSelectfromList);
                    if (ValueToSelectfromList.equalsIgnoreCase(valueToSelect)) {
                        elementTobeSelected.click();
                        Assert.assertTrue(true, valueToSelect);

                        break;
                    }

                    sleep(3000);

                } else

                    Taf.utils().log().info(ValueToSelectfromList + " is not selected.");


            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public String getValueFromList(SelenideElement element) {
        return (element).getAttribute("value");
    }

    public void agreeButton() {
        if (agreeButton.isDisplayed()) {
            agreeButton.click();
        } else {

        }
    }

    public String getValueByXpath(String value, String type) {
        String xpathValue = "";
        //  if ((By.xpath("//*[text()='\"" + value + "\"']//following-sibling::span[@class='" + type + "']")).)
        xpathValue = WebDriverRunner.getWebDriver()
                .findElement(
                        By.xpath("//*[text()='\"" + value + "\"']//following-sibling::span[@class='" + type + "']"))
                .getText();
        if (xpathValue != null) {
            Taf.utils().log().info("Value of " + value + " is:" + xpathValue);
            Assert.assertTrue(true, "value is present");
            return xpathValue;
        } /*else {
            Taf.utils().log().error("value is not present");
            Assert.assertTrue(false, "value is not present");
       // }*/
        return xpathValue;
    }


    public void openLinkInNewTab(String link) {
        link = link.replaceAll("^\"+|\"+$", "");
        System.out.println(link);
        WebDriverRunner.getWebDriver().findElement(By.tagName("body")).sendKeys(Keys.CONTROL + "t");

        Set<String> windowHandles = WebDriverRunner.getWebDriver().getWindowHandles();

        System.out.println(windowHandles.size());

        for (String winHandle : WebDriverRunner.getWebDriver().getWindowHandles()) {

            WebDriverRunner.getWebDriver().switchTo().window(winHandle);

        }

        WebDriverRunner.getWebDriver().navigate().to(link);
    }

    public void getConsentData(String iban) throws JsonProcessingException {
        // String iban=getaccount.getAccountList(reqSpec);
        System.out.println(iban);
        ConsentCreationPayload body = new ConsentCreationPayload(iban);

        ObjectMapper object = new ObjectMapper();
        String myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(body);
        System.out.println(myData);

        WebElement ele_acct = WebDriverRunner.getWebDriver().findElement(By.xpath("//textarea[@class='ace_text-input']"));
        // common.waitForvisible(ele_acct){
        //	sleep(20000);
        ele_acct.sendKeys(Keys.CONTROL + "A");
        sleep(5000);
        ele_acct.sendKeys(Keys.DELETE);
        //ele_acct.click();
        sleep(2000);


   /* Toolkit toolkit = Toolkit.getDefaultToolkit();
    sleep(5000);
    Clipboard clipboard = toolkit.getSystemClipboard();
    sleep(2000);
 */   /*String result = "";
    try {
        result = (String) clipboard.getData(DataFlavor.stringFlavor);
       sleep(2000);
    } catch (UnsupportedFlavorException e1) {

        e1.printStackTrace();
    } catch (IOException e1) {
*/
      /*  e1.printStackTrace();
    }*/
        sleep(2000);
        // write for loop logic to replace text
        // String str = result.replace("", myData);
        // ele_acct.click();
        //System.out.println(str);
        //ele_acct.sendKeys(str);

        ele_acct.sendKeys(myData);

    }


    public void setAccountnoInBodyParam(String AccountNo) {
        //  WebElement e = ibanValue;
        AccountNo = "\"" + AccountNo + "\"";
        String no = ibanValue.getText();

        if ((ibanValue).isDisplayed()) {

            System.out.println(AccountNo);

            WebElement ele_acct = WebDriverRunner.getWebDriver().findElement(By.xpath("//textarea[@class='ace_text-input']"));
            // common.waitForvisible(ele_acct){
            sleep(20000);
            ele_acct.sendKeys(Keys.CONTROL + "A");
            sleep(5000);
            ele_acct.sendKeys(Keys.CONTROL + "C");
            sleep(5000);
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            sleep(5000);
            Clipboard clipboard = toolkit.getSystemClipboard();
            sleep(5000);
            String result = "";
            try {
                result = (String) clipboard.getData(DataFlavor.stringFlavor);
                sleep(5000);
            } catch (UnsupportedFlavorException e1) {

                e1.printStackTrace();
            } catch (IOException e1) {

                e1.printStackTrace();
            }
            sleep(20000);
            // write for loop logic to replace text
            String str = result.replace(no, AccountNo);

            ele_acct.sendKeys(str);

        }
    }
}