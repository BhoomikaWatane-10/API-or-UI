package com.luminor.utils;

import com.luminor.api.certificates.Testapp;
import com.luminor.api.certificates.tpp.Aisp;
import com.luminor.api.certificates.tpp.Aspsp;
import com.luminor.api.certificates.tpp.Piisp;
import com.luminor.api.certificates.tpp.Pisp;
import com.luminor.taf.Taf;
import io.restassured.config.SSLConfig;
import java.security.KeyStore;
import org.apache.http.conn.ssl.SSLSocketFactory;

public class SslConfigUtils {

  public static SSLConfig getSslConfig(String tppType) {
    SSLSocketFactory clientAuthFactory = null;
    try {
      clientAuthFactory = new SSLSocketFactory(getKeyStore(tppType), "changeit");
    } catch (Exception e) {
      e.printStackTrace();
    }
    return new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
  }

  private static KeyStore getKeyStore(String appName) throws Exception {
    KeyStore keyStore = null;
    Taf.utils().log().debug("Fetching keyStore based on application '" + appName + "' certificate");
    switch (appName) {
      case "testapp":
        keyStore = Testapp.getKeystore();
        break;
      case "aisp":
        keyStore = Aisp.getKeystore();
        break;
      case "aspsp":
        keyStore = Aspsp.getKeystore();
        break;
      case "piisp":
        keyStore = Piisp.getKeystore();
        break;
      case "pisp":
        keyStore = Pisp.getKeystore();
        break;
      default:
        throw new IllegalStateException("Unsupported certificate for application: " + appName);
    }
    return keyStore;
  }
}