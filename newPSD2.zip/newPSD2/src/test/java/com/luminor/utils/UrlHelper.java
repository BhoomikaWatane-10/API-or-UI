package com.luminor.utils;

import com.luminor.taf.Taf;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;

public class UrlHelper {

  public static String getValueFromUrl(String parameterName) {
    String currentUrl = Taf.web().browser().getCurrentUrl();
    String value = "";

    try {
      URI uri = new URI(currentUrl);
      List<NameValuePair> parameters = URLEncodedUtils
          .parse(uri.getQuery(), StandardCharsets.UTF_8);

      for (NameValuePair parameter : parameters) {
        if (parameter.getName().equals(parameterName)) {
          value = parameter.getValue();
          break;
        }
      }

    } catch (Exception ex) {
    }

    return value;
  }
}
