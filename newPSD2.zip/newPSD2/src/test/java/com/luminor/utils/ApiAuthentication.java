package com.luminor.utils;

import static io.restassured.RestAssured.given;
import static io.restassured.config.EncoderConfig.encoderConfig;

import com.luminor.api.pojo.ccc.AuthenticationResponse;
import com.luminor.taf.Taf;
import com.luminor.taf.utils.Config;
import com.luminor.taf.utils.ConfigApi;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class ApiAuthentication {

  private static ConfigApi config = Taf.utils().config();

  public static void setAuthToken() {
    AuthenticationResponse authResponse = getToken();
    Taf.api().rest().addHeader("Authorization", "Bearer " + authResponse.getIdToken());
    Taf.api().rest().addHeader("MS-TOKEN", authResponse.getAccessToken());
  }

  public static AuthenticationResponse getToken() {
    return given()
        .filter(new AllureRestAssured())
        .config(RestAssured.config().encoderConfig(
            encoderConfig().encodeContentTypeAs("application/text/html", ContentType.JSON)))
        .baseUri(config.getEnvironmentProperty("api.azure.url"))
        .formParam("grant_type", "password")
        .formParam("client_id", config.getEnvironmentProperty("api.azure.client.id"))
        .formParam("client_secret", config.getEnvironmentProperty("api.azure.client.secret"))
        .formParam("scope", "openid profile  User.Read")
        .formParam("username", config.getEnvironmentProperty("user"))
        .formParam("password", Config.getInstance().getDecryptedPassword())
        .when()
        .post("/fcf691db-9825-48c1-bb42-f4ec9308b62a/oauth2/v2.0/token")
        .then()
        .statusCode(200)
        .extract()
        .as(AuthenticationResponse.class);
  }
}
