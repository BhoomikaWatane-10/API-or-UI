package com.luminor.pageobjectsDevportal;

import com.codeborne.selenide.*;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.devPortalUtils;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.testng.Assert;

import java.util.Map;

import static com.codeborne.selenide.Selenide.*;

public class DevPortalAPIExplorerPage extends Psd2 {

    devPortalUtils common = new devPortalUtils();
    private static ExcelDataProviderApi excel = Taf.utils().excel();
    /* TPP Registration */
    SelenideElement apiExplorerLnk = $("a[href='#/api-explorer']");
    SelenideElement apiExplorerTxtToVerify = $x("//h2[text()='API Explorer']");

    SelenideElement xRequestID = $x("//*[@id='X-Request-ID']");
    SelenideElement tryItOutButton = $x("//*[text()='Try it out']");
    SelenideElement clientId = $x("//*[text()='\"clientId\"']//following-sibling::span[@class='token string']");
    SelenideElement status = $x("//*[text()='Created']");
    SelenideElement statusSuccess201 = $x("//*[contains(@class,'success')]");
    SelenideElement textAreaBodyParam = $x("//textarea[@class='ace_text-input']");
    /* Get application Status */

    SelenideElement clientIdtext = $x("//*[@id='client_id']");
    SelenideElement verifyActiveStatus = $x("//*[text()='\"status\"']//following-sibling::span[@class='token string']");
    SelenideElement statusSuccess200 = $x("//*[text()='OK']");

    SelenideElement verifyResponseData = $x("//div[@class='Code__code-source___QLclz']");

    SelenideElement formMissingValueButton = $x("//*[text()='Form is missing values']");

    /* User Login Page */
    // SelenideElement loginPageLnk =$x("//h2[text()='Login page']");
    SelenideElement openUserLoginPageLnk = $x("//div[contains(text(),'selected language')]");
    SelenideElement bankCountryButton = $("#bank_country");
    private static String listOfBankCountries = "//ul[@aria-labelledby='bank_country-label']/li";
    SelenideElement languageSelectButton = $("#locale");
    private static String listOfLanguages = "//ul[@aria-labelledby='locale-label']/li";
    SelenideElement languageListOnLuminorPage = $("#lang-select");
    SelenideElement loginButtonOnLuminorPage = $("#idToken7_0");
    SelenideElement inputBoxOfUserOnLuminorPage = $("#idToken4");
    SelenideElement confirmationMsgTxtOnLuminorPage = $("#callback_1");
    SelenideElement confirmButtonOnLuminorPage = $("#idToken3_0");
    SelenideElement logginSuccessfullyMsgTxtOnLuminorPage = $x("//h3[text()='You have logged in successfully']");
    SelenideElement authorizationCodeOnLuminorPage = $x("//span[@class='token plain']");
    SelenideElement accesstokenLnkOnLuminorPage = $("a[href='#/api-explorer/oauth2/getAccessToken']");

    /* Tokens and Customers */
    SelenideElement LoginSymbol = $x("//div[contains(@class,'Avatar__authorized')]");
    SelenideElement tokenLnk = $("a[href='#/tokens']");
    SelenideElement customerButton = $("#selectCustomer");
    SelenideElement AceContent= $x("//div[@class='ace_content']");
    private static String customerList = "//li[@data-value]";
    private static String accounttbl = "//table[@id='scrollable-table-element']//tr/td[1]";
    private static String currencytbl = "//table[@id='scrollable-table-element']//tr/td[2]";
    SelenideElement clientIdtoken = $("#client_id");
    SelenideElement authorizationText = $("#Authorization");


    public boolean verifyxRequestID() {
        // common.clickOn(signUpToTryOut, "signUP to try Out");
        if (xRequestID.shouldBe(Condition.visible.because("Request ID should be displayed")).exists()) {
            String verifyxRequestID = (xRequestID).getText();
            System.out.println(verifyxRequestID);
            if (verifyxRequestID != null) {
                System.out.println(verifyxRequestID);

            }
            // Assert.assertEquals(xRequestID, "");
            return true;
        } else {
            return false;
        }

    }
    public void ClickOnTryItOut(){
        common.clickOn(tryItOutButton, "try It Out button");
    }

    public void newTPPRegistation() {//String linkName

        common.clickOnExploreSymbol();
       apiExplorerLnk.shouldBe(Condition.visible.because("API Explorer Link is displayed")).click();
       sleep(20000);
      String txtValue=  apiExplorerTxtToVerify.shouldBe(Condition.visible.because("API Explorer Link should visible")).getText();
        common.clickOnUsingTxt("TPP registration");
        common.clickOnUsingTxt("Registers new TPP application");
        verifyxRequestID();
        ClickOnTryItOut();
        verifystatus();
        verifyClientID();

    }

    public void getTPPApplicationStatus() {

        common.clickOnExploreSymbol();
        apiExplorerLnk.shouldBe(Condition.visible.because("Explorer Link")).click();
        String txtValue=  apiExplorerTxtToVerify.getText();
        common.clickOnUsingTxt("TPP registration");
        common.clickOnUsingTxt("Get TPP application status");
        ClickOnTryItOut();
        verifyclientIdtext();
        verifyActiveStatus();

    }

    public void updateTPPApplication() {

        common.clickOnExploreSymbol();
        apiExplorerLnk.shouldBe(Condition.visible.because("Explorer Link")).click();
        String txtValue=  apiExplorerTxtToVerify.getText();
        common.clickOnUsingTxt("TPP registration");
        common.clickOnUsingTxt("Update TPP application");
        ClickOnTryItOut();
         verifyclientIdtext();
       verifyTppResponseDataofUpdate();

    }

    public void userLoginPage() {

        common.clickOnExploreSymbol();
        sleep(10000);
        apiExplorerLnk.waitUntil(Condition.visible.because("Explorer Link"),50).isDisplayed();
        sleep(20000);
        apiExplorerLnk.shouldBe(Condition.visible.because("Explorer Link")).click();
       // sleep(20000);
       // String txtValue=  apiExplorerTxtToVerify.waitUntil(Condition.visible.because("API Explorer"),30000).getText();
        sleep(20000);
        common.agreeButton();
      //  Selenide.atBottom();
        common.clickOnUsingTxt("Login page");
        sleep(30000);

        openUserLoginPageLnk.waitUntil(Condition.visible.because("Explorer Link"),5000).isDisplayed();
        openUserLoginPageLnk.shouldBe(Condition.visible.because("Open User Login page Link is displayed")).click();
        sleep(20000);
        verifyclientIdtext();
        bankCountryButton.shouldBe(Condition.visible.because("Open Country is visible")).click();
        selectFromlistOfBankCountries(excel.getValueForCurrentIteration("country"));
        sleep(5000);
        languageSelectButton.shouldBe(Condition.visible.because("Language Select button")).click();
        sleep(5000);
        selectFromlistOfLanguages(excel.getValueForCurrentIteration("language"));
        sleep(5000);
        ClickOnTryItOut();
        getValueOflanguageListOnLuminorPage(excel.getValueForCurrentIteration("language"));
        inputBoxOfUserOnLuminorPage.clear();
        inputBoxOfUserOnLuminorPage.sendKeys(excel.getValueForCurrentIteration("bankUserName"));
        loginButtonOnLuminorPage.click();

        String confirmationMsg = confirmationMsgTxtOnLuminorPage.getText();
        Taf.utils().log().info(confirmationMsg+ " is displayed");
        confirmButtonOnLuminorPage.shouldBe(Condition.visible.because("Confirm button is present")).click();
        sleep(2000);
       String AuthorizationText= authorizationCodeOnLuminorPage.getText();
        Taf.utils().log().info(AuthorizationText+ " is displayed");
        sleep(10000);
        accesstokenLnkOnLuminorPage.click();
        tryItOutButton.shouldBe(Condition.visible.because("Try Out button should be")).click();
        sleep(3000);
             String AccessData = verifyResponseData.getText();
        Taf.utils().log().info(AccessData+ " is displayed");

         }


    public void getListOfAvailableAccounts() {
        LoginSymbol.shouldBe(Condition.visible.because("Loin symbol")).click();
        tokenLnk.shouldBe(Condition.visible.because("Token Link")).click();;
        customerButton.shouldBe(Condition.visible.because("Customer Button")).click();
        sleep(10000);
        getCustomerFromTheList(excel.getValueForCurrentIteration("bankUserName"));
        sleep(10000);
        getAccountValue();
        sleep(10000);
        common.clickOnExploreSymbol();
        apiExplorerLnk.waitUntil(Condition.visible.because("Explorer Link"),50).isDisplayed();
        sleep(20000);
        apiExplorerLnk.shouldBe(Condition.visible.because("Explorer Link")).click();
        // sleep(20000);
         String txtValue=  apiExplorerTxtToVerify.waitUntil(Condition.visible.because("API Explorer"),30000).getText();
        sleep(20000);
        common.agreeButton();

        common.clickOnUsingTxt("List of available accounts");
        common.clickOnUsingTxt("Get list of available accounts");
        ClickOnTryItOut();
        sleep(2000);
        verifyAccountList();
    }

    public boolean verifystatus() {
        // common.clickOn(signUpToTryOut, "signUP to try Out");
        if (status.shouldBe(Condition.visible.because("Status Element is present")).isDisplayed()) {
            String statusSuccess = status.getText();
            String status201 =statusSuccess201.getText();
            System.out.println(statusSuccess);
            System.out.println(status201);
            if ((statusSuccess.equals("Created")) || (status201.equals("201"))) {
                System.out.println(statusSuccess);
                System.out.println(status201);
                Taf.utils().log().info("Response is: " + status201 + " and Status is: " + statusSuccess);
            }
            // Assert.assertEquals(xRequestID, "");
            return true;
        } else
            return false;
    }

    public boolean verifyClientID() {
        // common.clickOn(signUpToTryOut, "signUP to try Out");
        if (clientId.shouldBe(Condition.visible.because("Client Id")).isDisplayed()) {
            String verifyClientID = (clientId).getText();
            System.out.println(verifyClientID);
            if (verifyClientID != null) {
                System.out.println(verifyClientID);
                Taf.utils().log().info(verifyClientID + " Client ID is displayed");
            }
            // Assert.assertEquals(xRequestID, "");
            return true;
        } else
            return false;
    }

    public void verifyclientIdtext() {
        // common.clickOn(signUpToTryOut, "signUP to try Out");
        String verifyClientID = "";
        if (clientIdtext.waitUntil(Condition.visible.because("client ID Exist"),30000).exists()) {
            verifyClientID = (clientIdtext).getText();
            System.out.println(verifyClientID);
            if (verifyClientID != null) {
                System.out.println(verifyClientID);
                Taf.utils().log().info("Client Id is  Exist");

            }
            // Assert.assertEquals(xRequestID, "");

            else
                Taf.utils().log().info("Client Id is not Exist");

        }

    }

   public boolean verifyActiveStatus() {
        // common.clickOn(signUpToTryOut, "signUP to try Out");
        String activeStatus = "";
        String status200 = "";
        if (statusSuccess200.shouldBe(Condition.visible.because("Success Message is displayed")).isDisplayed()) {
            activeStatus = (verifyActiveStatus).getText();
            status200 = (statusSuccess200).getText();
            System.out.println(verifyActiveStatus);
            System.out.println(status200);
            if ((activeStatus.contains("ACTIVE")) || (status200.contains("OK"))) {
                System.out.println(activeStatus);
                System.out.println(status200);
               Taf.utils().log().info("Response is: " + status200 + " and Status is: " + activeStatus);
                Assert.assertTrue(true, activeStatus);
            }
            // Assert.assertEquals(xRequestID, "");
            return true;
        } else
            Taf.utils().log().info("Response is: " + status200 + " and Status is: " + activeStatus);
        return false;
    }

    public boolean verifyTppResponseDataofUpdate() {
        String verifyUpdatedataOfBody = "";
        String verifyUpdateData = "";

        if ((verifyResponseData).shouldBe(Condition.visible.because("Response Data Element")).isDisplayed()) {
            verifyUpdatedataOfBody = AceContent.getText();
            verifyUpdateData =(verifyResponseData).getText();
            System.out.println(verifyUpdateData);
            System.out.println(verifyUpdatedataOfBody);
            if (verifyUpdateData != null) {
                Assert.assertTrue(true);
                Taf.utils().log().info("Data from Body: " + "<br>" + verifyUpdatedataOfBody + "<br>"
                        + "Data From Response: " + "<br>" + verifyUpdateData);

            }
            // Assert.assertEquals(xRequestID, "");
            return true;
        } else
            Assert.assertTrue(false);
        Taf.utils().log().info("Data from Body: " + "<br>" + verifyUpdatedataOfBody + "<br>" + "Data From Response: "
                + "<br>" + verifyUpdateData);
        return false;
    }
    public void selectFromlistOfBankCountries(String selectCountry) {

        common.selectElementFromList(listOfBankCountries, "Bank Country", selectCountry);
    }

    public void selectFromlistOfLanguages(String selectLanguage) {
        // List<WebElement>
        // selectLanguages=driver.findElements(By.xpath(listOfBankCountries));
        common.selectElementFromList(listOfLanguages, "Language Selection", selectLanguage);
    }

    public void getValueOflanguageListOnLuminorPage(String selectLanguage) {
        String languageSelected = common.getValueFromList(languageListOnLuminorPage);
        if (languageSelected.equalsIgnoreCase(selectLanguage)) {
            Taf.utils().log().info
                    ("selected language on Luminor Page is:" + languageSelected);
            Assert.assertEquals(languageSelected, selectLanguage);
        } else
            Taf.utils().log().info
                    ("selected language on Luminor Page is:" + languageSelected);
    }
@Step("get Customer value from the tokens")
    public void getCustomerFromTheList(String username) {
        int listno = WebDriverRunner.getWebDriver().findElements(By.xpath(customerList)).size();
        if (listno > 0) {
            WebDriverRunner.getWebDriver().findElement(By.xpath("//li[@data-value='" + username + "']")).click();
            Taf.utils().log().info(username + "Customer is selected");
        } else {
            Taf.utils().log().info("customer is not selected");
        }
    }

    public void getAccountValue() {

        String AccountNo = "";
       // if (common.waitForvisible(By.xpath(accounttbl))) {
            int accountno = WebDriverRunner.getWebDriver().findElements(By.xpath(accounttbl)).size();
            if (accountno > 0) {
                for (int i = 0; i < accountno; i++) {
                    AccountNo = WebDriverRunner.getWebDriver().findElements(By.xpath(accounttbl)).get(i).getText();
                    System.out.println(AccountNo);

                    Taf.utils().log().info(AccountNo + " Account no. are present for selected customer");
                }
            } else {
                Taf.utils().log().info("Account no not present");
                Assert.assertTrue(false);
            }
       // }

    }

    public boolean verifyAccountList() {

        String verifyUpdateData;
        if (verifyResponseData.shouldBe(Condition.visible.because("Response Data")).isDisplayed()) {

            verifyUpdateData = verifyResponseData.getText();
            System.out.println(verifyUpdateData);

            if (verifyUpdateData != null) {
                Assert.assertTrue(true);
                Taf.utils().log().info("Available Accounts List: " + "<br>" + verifyUpdateData);

            }
            return true;
        } else
            return false;
    }

    public void clickOnLoginSymbol() {
        common.clickOn(LoginSymbol, "Login Symbol");
    }

    public void clickOnTokens() {
        common.clickOn(tokenLnk, "Tokens");
    }

    public void clickOncustomerButton() {
        common.clickOn(customerButton, "Customer list");
    }
    public void ClickOnapiExplorerLnk() {
        common.clickOn(apiExplorerLnk, "API Explorer");
    }
}


