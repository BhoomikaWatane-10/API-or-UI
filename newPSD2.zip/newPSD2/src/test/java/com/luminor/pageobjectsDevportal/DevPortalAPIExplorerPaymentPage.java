package com.luminor.pageobjectsDevportal;

import com.codeborne.selenide.SelenideElement;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.devPortalUtils;
import org.openqa.selenium.By;
import org.testng.Assert;



import static com.codeborne.selenide.Selenide.*;

public class DevPortalAPIExplorerPaymentPage extends Psd2 {
	SelenideElement tppRedirectPrefered = $("#tpp-redirect-preferred");
	private static String tppRedirectPreferedList = "//*[@aria-labelledby='tpp-redirect-preferred-label']/li";
	SelenideElement scaRedirect = $x("//*[text()='\"scaRedirect\"']//following-sibling::span[@class='token punctuation']");
	SelenideElement linkTobeValidatePayment = $x(
			"//*[text()='\"scaRedirect\"']//following::*[text()='\"href\"']//following-sibling::span[@class='token string']");
	devPortalUtils common = new devPortalUtils();
	DevPortalAPIExplorerPage apiexplorer = new DevPortalAPIExplorerPage();
	DevPortalAPIExplorerConsentPage consent = new DevPortalAPIExplorerConsentPage();
	SelenideElement paymentId = $("#paymentId");
	private static ExcelDataProviderApi excel = Taf.utils().excel();

	public void clickOntppRedirectPreferred() {
		common.clickOn(tppRedirectPrefered, "tpp-redirect-preferred");
	}

	public void selectListOfTppRedirectPreferred(String tppRedirectPreferred) {
		common.selectElementFromList(tppRedirectPreferedList, "tpp-Redirect-prefered", tppRedirectPreferred);
	}

	public void initatePayment() throws JsonProcessingException {
		String link = "";
		String valuesToFetch= excel.getValueForCurrentIteration("FieldValuesFromResponse2");
		String Type = excel.getValueForCurrentIteration("StringDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		String tppRedirectPreferred=excel.getValueForCurrentIteration("tppRedirectPreferredTrue");
		apiexplorer.clickOnLoginSymbol();
		apiexplorer.clickOnTokens();
		apiexplorer.clickOncustomerButton();
		apiexplorer.getCustomerFromTheList(excel.getValueForCurrentIteration("bankUserName"));
		String AccountNo = consent.getAccountNoFromcustomerList();
		/*
		 * common.waitForSync(SMALL_WAIT); common.clickOnExploreSymbol();
		 */
		sleep(10000);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		sleep(10000);
		common.clickOnUsingTxt("Payment initiation and information");
		common.clickOnUsingTxt("Initiate payment");
		clickOntppRedirectPreferred();
		selectListOfTppRedirectPreferred(tppRedirectPreferred);
		sleep(10000);
		common.setAccountnoInBodyParam(AccountNo);
		sleep(10000);
		apiexplorer.ClickOnTryItOut();
		sleep(10000);
		common.getValueByXpath(ValuetoEnter[0], Type);// transactionstatus
		common.getValueByXpath(ValuetoEnter[1], Type);// paymentId
		if ((scaRedirect).isDisplayed()) {
			if ((linkTobeValidatePayment).isDisplayed()) {
				link = common.getText(linkTobeValidatePayment, "scadirect Link");

				common.openLinkInNewTab(link);
				sleep(10000);
//				common.clickOnUsingTxt("Confirm");
				common.clickOnUsingTxt("Sign with Smart-ID");
				sleep(10000);
				common.clickOnExploreSymbol();
				apiexplorer.ClickOnapiExplorerLnk();
				sleep(10000);
				common.clickOnUsingTxt("Payment initiation and information");
			}
		} else {
			Taf.utils().log().info("TPP redirct UI is selected as :" + tppRedirectPreferred + " payment is done by API");
			back();
		}
	}

	public void getPaymentStatus() {
		String valuesToFetch= excel.getValueForCurrentIteration("FieldValuesFromResponse2");
		String type = excel.getValueForCurrentIteration("StringDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		sleep(10000);
		common.clickOnUsingTxt("Get payment status");
		sleep(10000);
		apiexplorer.ClickOnTryItOut();
		sleep(10000);
		if (common.getValueByXpath(ValuetoEnter[0], type).contains("ACSC"))
					Taf.utils().log().info("Payment is sccessful");
		back();
	}

	public void getPaymentFee() {
		String valuesToFetch= excel.getValueForCurrentIteration("FieldValuesFromResponse2");
		String type = excel.getValueForCurrentIteration("StringDataType");
		String noType = excel.getValueForCurrentIteration("NumericDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		sleep(10000);
		common.clickOnUsingTxt("Get payment fee");
		apiexplorer.ClickOnTryItOut();
		common.getValueByXpath(ValuetoEnter[2], noType);
		common.getValueByXpath(ValuetoEnter[3], type);
		back();
	}

	public void getinitiatePaymentAuthorization() {
		String valuesToFetch= excel.getValueForCurrentIteration("FieldValuesFromResponse2");
		String type = excel.getValueForCurrentIteration("StringDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		sleep(20000);
		common.clickOnUsingTxt("Payment authorisation");
		sleep(20000);
		common.clickOnUsingTxt("Initiate payment authorisation");
		sleep(20000);
		apiexplorer.ClickOnTryItOut();
		sleep(20000);
		common.getValueByXpath(ValuetoEnter[5], type);
		common.getValueByXpath(ValuetoEnter[6], type);
		common.getValueByXpath(ValuetoEnter[7], type);
		common.getValueByXpath(ValuetoEnter[8], type);
		back();
	}

	public void getPaymentAuthorization() {
		String valuesToFetch= excel.getValueForCurrentIteration("FieldValuesFromResponse2");
		String noType = excel.getValueForCurrentIteration("NumericDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		sleep(20000);
		common.clickOnUsingTxt("Get payment authorisations");
		sleep(20000);

		apiexplorer.ClickOnTryItOut();
		sleep(20000);

		common.getValueByXpath(ValuetoEnter[9], noType);
		back();
	}

	public void getPaymentAuthorizationDetail() {
		String valuesToFetch= excel.getValueForCurrentIteration("FieldValuesFromResponse2");
		String type = excel.getValueForCurrentIteration("StringDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Get payment authorisation details");
		sleep(20000);

		apiexplorer.ClickOnTryItOut();
		sleep(20000);
		common.getValueByXpath(ValuetoEnter[5], type);// authorisationId
		common.getValueByXpath(ValuetoEnter[6], type);// scaStatus
		common.getValueByXpath(ValuetoEnter[8], type);// authenticationMethodId
		common.getValueByXpath(ValuetoEnter[10], type);// name
		common.getValueByXpath(ValuetoEnter[11], type);// surname
		common.getValueByXpath(ValuetoEnter[12], type);// signatureSchemaType
		common.getValueByXpath(ValuetoEnter[13], type);// created
		//apiexplorer.verifyTppResponseDataofUpdate();
		back();
	}

	public void updatePaymentAuthorizationDetail() {
		String valuesToFetch= excel.getValueForCurrentIteration("FieldValuesFromResponse2");
		String type = excel.getValueForCurrentIteration("StringDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Update payment authorisation details");
		sleep(20000);

		apiexplorer.ClickOnTryItOut();
		sleep(20000);

		common.getValueByXpath(ValuetoEnter[6], type);
		common.getValueByXpath(ValuetoEnter[14], type);
		common.getValueByXpath(ValuetoEnter[15], type);

		apiexplorer.verifyTppResponseDataofUpdate();
		back();
	}

	public void getPaymentAuthorizationStatus() {
		common.clickOnUsingTxt("Get payment authorisation status");

		sleep(20000);
		apiexplorer.ClickOnTryItOut();
		sleep(20000);

		if (common.getValueByXpath("scaStatus", "token string").equals("\"finalised\"")) {
			Taf.utils().log().info("Payment is successful");
		} else {
			for (int i = 0; i < 5; i++) {
				apiexplorer.ClickOnTryItOut();
				sleep(20000);
				// Reporting.test.fail("Payment is not successful" +
				// common.getValueByXpath("scaStatus", "token string"));
				Assert.assertTrue(true);
			}
		}

	}

	public void initatePaymentAPI() throws JsonProcessingException {
			String link = "";
			String valuesToFetch = excel.getValueForCurrentIteration("FieldValuesFromResponse2");
			String Type = excel.getValueForCurrentIteration("StringDataType");
			String[] ValuetoEnter = valuesToFetch.split(";");
			String tppRedirectPreferred = excel.getValueForCurrentIteration("TppRedirectPreferredFalse");
			apiexplorer.clickOnLoginSymbol();
			apiexplorer.clickOnTokens();
			apiexplorer.clickOncustomerButton();
			apiexplorer.getCustomerFromTheList(excel.getValueForCurrentIteration("bankUserName"));
			String AccountNo = consent.getAccountNoFromcustomerList();

			sleep(10000);
			common.clickOnExploreSymbol();
			apiexplorer.ClickOnapiExplorerLnk();
			sleep(10000);
			common.clickOnUsingTxt("Payment initiation and information");
			common.clickOnUsingTxt("Initiate payment");
			clickOntppRedirectPreferred();
			selectListOfTppRedirectPreferred(tppRedirectPreferred);
			sleep(10000);
			common.setAccountnoInBodyParam(AccountNo);
			sleep(10000);
			apiexplorer.ClickOnTryItOut();
			sleep(10000);
			common.getValueByXpath(ValuetoEnter[0], Type);// transactionstatus
			common.getValueByXpath(ValuetoEnter[1], Type);// paymentId
		back();
		}

	/*public void missingPaymentId(String linkName, String linkname2) {

		String verifyPaymentID = "";
		sleep(20000);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		apiexplorer.verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt(linkname2);
		common.clickOn(paymentId, "Payment ID");
		common.blankBodyParam(paymentId);
		// ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		apiexplorer.visibleFormMissingValueButton();
		verifyPaymentID = driver.findElement(paymentId).getText();
		System.out.println(verifyPaymentID);
		if (verifyPaymentID != "") {
			System.out.println(verifyPaymentID);
			Reporting.test.fail(" Client ID is : " + verifyPaymentID);
			Assert.assertTrue(false);

		} else {
			Reporting.test.pass(" Client ID is blank, cannot proceed.");
		}
	}

*/
}