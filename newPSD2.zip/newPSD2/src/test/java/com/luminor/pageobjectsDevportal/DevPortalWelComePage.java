package com.luminor.pageobjectsDevportal;

import com.codeborne.selenide.SelenideElement;
import com.luminor.Psd2;
import io.qameta.allure.Step;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$x;

public class DevPortalWelComePage extends Psd2 {

    SelenideElement WelcomeLnk = $x("//a[@href='#/welcome']"), WelcomeTxtVerify = $x("//*[text()='Welcome to Luminor developer portal']"),
            ExplorerSymbol=$x("//div[@role='button']/span");

    @Step("Devportal welcome page")
    public DevPortalWelComePage verifyWelcomePage() throws InterruptedException {
    Thread.sleep(5000);
        ExplorerSymbol.shouldBe(visible.because("Welcome Page should displayed")).click();
        Thread.sleep(5000);
        WelcomeLnk.shouldBe(visible.because("Clicked on Welcome Link")).click();
        String welcomeText=WelcomeTxtVerify.getText();
        System.out.println(welcomeText);

        return this;
    }
}
