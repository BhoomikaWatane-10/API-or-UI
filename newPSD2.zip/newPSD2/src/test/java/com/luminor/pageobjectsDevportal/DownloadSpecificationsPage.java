package com.luminor.pageobjectsDevportal;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;

import com.codeborne.selenide.SelenideElement;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.devPortalUtils;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$x;
import static com.codeborne.selenide.Selenide.sleep;


public class DownloadSpecificationsPage extends Psd2 {

	devPortalUtils common = new devPortalUtils();
	DevPortalAPIExplorerPage apiexplorer = new DevPortalAPIExplorerPage();
	private static ExcelDataProviderApi excel = Taf.utils().excel();

	public void downloadSpecificationsforJSON(String linkname) throws IOException {

		String st = "";
		String type = excel.getValueForCurrentIteration("FileTypeJson");

		common.clickOnExploreSymbol();
		sleep(10000);
		apiexplorer.ClickOnapiExplorerLnk();
		common.clickOnUsingTxt(linkname);
		sleep(10000);
		//deleteFile(linkname, type, path);
		SelenideElement downloadSpecificationsLnk = $x("//h2[text()='" + linkname
				+ "']//ancestor::span[@class='Collapsible__trigger is-open']/following-sibling::div//span[text()='Download specification']");
		SelenideElement FileTypeLnk = $x("//h2[text()='" + linkname
				+ "']//ancestor::span[@class='Collapsible__trigger is-open']/following-sibling::div//li[text()='" + type
				+ "']");

		if ((downloadSpecificationsLnk).isDisplayed()) {
			common.clickOn(downloadSpecificationsLnk, "Download specification");
			if ((FileTypeLnk).isDisplayed()) {
				common.clickOn(FileTypeLnk, type);
				sleep(10000);
				Taf.utils().log().info(type + " file is downloaded for" + linkname);
			}
		}
			/*String ext = type.toLowerCase();
			File file = new File(path + "\\" + linkname + "." + ext);
			if (file.exists() && !file.isDirectory()) {
				String FileName = file.getName();
				Taf.utils().log().info(FileName + " is downloaded.Path is :" + file.toString());
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				Taf.utils().log().info("timestamp of the downloaded file: " + sdf.format(file.lastModified()));

				BufferedReader br = new BufferedReader(new FileReader(file));
				Taf.utils().log().info("Data From File:  ");
				try {

					while ((st = br.readLine()) != null)
						// st=br.readLine();
						// st=""+st;
						Taf.utils().log().info(st);

				} catch (FileNotFoundException e) {

					Taf.utils().log().info("File data is not present.");
					e.printStackTrace();
				}

				try {

					br.close();

				} catch (IOException e) {

					e.printStackTrace();
				}*/
		else {
			Taf.utils().log().info("File is not Exist.");
		}


		/*else {
			Taf.utils().log().info("Download spcification is not present for " + linkname);
		}*/
	}
		public void downloadSpecificationsforYAML(String linkname) throws IOException {

			String st = "";
			String type =excel.getValueForCurrentIteration("FileTypeYaml");

			common.clickOnExploreSymbol();
			sleep(10000);
			apiexplorer.ClickOnapiExplorerLnk();
			sleep(5000);
			common.clickOnUsingTxt(linkname);

			//deleteFile(linkname, type, path);
			SelenideElement downloadSpecificationsLnk = $x("//h2[text()='" + linkname
					+ "']//ancestor::span[@class='Collapsible__trigger is-open']/following-sibling::div//span[text()='Download specification']");
			SelenideElement FileTypeLnk =$x("//h2[text()='" + linkname
					+ "']//ancestor::span[@class='Collapsible__trigger is-open']/following-sibling::div//li[text()='" + type
					+ "']");

			if ((downloadSpecificationsLnk).isDisplayed()) {
				common.clickOn(downloadSpecificationsLnk, "Download specification");
				if ((FileTypeLnk).isDisplayed()) {
					common.clickOn(FileTypeLnk, type);
					sleep(10000);
					Taf.utils().log().info(type + " file is downloaded for" + linkname);
				}
			}
			/*String ext = type.toLowerCase();
			File file = new File(path + "\\" + linkname + "." + ext);
			if (file.exists() && !file.isDirectory()) {
				String FileName = file.getName();
				Taf.utils().log().info(FileName + " is downloaded.Path is :" + file.toString());
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				Taf.utils().log().info("timestamp of the downloaded file: " + sdf.format(file.lastModified()));

				BufferedReader br = new BufferedReader(new FileReader(file));
				Taf.utils().log().info("Data From File:  ");
				try {

					while ((st = br.readLine()) != null)
						// st=br.readLine();
						// st=""+st;
						Taf.utils().log().info(st);

				} catch (FileNotFoundException e) {

					Taf.utils().log().info("File data is not present.");
					e.printStackTrace();
				}

				try {

					br.close();

				} catch (IOException e) {

					e.printStackTrace();
				}*/
			else {
				Taf.utils().log().info("File is not Exist.");
			}


		/*else {
			Taf.utils().log().info("Download spcification is not present for " + linkname);
		}*/

	}

	/*public void deleteFile(String linkname, String type, String path) {
		String ext = type.toLowerCase();
		File file = new File(path + "\\" + linkname + "." + ext);
		if (file.exists() && !file.isDirectory()) {
			file.delete();
		}
	}*/
}