package com.luminor.pageobjectsDevportal;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import io.qameta.allure.Step;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class DevPortalLoginPage extends Psd2 {

  SelenideElement LogInButton = $x("//button[text()='LOG IN']"), UserName = $("#inputUserName"),
          Password = $("#inputPassword"), LogInButtonUser = $x("//button[@type='submit']"),
          lnkHowToAPI = $x("//a[text()='How to APIs']"), WelcomeText = $x("//*[text()='Welcome to']"),
          LogOutButton = $x("//button[text()='LOGOUT']");SelenideElement LoginSymbol = $x("//div[contains(@class,'Avatar__authorized')]");



  @Step("Set Login detail on devportal login page")
  public DevPortalLoginPage setLoginDetails() {
    if(LoginSymbol.isDisplayed()) {
        Taf.utils().log().info("Already Logged In");
    }
    else {
      LogInButton.shouldBe(visible.because("Devportal Login should be displayed"));
      LogInButton.shouldBe(visible.because("Devportal Login Page")).click();
      UserName.sendKeys(Taf.utils().excel().getValueForCurrentIteration("username"));//Taf.utils().excel().getValueForCurrentIteration("username"));
      Password.sendKeys(Taf.utils().excel().getValueForCurrentIteration("password"));//Taf.utils().excel().getValueForCurrentIteration("personalCode"));
      LogInButtonUser.click();
      WelcomeText.shouldBe(visible.because("WelcomeText should be displayed")).isDisplayed();
      sleep(20000);


    }
    return this;
  }
    public void closeWindow(){
      WebDriverRunner.getWebDriver().close();
    }
  }


