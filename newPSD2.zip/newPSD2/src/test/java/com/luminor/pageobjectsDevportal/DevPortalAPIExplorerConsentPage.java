package com.luminor.pageobjectsDevportal;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.DevPortalCalenderUtil;
import com.luminor.utils.devPortalUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;



import static com.codeborne.selenide.Selenide.*;

/**
 * @author Bhoomika
 *
 */
public class DevPortalAPIExplorerConsentPage extends Psd2 {

	SelenideElement tryItOutButton = $x("//*[text()='Try it out']");
	SelenideElement verifyResponseData = $x("//div[@class='Code__code-source___QLclz']");
	SelenideElement consentId = $("#consentId");
	SelenideElement accountId = $("#accountId");
	private static ExcelDataProviderApi excel = Taf.utils().excel();
	/* Get consent authorisations details */

	SelenideElement authenticationMethodId = $x("//*[text()='\"authenticationMethodId\"']//following-sibling::span[@class='token string']");

	/* Account Information */

	SelenideElement getAccountswithinUsersConsentLnk = $x("//*[text()=\"Get accounts within user's consent\"]");

	SelenideElement ResourceIdaccountIdTxt = $("#accountId");

	SelenideElement toDate = $("#dateTo");
	SelenideElement fromDate = $("#dateFrom");
	SelenideElement tppRedirectPrefered = $("#tpp-redirect-preferred");
	private static String tppRedirectPreferedList = "//*[@aria-labelledby='tpp-redirect-preferred-label']/li";
	SelenideElement scaRedirect = $x("//*[text()='\"scaRedirect\"']//following-sibling::span[@class='token punctuation']");
	SelenideElement linkTobeValidatePayment = $x(
			"//*[text()='\"scaRedirect\"']//following::*[text()='\"href\"']//following-sibling::span[@class='token string']");
	private static String accounttbl = "//table[@id='scrollable-table-element']//tr/td[1]";
	private static String currencytbl = "//table[@id='scrollable-table-element']//tr/td[2]";

	//SelenideElement validUntil = $x("//span[text()='\"validUntil\"']//following-sibling::span[@class='ace_string']");

	devPortalUtils common = new devPortalUtils();
	DevPortalAPIExplorerPage apiexplorer = new DevPortalAPIExplorerPage();
	DevPortalCalenderUtil calender = new DevPortalCalenderUtil();

	public void getConsentIdTxt() {
		common.getText(consentId, "Consent Id");
	}

	public boolean  verifyGetConsentDetailsData() {

		String verifyUpdateData;
		if (verifyResponseData.shouldBe(Condition.visible.because("Response Data")).isDisplayed()) {

			verifyUpdateData = verifyResponseData.getText();
			System.out.println(verifyUpdateData);

			if (verifyUpdateData != null) {
				Assert.assertTrue(true);
				Taf.utils().log().info("Available Accounts List: " + "<br>" + verifyUpdateData);

			}
			return true;
		} else
			return false;
	}


	public void getScaStatus() {
		String status = common.getValueByXpath("scaStatus", "token string");
		if (status.contains("finalised")) {
			Taf.utils().log().info("authorization of Consent is " + status);
			Assert.assertTrue(true);
		} else {
			Taf.utils().log().error("authorization of Consent is no successful");
			Assert.assertTrue(false);
		}
	}

	public void getstartedScaStatus() {
		String status = common.getValueByXpath("scaStatus", "token string");
		if (status.contains("started")) {
			Taf.utils().log().info("authorization of Consent is " + status);
			Assert.assertTrue(true);
		} else if (status.contains("received")) {
			Taf.utils().log().info("authorization of Consent is " + status);
			Assert.assertTrue(true);
		} else if (status.contains("valid")) {
			Taf.utils().log().info("authorization of Consent is " + status);
			Assert.assertTrue(true);
		} else {
			Taf.utils().log().info("authorization of Consent is not successful");
			Assert.assertTrue(false);
		}
	}

	public void getauthenticationMethodId() {
		common.getText(authenticationMethodId, "Authetication Method Id");
	}

	//duplicate can be vanished
	public boolean verifyAuthorizationDetailsData() {

		String verifyUpdateData;
		if (verifyResponseData.shouldBe(Condition.visible.because("Response Data")).isDisplayed()) {

			verifyUpdateData = verifyResponseData.getText();
			System.out.println(verifyUpdateData);

			if (verifyUpdateData != null) {
				Assert.assertTrue(true);
				Taf.utils().log().info("Available Accounts List: " + "<br>" + verifyUpdateData);

			}
			return true;
		} else
			return false;
	}

	public void clickOngetAccountswithinUsersConsentLnk() {
		common.clickOn(getAccountswithinUsersConsentLnk, "Accounts within user's consent");
	}

	public void setResourceIdAsAccountIdTxt(String value) {

		value = value.replaceAll("^\"+|\"+$", "");
		common.setText(ResourceIdaccountIdTxt, "Account Id", value);
	}

	public void setToDate() {
		toDate.click();
		toDate.clear();
		common.setText(toDate, "To Date", calender.getCurrentDate());
	}

	public void setFromDate() {
		fromDate.click();
		fromDate.clear();

		common.setText(fromDate, "From Date", calender.getPreviousDate());
	}

	public void clickOntppRedirectPreferred() {
		common.clickOn(tppRedirectPrefered, "tpp-redirect-preferred");
	}

	public void getListOfTppRedirectPreferred(String tppRedirectPreferred) {
		common.selectElementFromList(tppRedirectPreferedList, "tpp-Redirect-preffered", tppRedirectPreferred);
	}

	//to do
	public String getAccountNoFromcustomerList() {
		String AccountNo = "";
		String currency = "";
		int accountno = WebDriverRunner.getWebDriver().findElements(By.xpath(accounttbl)).size();
		if (accountno > 0) {
			for (int i = 0; i < accountno; i++) {
				//common.waitForSync(LONG_WAIT);
				currency = WebDriverRunner.getWebDriver().findElements(By.xpath(currencytbl)).get(i).getText();
				System.out.println(AccountNo);
				if (currency.equals("EUR")) {
					AccountNo = WebDriverRunner.getWebDriver().findElements(By.xpath(accounttbl)).get(i).getText();
					Taf.utils().log().info(AccountNo + " Account No is copied.");
					break;
				}

			}
		}
		return AccountNo;
	}


	public void createConsentViaAPI() throws JsonProcessingException {
		String Type = excel.getValueForCurrentIteration("StringDataType");
		String LinkName =excel.getValueForCurrentIteration("LinkText1");
		String link[] = LinkName.split(";");
		String linkToclicked = "";
		String valuesToFetch=excel.getValueForCurrentIteration("FieldValuesFromResponse1");
		String[] ValuetoEnter = valuesToFetch.split(";");
		apiexplorer.clickOnLoginSymbol();
		apiexplorer.clickOnTokens();
		apiexplorer.clickOncustomerButton();
		apiexplorer.getCustomerFromTheList(excel.getValueForCurrentIteration("bankUsernameForConsentAuthorization"));
		String AccountNo = getAccountNoFromcustomerList();
		sleep(20000);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		sleep(20000);
		common.clickOnUsingTxt(link[0]);
		common.clickOnUsingTxt(link[1]);
		clickOntppRedirectPreferred();
		sleep(20000);
		getListOfTppRedirectPreferred(excel.getValueForCurrentIteration("TppRedirectPreferredFalse"));
		sleep(20000);
		//setAccountnoInBodyParam(AccountNo);
		common.getConsentData(AccountNo);
		apiexplorer.ClickOnTryItOut();


		sleep(20000);
		if ((scaRedirect).isDisplayed()) {
			if ( (linkTobeValidatePayment).isDisplayed()) {
				linkToclicked = common.getText(linkTobeValidatePayment, "scadirect Link");

				common.openLinkInNewTab(linkToclicked);
				sleep(20000);
				// common.clickOnUsingTxt("Confirm");
				common.clickOnUsingTxt("Sign with Smart-ID");
				sleep(10000);
				common.clickOnExploreSymbol();
				apiexplorer.ClickOnapiExplorerLnk();
				common.clickOnUsingTxt(link[0]);
			}
		} else {
			apiexplorer.verifyxRequestID();
			common.getValueByXpath(ValuetoEnter[0], Type);
			common.getValueByXpath(ValuetoEnter[1], Type);
			back();


		}

	}
	public void createConsentViaUI() throws JsonProcessingException {
		String Type = excel.getValueForCurrentIteration("StringDataType");
		String LinkName =excel.getValueForCurrentIteration("LinkText1");
		String link[] = LinkName.split(";");
		String linkToclicked = "";
		String valuesToFetch=excel.getValueForCurrentIteration("FieldValuesFromResponse1");
		String[] ValuetoEnter = valuesToFetch.split(";");
		apiexplorer.clickOnLoginSymbol();
		apiexplorer.clickOnTokens();
		apiexplorer.clickOncustomerButton();
		apiexplorer.getCustomerFromTheList(excel.getValueForCurrentIteration("bankUsernameForConsentAuthorization"));
		String AccountNo = getAccountNoFromcustomerList();
		sleep(20000);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		sleep(20000);
		common.clickOnUsingTxt(link[0]);
		common.clickOnUsingTxt(link[1]);
		clickOntppRedirectPreferred();
		sleep(20000);
		getListOfTppRedirectPreferred(excel.getValueForCurrentIteration("tppRedirectPreferredTrue"));
		sleep(20000);
		//setAccountnoInBodyParam(AccountNo);
		common.getConsentData(AccountNo);
		apiexplorer.ClickOnTryItOut();


		sleep(20000);
		if ((scaRedirect).isDisplayed()) {
			if ( (linkTobeValidatePayment).isDisplayed()) {
				linkToclicked = common.getText(linkTobeValidatePayment, "scadirect Link");

				common.openLinkInNewTab(linkToclicked);
				sleep(20000);
				 common.clickOnUsingTxt("Confirm");
				//common.clickOnUsingTxt("Sign with Smart-ID");
				sleep(10000);
				common.clickOnExploreSymbol();
				apiexplorer.ClickOnapiExplorerLnk();
				common.clickOnUsingTxt(link[0]);
			}
		} else {
			apiexplorer.verifyxRequestID();
			common.getValueByXpath(ValuetoEnter[0], Type);
			common.getValueByXpath(ValuetoEnter[1], Type);
			back();


		}

	}

	public void getConsentDetails() {
		String valuesToFetch=excel.getValueForCurrentIteration("FieldValuesFromResponse1");

		String Type = excel.getValueForCurrentIteration("StringDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Get consent details");
		apiexplorer.ClickOnTryItOut();
		sleep(20000);
		common.getValueByXpath(ValuetoEnter[0], Type);
		common.getValueByXpath(ValuetoEnter[2], Type);
		verifyGetConsentDetailsData();
		sleep(20000);
		back();
	}

	public void geConsentStatus() {
		String valuesToFetch=excel.getValueForCurrentIteration("FieldValuesFromResponse1");
		String Type = excel.getValueForCurrentIteration("StringDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Get consent status");
		sleep(20000);
		apiexplorer.ClickOnTryItOut();
		sleep(20000);
		common.getValueByXpath(ValuetoEnter[1], Type);
		back();
	}

	public void initiateconsentAuthorization() {
		// consent authorization
		common.clickOnUsingTxt("Consent authorisation");
		sleep(20000);
		common.clickOnUsingTxt("Initiate consent authorisation");
		sleep(20000);
		apiexplorer.ClickOnTryItOut();
		back();
	}

	public void getconsentAuthorization() {
		String valuesToFetch=excel.getValueForCurrentIteration("FieldValuesFromResponse1");
		String Type = excel.getValueForCurrentIteration("StringDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Get consent authorisations");
		sleep(20000);
		apiexplorer.ClickOnTryItOut();
		sleep(20000);
		common.getValueByXpath(ValuetoEnter[3], Type);
		// getScaStatus();
		back();
	}

	public void getconsentAuthorizationDetails() {
		String valuesToFetch=excel.getValueForCurrentIteration("FieldValuesFromResponse1");
		String Type = excel.getValueForCurrentIteration("StringDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Get consent authorisation details");
		sleep(20000);
		apiexplorer.ClickOnTryItOut();
		sleep(20000);
		getstartedScaStatus();
		// getauthenticationMethodId();
		common.getValueByXpath(ValuetoEnter[4], Type);
		common.getValueByXpath(ValuetoEnter[5], Type);
		verifyAuthorizationDetailsData();
		back();
	}

	public void updateConsentAuthorizationDetails() {
		String valuesToFetch=excel.getValueForCurrentIteration("FieldValuesFromResponse1");
		String Type = excel.getValueForCurrentIteration("StringDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Update consent authorisation details");
		apiexplorer.ClickOnTryItOut();
		common.getValueByXpath(ValuetoEnter[6], Type);
		getstartedScaStatus();
		back();
	}

	public void getConsentAuthorizationStatus() {

		common.clickOnUsingTxt("Get consent authorisation status");
		sleep(20000);
		apiexplorer.ClickOnTryItOut();
		sleep(20000);
		(tryItOutButton).click();
		sleep(20000);
		(tryItOutButton).click();
		getScaStatus();
		back();
	}

	public void AcoountInformation() {
		String valuesToFetch=excel.getValueForCurrentIteration("FieldValuesFromResponse1");
		String Type = excel.getValueForCurrentIteration("StringDataType");
		String noType = excel.getValueForCurrentIteration("NumericDataType");
		String boolType = excel.getValueForCurrentIteration("BooleanDataType");
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Account information");
		clickOngetAccountswithinUsersConsentLnk(); // 's using so create seperate method
		sleep(20000);
		apiexplorer.ClickOnTryItOut();
		sleep(20000);
		String value = common.getValueByXpath(ValuetoEnter[9], Type);
		common.getValueByXpath(ValuetoEnter[2], Type);
		common.getValueByXpath(ValuetoEnter[7], Type);
		common.getValueByXpath(ValuetoEnter[9], Type);
		back();
		common.clickOnUsingTxt("Get account details");
		setResourceIdAsAccountIdTxt(value);

		apiexplorer.ClickOnTryItOut();
		sleep(20000);
		verifyGetConsentDetailsData();
		common.getValueByXpath(ValuetoEnter[9], Type);// resourceid
		common.getValueByXpath(ValuetoEnter[2], Type);// iban
		common.getValueByXpath(ValuetoEnter[7], Type);// currencyk
		common.getValueByXpath(ValuetoEnter[4], Type);// name
		common.getValueByXpath(ValuetoEnter[10], Type);// product
		common.getValueByXpath(ValuetoEnter[11], Type);// balncetype
		// common.getValueByXpath("creditLimitIncluded");
		back();
		common.clickOnUsingTxt("Get account balances");
		sleep(20000);
		setResourceIdAsAccountIdTxt(value);
		apiexplorer.ClickOnTryItOut();
		common.getValueByXpath(ValuetoEnter[7], Type);// iban
		common.getValueByXpath(ValuetoEnter[7], Type);// currency
		common.getValueByXpath(ValuetoEnter[8], noType);// amount
		common.getValueByXpath(ValuetoEnter[12], boolType);// creditlimitincluded
		back();

		/*common.clickOnUsingTxt("Get account transactions");
		setResourceIdAsAccountIdTxt(value);
		setToDate();
		setFromDate();
		sleep(20000);
		// common.clickOnUsingTxt("Try it out");
		apiexplorer.ClickOnTryItOut();
		sleep(20000);
		*//*if (common.getValueByXpath(ValuetoEnter[13], Type).equals("\"NOT PROVIDED\"")) {
			System.out.println(common.getValueByXpath(ValuetoEnter[13], Type));// endtoendid
			sleep(20000);*//*
		//	apiexplorer.ClickOnTryItOut();
		//	sleep(50000);
		//}
		*//*else {
			Taf.utils().log().info("Response Data is not captured");
			Assert.assertTrue(false);
		}*//*
		common.getValueByXpath(ValuetoEnter[2], Type);// iban
		common.getValueByXpath(ValuetoEnter[7], Type);// currency
		// common.getValueByXpath(ValuetoEnter[13],Type);//transctionid
		common.getValueByXpath(ValuetoEnter[13], Type);// endtoendid
		common.getValueByXpath(ValuetoEnter[8], noType);// amount
		common.getValueByXpath(ValuetoEnter[14], Type);// debatorname
		common.getValueByXpath(ValuetoEnter[15], Type);// debatoraccount
		common.getValueByXpath(ValuetoEnter[16], Type);// bookingdate
		common.getValueByXpath(ValuetoEnter[17], Type);// valuedate
		common.getValueByXpath(ValuetoEnter[18], Type);// currency
		common.getValueByXpath(ValuetoEnter[19], Type);// banktransactioncode
		verifyGetConsentDetailsData();
		back();*/
	}

	public void confirmFundsAvailabilityOnAccount() {
		String Type = excel.getValueForCurrentIteration("StringDataType");
		String noType = excel.getValueForCurrentIteration("NumericDataType");
		String boolType = excel.getValueForCurrentIteration("BooleanDataType");
		String valuesToFetch=excel.getValueForCurrentIteration("FieldValuesFromResponse1");
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Funds Confirmation");
		sleep(20000);
		common.clickOnUsingTxt("Confirm funds availability on account");

		String amount = common.getValueByXpath("amount", "ace_constant ace_numeric");
		double amt = Double.parseDouble(amount);
		apiexplorer.ClickOnTryItOut();
		String value = common.getValueByXpath("fundsAvailable", "token boolean");

		if (amt > 0) {

			Taf.utils().log().info("funds Available: " + value);
		} else {

			Taf.utils().log().error("Funds Available: " + value);
			Assert.assertTrue(false);
		}

	}

	/*public void CreateConsentsWithWrongTokens(String linkname1, String linkname2, String username) {

		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		apiexplorer.verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkname1);
		common.clickOnUsingTxt(linkname2);
		apiexplorer.setAuthorizationText();
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		apiexplorer.verifyAccessTokenDataOfError();
	}

	public void verifyBlankAccountId(String linkName, String linkname2) {

		String verifyAccountID = "";
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		apiexplorer.verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt(linkname2);
		common.waitForSync(SMALL_WAIT);
		apiexplorer.visibleFormMissingValueButton();
		verifyAccountID = driver.findElement(accountId).getText();
		if (verifyAccountID != "") {
			System.out.println(verifyAccountID);
			Reporting.test.fail(" Account ID is : " + verifyAccountID);
			Assert.assertTrue(false);

		} else {
			Reporting.test.pass(" Account ID is blank, cannot proceed.");
		}
	}*/
}
