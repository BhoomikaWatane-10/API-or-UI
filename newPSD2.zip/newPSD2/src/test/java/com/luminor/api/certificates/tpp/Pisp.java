package com.luminor.api.certificates.tpp;

import com.luminor.taf.controllers.FrameworkException;
import com.luminor.taf.test.api.auth.utils.BouncycastleUtils;
import com.luminor.taf.test.api.auth.utils.KeystoreBuilder;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;

public class Pisp {

  private static RSAPrivateKey privateKey;
  private static X509Certificate certificate;

  public static RSAPrivateKey getPrivateKey() {
    if (privateKey == null) {
      try {
        privateKey = (RSAPrivateKey) BouncycastleUtils.getPrivateKeyFromPEM(privateKeyValue);
      } catch (Exception e) {
        throw new FrameworkException(e.getMessage());
      }
    }
    return privateKey;
  }

  public static X509Certificate getCertificate() throws Exception {
    if (certificate == null) {
      certificate = BouncycastleUtils.getX509CertificateFromPem(certificateValue);
    }
    return certificate;
  }

  public static KeyStore getKeystore() throws Exception {
    KeystoreBuilder builder = new KeystoreBuilder()
        .setPrivateKey(getPrivateKey(), getCertificate(), "1")
        .setCert("tppca", TppCA.getCaCertificate())
        .setKeystorePassword("changeit");
    KeyStore keyStore = builder.build();
    return keyStore;
  }

  private static final String privateKeyValue = "-----BEGIN PRIVATE KEY-----\n"
      + "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCt/FwlxA71vUy5\n"
      + "C2/QXkjug7kNfBrclh36imbYmSvFramqFsmtW8rF0ue7koocVqjReA/nzcff6C9r\n"
      + "zdF8tqra60942VXMsP35iUDPUzG/h5phes7B4l+/3iz9jq9W2kJ8durNrfR+pEf0\n"
      + "mxD7JOiFD6lVloJ8WxMLSvcjktSDddoV0vJfteNMJcH2lcye98wta524DrU670R8\n"
      + "uaPBKEI50NrycTYyrHsY6YG3WV2PjY5BSlWP+obr+x8ue0dTx/ZQz+1t0LwXwTbL\n"
      + "VwnjkLTGrg+Lc1RAGkyBFc/kqrLYa0MGlEMzZx3qvZy7Gl9LWkPGwv5c4Inw0cPk\n"
      + "OCNBvL8ZAgMBAAECggEAKASdpUodLsSluwI4a7LkD4hYrhNXklks+A2Rbkx81vEE\n"
      + "z0yCgs9UKoBCMNCZ177PAa8d6XFZgdTD44Xpo0fYsJXjJ6bFp1kmcZjyQT2febBV\n"
      + "AArhN5M79sPBkWiaR93X4QzxIPHcBK0Ap/BqzXlFyiU6C6ecx8Gi9bv+cD47hyjY\n"
      + "1/e9OlgFWZiFEGFXdEUaNfpdqkCp3nmZTxL25Qcb/GXXtBXbn4d3HZk8Bq6k5LDf\n"
      + "F8T7avEbkZzsHyvnWd9uqFA6ZmaM6aTGQs+f4+ziY+SntnroJRqhl/YaHzTJBWjo\n"
      + "prNyFIivHPUE1Flnul/rtbeLXe4A4wY303AKeXyCSQKBgQDmFCs9y2YLAQSIXMY+\n"
      + "8eqlkwdbyyuyEKwalgW4XqKgj1PRIbiu48OI0KlXOQ3JECPU1267hla9EVVR40sB\n"
      + "pV22Fw7FLY2XqQYuwToWOdKqXV2e0NpFpGEcA3eCafP1rlW2C1HCgbWwkHmMH4wg\n"
      + "PISsn5F9gX7zx0DUbfhWOTPE4wKBgQDBlmGdG4rZQENQwAygboLM0C8BWI18B6kH\n"
      + "2yZZxhNae2ovhL8w14B07jOSMTcsgX0oB3UsvLLK7cMVvbiAARu/OlnSPTBwV723\n"
      + "YLpNpWGusMtegQPvzRiwdrHMLvRqueV89M38orOBS+4Z5BpAfP3FQDRwoVgqCCi2\n"
      + "x2VM9Noo0wKBgFAfv/tSJSQ544E1hdiP2N52eH6QH5RwV+8eRbmyQ0JVB6Rx8OX+\n"
      + "7a5stDxq4xEdLM1HhQmLPBO1wJe25v0YwKzUFNG4DnI9a6jGo9rvohywTRUsuIa+\n"
      + "Ow9NacYh7dKmNrUh9gQdtc9aUOnqZpsnWDDhlQI3IaX1wu73qR8l5pBvAoGAdVki\n"
      + "XOkoNt+UrqtsPAghc+Qyyj8SrP+7wA5hZgQDEVNEn/95IjNQJBGM427AAlOQOaaj\n"
      + "qfXM7+RG4LP71mRVnIrTjfUXmtIlJ7cT2COLXii/bs8IQuHxuG6LArnn4ZZEfYWs\n"
      + "JBvAcn1DnSA/pZ3e+yYbY7b6SahefcXLK2Y1pI8CgYAA/ZLuAeNpneLI0KIeOLLJ\n"
      + "MecVCXr7IG+D7IjVEdCqNUZVaiCA3LsGMkHh9FWW0daYiOGJvhujqEY0lEEanLPQ\n"
      + "pA8mUeQzWklMASGz7dTh+b0mvkCoOXdvIRsp30ZzmmNwkZ6oX+o1KH/L5iHSXqkW\n"
      + "6fXbVL80hNT809OTUysaeA==\n"
      + "-----END PRIVATE KEY-----";

  private static final String certificateValue = "-----BEGIN CERTIFICATE-----\n"
      + "MIIEyzCCArOgAwIBAgIEAQIDBDANBgkqhkiG9w0BAQsFADA5MQswCQYDVQQGEwJF\n"
      + "RTETMBEGA1UECgwKU3VwZXIgaW5jLjEVMBMGA1UEAwwMUFNEMiBUZXN0IENBMB4X\n"
      + "DTE5MTIwMjAzMTMwMFoXDTI1MTIwMjAzMTMwMFowXzEZMBcGA1UEYRMQUFNERVMt\n"
      + "QkRFLTNERkQwMzELMAkGA1UEBhMCRUUxFTATBgNVBAMTDEF1dG9UZXN0UElTUDEe\n"
      + "MBwGA1UEChMVVGVzdCBQYXltZW50IFByb3ZpZGVyMIIBIjANBgkqhkiG9w0BAQEF\n"
      + "AAOCAQ8AMIIBCgKCAQEArfxcJcQO9b1MuQtv0F5I7oO5DXwa3JYd+opm2Jkrxa2p\n"
      + "qhbJrVvKxdLnu5KKHFao0XgP583H3+gva83RfLaq2utPeNlVzLD9+YlAz1Mxv4ea\n"
      + "YXrOweJfv94s/Y6vVtpCfHbqza30fqRH9JsQ+yTohQ+pVZaCfFsTC0r3I5LUg3Xa\n"
      + "FdLyX7XjTCXB9pXMnvfMLWuduA61Ou9EfLmjwShCOdDa8nE2Mqx7GOmBt1ldj42O\n"
      + "QUpVj/qG6/sfLntHU8f2UM/tbdC8F8E2y1cJ45C0xq4Pi3NUQBpMgRXP5Kqy2GtD\n"
      + "BpRDM2cd6r2cuxpfS1pDxsL+XOCJ8NHD5DgjQby/GQIDAQABo4G0MIGxMAsGA1Ud\n"
      + "DwQEAwIBxjAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwgYIGCCsGAQUF\n"
      + "BwEDBHYwdDAIBgYEAI5GAQEwCwYGBACORgEDAgEUMAgGBgQAjkYBBDATBgYEAI5G\n"
      + "AQYwCQYHBACORgEGAzA8BgYEAIGYJwIwMjATMBEGBwQAgZgnAQIMBlBTUF9QSQwT\n"
      + "Q29tcGV0ZW50IEF1dGhvcml0eQwGRUUtUEFZMA0GCSqGSIb3DQEBCwUAA4ICAQBi\n"
      + "Ozo/lkh/cWw/531kApp4T/HyJXQvtgmgg9l5BQgxAxwTpa2i3nmt5fRsyKolWcZA\n"
      + "HChHN+2LVIZm8LSFavJTnZ1w78g/KkvfvzUNWFSKqvZLj0JfYtDPIbMktPXGP2TS\n"
      + "jQzSf54LlcGt8aC70hHpfAJ7jq7l5rLrTzozeJLxJ86De41PfADrViaUMbnYLXG4\n"
      + "cvTTUX6cNsPUIz3k7KVODwpqI8Y9wRqQG0pfQmfRw9QuI0sbnT4NUJQzS6vyKhTX\n"
      + "j3j75DgUSDd7vzGdBENh+2L9awSMqhH2bA+H/55NBsheHqhCkMxRfSQmQc6QtHgF\n"
      + "yeNZfdRrZZICXt1q6MTqQfi68gbYT/24VizE98BfRU5aUEP8w/b/qUGmZYdnQeCf\n"
      + "6RDy/8eWops59P842RVQQ142UTg+zvrrLBY9+dN0Xf5I5hk28iSqME725gKs7nvg\n"
      + "5M2BChhu5eiCt2rkzXYs95AYL/GnlhbYMcm4yjxK+/DYh2jVppQ9HohsKTwjkwjG\n"
      + "ywBrWWu/N7ERyZwMlUWaZvAF4qhcPYV0QqkJWvM4yrkHO83rypX+DDxoHh14fVQB\n"
      + "PU8WowrMETocpOK2qDpSX9xmAEc7ddLvx9fLfRNpqvLKVwrpiLKKBkZKV8ampFoM\n"
      + "IDCQUtj0eNY6Yy89H/60VDZNsuXBjee4WzujNK1SbA==\n"
      + "-----END CERTIFICATE-----";
}
