package com.luminor.api.endpoints;

import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Selenide.$;
import static org.awaitility.Awaitility.await;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.BasePsd2Test;
import com.luminor.api.enums.TransactionStatus;
import com.luminor.api.pojo.ErrorResponse;
import com.luminor.api.pojo.consents.ConsentCreationPayload;
import com.luminor.api.pojo.payments.*;
import com.luminor.pageobjects.BlankedIBANPaymentPage;
import com.luminor.pageobjects.PaymentPage;
import com.luminor.taf.Taf;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.Authorization;
import com.luminor.utils.models.AuthMethodRequestBodyModel;
import io.qameta.allure.Step;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.http.HttpStatus;
import org.awaitility.core.ConditionTimeoutException;

public class Payments {

  public static final String PAYMENT_SIGNING_STATUS_FINALISED = "finalised";

  private static ExcelDataProviderApi excel = Taf.utils().excel();

  @Step("Create and sign SEPA payment")
  public static String createAndSignSepaPayment(Map<String, String> dp) {
    Taf.utils().log().info("Creating and signing SEPA payment");
    String paymentId =
        Payments.createSepaPayment(
            excel.getValueForCurrentIteration("debtorAccount"),
            excel.getValueForCurrentIteration("creditorAccount"));

    AuthMethodRequestBodyModel paymentBody = new AuthMethodRequestBodyModel(dp);
    String authorisationId = Payments.initiatePaymentSigning(paymentId);
    Payments.selectPaymentSigningMethod(paymentId, authorisationId, paymentBody);
    Payments.checkPaymentSigningStatusBecomesFinalised(paymentId, authorisationId);

    return paymentId;
  }


  @Step("Create SEPA payment via API and sign from browser")
  public static PaymentPage openCreatedPaymentFromBrowser(String debtorAccount, String creditorAccount) {
    open(createSepaPaymentAndReturnUrl(debtorAccount, creditorAccount));
    Authorization.loginToSignPayment();

    return new PaymentPage();
  }

  @Step("Check transaction status becomes '{1}'")
  public static void checkPaymentTransactionStatus(String paymentId,
      TransactionStatus expectedTransactionStatus) {

    Integer timeoutMiliSec = Taf.utils().config().getIntPropertyValue("selenide.timeout");
    Integer timoutSec = timeoutMiliSec / 1000;

    int pollingInterval = 5;
    try {
      await().atMost(timoutSec, TimeUnit.SECONDS).pollInterval(pollingInterval, TimeUnit.SECONDS)
          .until(() ->
              getPaymentDetails(paymentId).getTransactionStatus()
                  .equals(expectedTransactionStatus.getValue())
          );
    } catch (ConditionTimeoutException e) {
      Taf.utils().log().error(
          "Payment transaction status has not changed withing the given time limit of '" + timoutSec
              + "' seconds. Expected transaction status: '" + expectedTransactionStatus.getValue()
              + "', but was '" + getPaymentDetails(paymentId).getTransactionStatus() + "'");
    }
  }

  @Step("Get payment fee")
  public static void getPaymentFee(String debtorAccount, String creditorAccount) {
    Taf.utils().log().info(
        "Getting payment fee when payment is made from '" + debtorAccount + "' to '"
            + creditorAccount + "' account");
    Taf.api().rest()
        .addRequestBody(new PaymentFeePayload(debtorAccount, creditorAccount))
        .httpPost("/payment_fee")
        .hasStatusCode(HttpStatus.SC_OK)
        .validateJSONSchema("testdata/schemas/rest_response_post_payment_fee.json");
  }

  @Step("Check payment creation is unavailable")
  public static ErrorResponse checkPaymentCreationUnavailable(Object body,
      int expectedHttpStatusCode) {
    Taf.utils().log().info("Checking that payment creation is unavailable");
    return Taf.api().rest()
        .addRequestBody(body)
        .httpPost("/payments/sepa-credit-transfers")
        .hasStatusCode(expectedHttpStatusCode)
        .extractArrayAsList("errors", ErrorResponse.class)
        .get(0);
  }

  @Step("Get payment details")
  public static PaymentDetailsResponse getPaymentDetails(String paymentId) {
    Taf.utils().log().info("Getting payment details for payment with id '" + paymentId + "'");
    return Taf.api().rest()
        .httpGet("/payments/sepa-credit-transfers/%s", paymentId)
        .hasStatusCode(HttpStatus.SC_OK)
        .getResponseAsJavaObject(PaymentDetailsResponse.class);
  }

  @Step("Call api, post /payments/sepa-credit-transfers")
  private static String createSepaPayment(String debtorAccount, String creditorAccount) {
    Taf.utils().log().info(
        "Creating SEPA payment from account '" + debtorAccount + "' to '" + creditorAccount
            + "'");
    return Taf.api().rest()
        .addRequestBody(new CreatePaymentPayload(debtorAccount, creditorAccount))
        .httpPost("/payments/sepa-credit-transfers")
        .hasStatusCode(HttpStatus.SC_CREATED)
        .extractStringValue("paymentId");
  }

  @Step("Call api, post /payments/sepa-credit-transfers")
  private static String createSepaPaymentAndReturnUrl(String debtorAccount, String creditorAccount) {
    Taf.utils().log().info(
        "Creating SEPA payment from account '" + debtorAccount + "' to '" + creditorAccount
            + "'");
    return Taf.api().rest()
        .addHeader("Tpp-Redirect-Preferred", "true")
        .addHeader("Tpp-Redirect-URI", "https://www.microsoft.com")
        .addHeader("Tpp-Nok-Redirect-URI", "https://www.google.com")
        .addRequestBody(new CreatePaymentPayload(debtorAccount, creditorAccount))
        .httpPost("/payments/sepa-credit-transfers")
        .hasStatusCode(HttpStatus.SC_CREATED)
        .extractStringValue("_links.scaRedirect.href");
  }

  @Step("Call api, post /payments/sepa-credit-transfers/{0}/authorisations")
  private static String initiatePaymentSigning(String paymentId) {
    Taf.utils().log().info("Initiating payment signing for payment: '" + paymentId + "'");
    return Taf.api().rest()
        .httpPost("/payments/sepa-credit-transfers/%s/authorisations", paymentId)
        .hasStatusCode(HttpStatus.SC_CREATED)
        .extractStringValue("authorisationId");
  }

  @Step("Call api, put /payments/sepa-credit-transfers/{0}/authorisations/{1}")
  private static void selectPaymentSigningMethod(String paymentId, String authorisationId, AuthMethodRequestBodyModel body) {
    Taf.utils().log().info("Selecting '" + body.getAuthMethod() + "' as payment signing method");
    Taf.api().rest()
        .addRequestBody(body)
        .httpPut("/payments/sepa-credit-transfers/%s/authorisations/%s", paymentId,
            authorisationId)
        .hasStatusCode(HttpStatus.SC_OK);
  }

  @Step("Call api, get /payments/sepa-credit-transfers/{0}/authorisations/{1}/status")
  private static String getSigningStatus(String paymentId, String authorisationId) {
    Taf.utils().log().info("Getting payment signing status");
    return Taf.api().rest()
        .httpGet("/payments/sepa-credit-transfers/%s/authorisations/%s/status", paymentId,
            authorisationId)
        .hasStatusCode(HttpStatus.SC_OK)
        .extractStringValue("scaStatus");
  }

  @Step("Check payment status, recall api")
  private static void checkPaymentSigningStatusBecomesFinalised(String paymentId,
      String authorisationId) {
    Taf.utils().log()
        .info("Checking payment signing status becomes '" + PAYMENT_SIGNING_STATUS_FINALISED + "'");

    Integer timeoutMilliSec = Taf.utils().config().getIntPropertyValue("selenide.timeout");
    Integer timeoutSec = timeoutMilliSec / 1000;

    int pollingInterval = 5;
    try {
      await().atMost(timeoutSec, TimeUnit.SECONDS).pollInterval(pollingInterval, TimeUnit.SECONDS)
          .until(() ->
              getSigningStatus(paymentId, authorisationId).equals(PAYMENT_SIGNING_STATUS_FINALISED)
          );
    } catch (ConditionTimeoutException e) {
      Taf.utils().log().error(
          "Payment was not signed withing the given time limit of '" + timeoutSec
              + "' seconds. Expected payment signing status: '" + PAYMENT_SIGNING_STATUS_FINALISED
              + "'");
    }
  }

  @Step("Call api, post /payments/sepa-credit-transfers")
  private static String createSepaPaymentAndReturnUrlForBlankedIBAN( String creditorAccount) {
    Taf.utils().log().info(
            "Creating SEPA payment from account '" + "" + "' to '" + creditorAccount
                    + "'");
    return Taf.api().rest()
            .addHeader("Tpp-Redirect-Preferred", "true")
            .addHeader("Tpp-Redirect-URI", "https://www.microsoft.com")
            .addHeader("Tpp-Nok-Redirect-URI", "https://www.google.com")
            .addRequestBody(new CreatePaymentPayload("", creditorAccount))
            .httpPost("/payments/sepa-credit-transfers")
            .hasStatusCode(HttpStatus.SC_CREATED)
            .extractStringValue("_links.scaRedirect.href");
  }

  public static BlankedIBANPaymentPage openCreatedPaymentFromBrowserForBlankedIBAN( String creditorAccount) {
    open(createSepaPaymentAndReturnUrlForBlankedIBAN( creditorAccount));
    Authorization.loginToSignPaymentForBlankedIBAN();

    return new BlankedIBANPaymentPage();
  }

  @Step("Cancel payment by signing UI")
  public static void  openCancelPaymentPaymentFromBrowser(String debtorAccount, String creditorAccount,String valueToMatch){


    Taf.utils().log().info(
            "Creating  SEPA payment from account '" +  debtorAccount+ "' to '" + creditorAccount
                    + "'");
    String hrefLink= Taf.api().rest()
            .addHeader("Tpp-Redirect-Preferred", "true")
            .addHeader("Tpp-Redirect-URI", "https://www.microsoft.com")
            .addHeader("Tpp-Nok-Redirect-URI", "https://www.google.com")
            .addRequestBody(new CreatePaymentPayload(debtorAccount,creditorAccount))
            .httpPost("/payments/sepa-credit-transfers")
            .hasStatusCode(HttpStatus.SC_CREATED)
            .extractStringValue("_links.scaRedirect.href");
    String PaymentId=Taf.api().rest().extractStringValue("paymentId");

    open(hrefLink);
    Authorization.loginToSignPayment();
    SelenideElement buttonSign = $x("//button[@class='button layout-link size-default']/span"),
            tableCreditorInfo = $(".layout-wide-content.layout-wide-column2"),
            tableDebtorInfo = $(".layout-wide-content.layout-wide-column1");

    tableCreditorInfo.shouldHave(Condition.text(creditorAccount));
    tableDebtorInfo.shouldHave(Condition.text(debtorAccount));
    buttonSign.shouldBe(Condition.visible.because("Cancel Link should be visible")).click();
    String Status=  Payments.getPaymentStatus(PaymentId);
    if(Status.equals(valueToMatch)){
      Taf.utils().log().info("Payment is :"+Status);
    }
    else {
      Taf.utils().log().error("Payment is :"+Status);
    }
  }
  @Step("Call api, get /payments/sepa-credit-transfers/{0}/authorisations/{1}/status")
  private static String getPaymentStatus(String paymentId) {
    Taf.utils().log().info("Getting payment signing status");
    return Taf.api().rest()
            .httpGet("/payments/sepa-credit-transfers/%s/status", paymentId)

            .hasStatusCode(HttpStatus.SC_OK)
            .extractStringValue("transactionStatus");
  }

  @Step("Create and sign SEPA payment")
  public static String createAndDoNotSignSepaPaymentCheckPaymentStatus(String creditorAccount) {
    Taf.utils().log().info("Creating SEPA payment");
    String paymentId =
            Payments.createSepaPayment(
                    "",
                    excel.getValueForCurrentIteration("creditorAccount"));

   String status = Payments.getPaymentStatus(paymentId);
   if(status.equalsIgnoreCase("ACTC")){
     Taf.utils().log().info("Status is : "+status);

   }
   else{
     Taf.utils().log().error("Status is : "+status);
   }

    return paymentId;
  }
  }


