package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Setter;

@Setter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class CreditorAccount {

  private String iban;

  @JsonCreator
  public CreditorAccount(String creditorAccount) {
    this.iban = creditorAccount;
  }
}
