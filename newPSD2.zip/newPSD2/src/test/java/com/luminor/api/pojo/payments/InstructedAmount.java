package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class InstructedAmount {

  private String amount;
  private String currency;

  @JsonCreator
  public InstructedAmount() {
    this.amount = "0.01";
    this.currency = "EUR";
  }
}
