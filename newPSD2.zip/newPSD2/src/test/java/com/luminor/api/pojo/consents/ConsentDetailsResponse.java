package com.luminor.api.pojo.consents;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class ConsentDetailsResponse {

  private String consentStatus;
  private String consentId;

  @JsonCreator
  public ConsentDetailsResponse(@JsonProperty("consentStatus") String consentStatus,
      @JsonProperty("consentId") String consentId) {
    this.consentId = consentId;
    this.consentStatus = consentStatus;
  }
}
