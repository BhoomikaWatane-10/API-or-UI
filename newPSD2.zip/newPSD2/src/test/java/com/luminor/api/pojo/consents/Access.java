package com.luminor.api.pojo.consents;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Setter;

@Setter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class Access {

  @JsonProperty("accounts")
  private List<Accounts> accounts;

  @JsonCreator
  public Access(String iban) {
    accounts = new ArrayList<>();
    Accounts account = new Accounts(iban);
    this.accounts.add(account);
  }

  @JsonCreator
  public Access(List<String> ibanList) {
    accounts = new ArrayList<>();
    Accounts account;
    for (String iban : ibanList) {
      account = new Accounts(iban);
      this.accounts.add(account);
    }
  }
}
