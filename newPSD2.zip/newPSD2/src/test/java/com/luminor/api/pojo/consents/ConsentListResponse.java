package com.luminor.api.pojo.consents;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class ConsentListResponse {

  public String consentStatus;
  public String consentId;

  @JsonCreator
  public ConsentListResponse(@JsonProperty("consentStatus") String consentStatus,
      @JsonProperty("consentId") String consentId) {
    this.consentId = consentId;
    this.consentStatus = consentStatus;
  }
}

