package com.luminor.api.pojo.accounts;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionListResponse {

  private String transactionId;
  private String bookingDate;
  private String remittanceInformationUnstructured;
  private Account debtorAccount;

  @JsonCreator
  public TransactionListResponse(@JsonProperty("transactionId") String transactionId,
      @JsonProperty("bookingDate") String bookingDate,
      @JsonProperty("remittanceInformationUnstructured") String remittanceInformationUnstructured,
      @JsonProperty("debtorAccount") Account debtorAccount) {
    this.transactionId = transactionId;
    this.bookingDate = bookingDate;
    this.remittanceInformationUnstructured = remittanceInformationUnstructured;
    this.debtorAccount = debtorAccount;
  }
}