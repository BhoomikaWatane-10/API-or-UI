package com.luminor.api.enums;

public enum TppType {
  AISP("AISP"),
  ASPSP("ASPSP"),
  PIISP("PIISP"),
  PISP("PISP");

  private String value;

  TppType(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
