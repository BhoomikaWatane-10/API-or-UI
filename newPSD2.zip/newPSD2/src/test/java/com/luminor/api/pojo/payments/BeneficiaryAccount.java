package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.ToString;

@ToString
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class BeneficiaryAccount {

  private String benAcc;

  @JsonCreator
  public BeneficiaryAccount(String benAcc) {
    this.benAcc = benAcc;
  }
}
