package com.luminor.api.certificates.tpp;

import com.luminor.taf.controllers.FrameworkException;
import com.luminor.taf.test.api.auth.utils.BouncycastleUtils;
import com.luminor.taf.test.api.auth.utils.KeystoreBuilder;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;

public class Aspsp {

  private static RSAPrivateKey privateKey;
  private static X509Certificate certificate;

  public static RSAPrivateKey getPrivateKey() {
    if (privateKey == null) {
      try {
        privateKey = (RSAPrivateKey) BouncycastleUtils.getPrivateKeyFromPEM(privateKeyValue);
      } catch (Exception e) {
        throw new FrameworkException(e.getMessage());
      }
    }
    return privateKey;
  }

  public static X509Certificate getCertificate() throws Exception {
    if (certificate == null) {
      certificate = BouncycastleUtils.getX509CertificateFromPem(certificateValue);
    }
    return certificate;
  }

  public static KeyStore getKeystore() throws Exception {
    KeystoreBuilder builder = new KeystoreBuilder()
        .setPrivateKey(getPrivateKey(), getCertificate(), "1")
        .setCert("tppca", TppCA.getCaCertificate())
        .setKeystorePassword("changeit");
    KeyStore keyStore = builder.build();
    return keyStore;
  }

  private static final String privateKeyValue = "-----BEGIN PRIVATE KEY-----\n"
      + "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDNWJAIhvJ46z4X\n"
      + "2QvsOm1KPZNNmZiMSWru1ESUf8gIGabnr8DWlFT0O4gLz3/d2Mo+PCfi3DMNkJ4l\n"
      + "YHnMkVnwimrALSxVbOt8JYev5IVPo64rA74h0CwTSTT3ZkiqQrTrIxAvOTLi7ckN\n"
      + "09VTTZ+VJMMm7R6MSr88DoP6MzxyUgOFxtBB1oulnUt/dFrIPE1BVJ07dsgO3nfI\n"
      + "PPJr8XQh7PSTy/DJhSuFjc9DmyiL575hyXEtF/pxJ1BsP04FDQdjnomlwy3iM0mi\n"
      + "0qBfRFhIWM0g6J1v4IRpRyFGPETwUSsQ3j2JOJlgS7k6psZw2e+kzprl7tBV6IGk\n"
      + "0nMLLoFJAgMBAAECggEAGsIbosDS/+bHpJvn7dR/QVlcxJPrSPyYLp8CgMdV7ZhK\n"
      + "I47Hdi7GEz1esQtNAj+puwpjuDAxhub9dKlptbqLGckvt/Mq/8a9uOO7FrSUmpgd\n"
      + "rgVC1W0nESxM9qAhf+5JXQqopT6y3tdVh7O+7KgEz46Gz5++h1GGMfFCSWw7yDmj\n"
      + "8P48TmhXRZYsPXIBAYcPmmFzH1cI4FcWc+yI/UhHj+YvgZIYGgUsqmTvAXEV+fV8\n"
      + "YmsTQadyARrOduBuNMWcXssvMt9Dw5SvyDjOTydgfJ7qNlzzT9bvcq3unsvuy1EB\n"
      + "wuD0b6wVasydNXF+Tben0Tg0XmtcPnbO24AC3M16cQKBgQDou/+mOLyeihGf0r7h\n"
      + "5sXYFQ72rpfwdBUcRwyiNeLrEl8tcZ/ocXBblHrNC8JP9tpvbrC6azqKJqBuOSV8\n"
      + "DEkoeSu/pQhpxj6pAE7F1wbD58l9FNgZXo+YjzZJdO8QRhQw0OpnLUekHFmzax40\n"
      + "FoUqq07ZqKZ4dQ8w028cbTLc+wKBgQDh36fUZzVVm66g5P9hg1WRyY6/lkdGLVAr\n"
      + "F5TjKW23OCZRCHbN04vrLGFD+bubOAVTB38vAGAG4IFhfVsi/gvmdTGAFDNQExGp\n"
      + "9dUTAl/iMks9qcQ0i8sB3b3UMtQsLJUTjbC12IIhyL2flryeXf1PzMX46suPlH85\n"
      + "926om9B/iwKBgCT5mUgjQ3Q8o0gtBz6El3IZBmOSoXkGOERh1VQAE6kdJhnmL22S\n"
      + "eDNUh54D/D8QDOwfPdygJJDGSj64vYfTu9u+RIESCyAi6tmWvu0XmG+PZ6eDpEGD\n"
      + "kHTAa/OHrGN9fr+ysUrrGrKr/mRO5GGKImYBCWnzLV992Yf8T27Iuof5AoGAeC3+\n"
      + "KD9520DoW2c8km/EubsansmgxrAZdbQoXe2PGOthR8BPJhim28xTPE3GCkJ2YsUc\n"
      + "YK+8aCxP6sU+FpJBVq+IVPNqkfJzdZD9fA3JYpsL+ZU4dhTjQOzwsdURmydlcm/z\n"
      + "U+4M31jlu+ICHek4fJshwt16zbxfLUJ/uGqfNx0CgYEAu73W+nH0qV1h8qXjt6Fb\n"
      + "/ekihJQTzgN7VWyFxF258UPUkYuPSs6tA8D1nFW9xp85NjP+mA9/U0HPZFWcU3gq\n"
      + "YR3lgOcErP6Vm4QUxo5CmrkKCK1YJWYuZSlIIrP5rYXJx2FI+wKGFQ3ISMk6NnRc\n"
      + "Yj6PR2r3bkxzabPQ/PkYfkE=\n"
      + "-----END PRIVATE KEY-----";

  private static final String certificateValue = "-----BEGIN CERTIFICATE-----\n"
      + "MIIEyDCCArCgAwIBAgIEAQIDBDANBgkqhkiG9w0BAQsFADA5MQswCQYDVQQGEwJF\n"
      + "RTETMBEGA1UECgwKU3VwZXIgaW5jLjEVMBMGA1UEAwwMUFNEMiBUZXN0IENBMB4X\n"
      + "DTE5MDgwNzA5MjE1N1oXDTIyMDgwNzA5MjE1N1owXDEZMBcGA1UEYRMQUFNERVMt\n"
      + "QkRFLTNERkQyMzELMAkGA1UEBhMCTFYxEjAQBgNVBAMTCVRlc3RBU1BTUDEeMBwG\n"
      + "A1UEChMVVGVzdCBQYXltZW50IFByb3ZpZGVyMIIBIjANBgkqhkiG9w0BAQEFAAOC\n"
      + "AQ8AMIIBCgKCAQEAzViQCIbyeOs+F9kL7DptSj2TTZmYjElq7tRElH/ICBmm56/A\n"
      + "1pRU9DuIC89/3djKPjwn4twzDZCeJWB5zJFZ8IpqwC0sVWzrfCWHr+SFT6OuKwO+\n"
      + "IdAsE0k092ZIqkK06yMQLzky4u3JDdPVU02flSTDJu0ejEq/PA6D+jM8clIDhcbQ\n"
      + "QdaLpZ1Lf3RayDxNQVSdO3bIDt53yDzya/F0Iez0k8vwyYUrhY3PQ5soi+e+Yclx\n"
      + "LRf6cSdQbD9OBQ0HY56JpcMt4jNJotKgX0RYSFjNIOidb+CEaUchRjxE8FErEN49\n"
      + "iTiZYEu5OqbGcNnvpM6a5e7QVeiBpNJzCy6BSQIDAQABo4G0MIGxMAsGA1UdDwQE\n"
      + "AwIBxjAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwgYIGCCsGAQUFBwED\n"
      + "BHYwdDAIBgYEAI5GAQEwCwYGBACORgEDAgEUMAgGBgQAjkYBBDATBgYEAI5GAQYw\n"
      + "CQYHBACORgEGAzA8BgYEAIGYJwIwMjATMBEGBwQAgZgnAQEMBlBTUF9BUwwTQ29t\n"
      + "cGV0ZW50IEF1dGhvcml0eQwGRUUtUEFZMA0GCSqGSIb3DQEBCwUAA4ICAQB7aU4q\n"
      + "4/qjpMR5xJfDdPI4X1rKMmHZ0ILeEq61EEtuJGUeFUguXuIuSYjqQU+FI3An6G+x\n"
      + "Am/fT5KX1zP6ToGdQJlDjVX8cSYk4bbD55r/R2MFJUw2DnR5jCNGc+UrcHN/Yiy5\n"
      + "4e6WED6Tz0mawmp2aGl1PfZKu9zowSFXSWuE2hmH2ZxudrPiVHiKsAE5F7dGYS9y\n"
      + "dfu7as+9TSGPLcmhJ3eF56bhOo7bxtx1KMCB/F1UjS5s0nLVAeRI4IepgFuDs/ew\n"
      + "KIrzYXcW4oo8l17tBHk7iJdxdiePxszb+80hRju4+ul57hs3En0tc84XjoHq6OO+\n"
      + "aDPWdE90E7g885dFHhAvZIqZWShaJ4HmID//+uvdQJlFcUFJqhcTNOCuKXIYOVv5\n"
      + "v8KLDRaKo/hGt+xs4G5ERnwNhHQzG+D2ao0875kr6Y2vVlfynf8FlPX3/fp31wZk\n"
      + "ImurH6525n9Yq/iVi812DsQY6GgSzgs/pgbskHyZiNcvVs8Of8fg9p4t/HfaFpIk\n"
      + "kpWQnmEJpunHZbRVCfiGA/QC/D35z4dq9sfH9ES8NcnqudyXM8FzoIz20tAuZoNN\n"
      + "CwGfDi7D92f7nqzd+PKLHcl7LRgl+71FwJubnpegjlzV74LgAsH8YnLXRTB030tO\n"
      + "C+F+Ka/89Jt3KRQtsEBF3n7XjBnDWXBJ0/grFA==\n"
      + "-----END CERTIFICATE-----";
}
