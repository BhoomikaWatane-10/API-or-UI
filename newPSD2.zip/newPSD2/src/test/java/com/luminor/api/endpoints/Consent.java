package com.luminor.api.endpoints;

import static com.codeborne.selenide.Selenide.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.api.enums.Error;
import com.luminor.api.pojo.ErrorResponse;
import com.luminor.api.pojo.consents.AccountsListResponse;
import com.luminor.api.pojo.consents.ConsentCreationPayload;
import com.luminor.api.pojo.consents.ConsentDetailsResponse;
import com.luminor.pageobjects.ConsentPage;
import com.luminor.taf.Taf;
import com.luminor.taf.controllers.FrameworkException;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.Authorization;
import com.luminor.utils.models.AuthMethodRequestBodyModel;
import io.qameta.allure.Step;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.http.HttpStatus;
import org.awaitility.core.ConditionTimeoutException;

public class Consent {

  public static final String
          SCA_STATUS_FINALISED = "finalised",
          IBAN_INVALID = "EE571249487428281182";

  private static ExcelDataProviderApi excel = Taf.utils().excel();
  private static String consentId;

  @Step("Create and sign new consent")
  public static ConsentDetailsResponse createAndSignConsent(Map<String, String> dp) {
    Taf.utils().log().info("Creating and signing new consent");
    String consentId = createConsent(excel.getValueForCurrentIteration("debtorAccount"));
    String authId = Consent.initiateConsentSigning(consentId);

    AuthMethodRequestBodyModel consentBody = new AuthMethodRequestBodyModel(dp);
    Consent.selectSigningMethod(consentId, authId, consentBody);
    checkConsentSigningStatusBecomesFinalised(consentId, authId);
    Taf.utils().log().info("Consent is created with id: '" + consentId + "'");
    setConsentId(consentId);

    Taf.api().rest().addHeader("Consent-ID", consentId);

    return getConsentDetails(consentId);
  }

  @Step("Create consent, check for errors, sign consent")
  public static ConsentDetailsResponse createConsentCheckErrorsSign(Map<String, String> dp) {
    Taf.utils().log().info("Attempt to create consent with iban which does not belong to the user");
    assertThat(createInvalidConsent(IBAN_INVALID, HttpStatus.SC_FORBIDDEN).get(0).getText())
            .as("Error should be returned: '" + Error.SERVICE_BLOCKED + "'")
            .contains(Error.SERVICE_BLOCKED.getValue());

    String consentId = createConsent(excel.getValueForCurrentIteration("debtorAccount"));

    Taf.utils().log().info("Attempt to get account info without consent");
    assertThat(Accounts.checkAccountsUnavailable(HttpStatus.SC_BAD_REQUEST).getText())
            .as("Error should be returned: '" + Error.CONSENT_NOT_SET + "'")
            .contains(Error.CONSENT_NOT_SET.getValue());

    Taf.utils().log().info("Attempt to get accounts info with unsigned consent");
    Taf.api().rest().addHeader("Consent-ID", consentId);
    assertThat(Accounts.checkAccountsUnavailable(HttpStatus.SC_CONFLICT).getText())
            .as("Error should be returned: '" + Error.STATUS_INVALID.getValue() + "'")
            .contains(Error.STATUS_INVALID.getValue());

    AuthMethodRequestBodyModel consentBody = new AuthMethodRequestBodyModel(dp);
    String authId = Consent.initiateConsentSigning(consentId);
    Consent.selectSigningMethod(consentId, authId, consentBody);
    checkConsentSigningStatusBecomesFinalised(consentId, authId);
    Taf.utils().log().info("Consent is created with id: '" + consentId + "'");

    return getConsentDetails(consentId);
  }

  @Step("Check consent creation is unavailable")
  public static void checkConsentListIsUnavailable() {
    Taf.utils().log().info("Checking that consent creation is unavailable");
    Taf.api().rest()
            .httpGet("/consents")
            .hasStatusCode(HttpStatus.SC_UNAUTHORIZED);
  }

  @Step("Check account list is unavailable")
  public static void checkAccountListUnavailable() {
    Taf.utils().log().info("Checking that account list is unavailable");
    Taf.api().rest()
            .httpGet("/account-list")
            .hasStatusCode(HttpStatus.SC_UNAUTHORIZED);
  }

  @Step("Check account {0} is available for consent creation")
  public static void checkAccountAvailableForConsentCreation(String iban) {
    Taf.utils().log().info("Checking account '" + iban + "' is available for consent creation");
    assertThat(getAccountListAvailableForConsentCreation()
            .stream()
            .filter(x -> x.getIban().equals(iban))
            .findFirst()
            .orElseThrow(() -> new FrameworkException(
                    "Unable to find account '" + iban + "' for consent creation"))
            .getIban())
            .as("Consent IBAN should be equal to IBAN from data provider")
            .isEqualTo(iban);
  }

  @Step("Check account {0} is unavailable for consent creation")
  public static void checkAccountUnavailableForConsentCreation(String iban) {
    Taf.utils().log().info("Checking account '" + iban + "' is unavailable for consent creation");
    getAccountListAvailableForConsentCreation().forEach(x -> {
      assertThat(x.getIban())
              .as("Consent IBAN should not be equal to IBAN from data provider")
              .isNotEqualTo(iban);
    });
  }

  @Step("Get account list")
  public static List<AccountsListResponse> getAccountListAvailableForConsentCreation() {
    Taf.utils().log()
            .info("Getting account list");
    return Taf.api().rest()
            .httpGet("/account-list")
            .hasStatusCode(HttpStatus.SC_OK)
            .extractArrayAsList("accounts", AccountsListResponse.class);
  }

  @Step("Delete consent: {0}")
  public static void deleteConsent(String consentId) {
    if (consentId != null) {
      Taf.utils().log().info("Deleting consent with id: '" + consentId + "'");
      Taf.api().rest()
              .httpDelete("/consents/%s", consentId)
              .hasStatusCode(HttpStatus.SC_NO_CONTENT);
    }
  }

  @Step("Open generated consent url and proceed with login")
  public static ConsentPage createConsentFromBrowser(String iban) {
    open(getConsentUrl(iban));
    Authorization.loginToSignConsent();

    return new ConsentPage();
  }


  @Step("Call api, post /consents")
  public static String createConsent(String iban) {
    Taf.utils().log().info("Creating new consent request");
    return Taf.api().rest()
            .addRequestBody(new ConsentCreationPayload(iban))
            .httpPost("/consents")
            .hasStatusCode(HttpStatus.SC_OK)
            .extractStringValue("consentId");
  }

  @Step("Call api, post /consents")
  private static String getConsentUrl(String iban) {
    Taf.utils().log().info("Creating new consent request");

    return Taf.api().rest()
            .addHeader("Tpp-Redirect-Preferred", "true")
            .addHeader("Tpp-Redirect-URI", "https://localhost/success")
            .addHeader("Tpp-Nok-Redirect-URI", "https://localhost/fail")
            .addRequestBody(new ConsentCreationPayload(iban))
            .httpPost("/consents")
            .hasStatusCode(HttpStatus.SC_OK)
            .extractStringValue("_links.scaRedirect.href");
  }

  @Step("Call api, post /consents")
  private static List<ErrorResponse> createInvalidConsent(String iban, int expectedStatusCode) {
    Taf.utils().log().info("Creating invalid consent request with iban '" + iban + "'");
    return Taf.api().rest()
            .addRequestBody(new ConsentCreationPayload(iban))
            .httpPost("/consents")
            .hasStatusCode(expectedStatusCode)
            .extractArrayAsList("errors", ErrorResponse.class);
  }

  @Step("Call api, post /consents/{0}/authorisations")
  public static String initiateConsentSigning(String consentId) {
    Taf.utils().log().info("Initiating consent signing for consent: '" + consentId + "'");
    return Taf.api().rest()
            .httpPost("/consents/%s/authorisations", consentId)
            .hasStatusCode(HttpStatus.SC_OK)
            .extractStringValue("authorisationId");
  }

  @Step("Call api, put /consents/{0}/authorisations/{1}")
  public static void selectSigningMethod(String consentId, String authorizationId, AuthMethodRequestBodyModel body) {
    Taf.utils().log().info("Selecting '" + body.getAuthMethod() + "' as signing method");
    Taf.api().rest()
            .addRequestBody(body)
            .httpPut("/consents/%s/authorisations/%s", consentId, authorizationId)
            .hasStatusCode(HttpStatus.SC_OK);
  }

  @Step("Call api, get /consents/{0}/authorisations/{1}/status")
  public static String getConsentSigningStatus(String consentId, String authorizationId) {
    Taf.utils().log().info("Getting consent signing status");
    return Taf.api().rest()
            .httpGet("/consents/%s/authorisations/%s/status", consentId, authorizationId)
            .hasStatusCode(HttpStatus.SC_OK)
            .extractStringValue("scaStatus");
  }

  @Step("Call api, get /consents/{0}/authorisations/{1}/status")
  public static String getConsentStatus(String consentId) {
    Taf.utils().log().info("Getting consent signing status");
    return Taf.api().rest()
            .httpGet("/consents/%s/status", consentId)
            .hasStatusCode(HttpStatus.SC_OK)
            .extractStringValue("consentStatus");
  }

  @Step("Check consent status, recall api")
  public static void checkConsentSigningStatusBecomesFinalised(String consentId,
                                                               String authorizationId) {
    Taf.utils().log()
            .info("Checking consent signing status becomes '" + SCA_STATUS_FINALISED + "'");

    Integer timeoutMiliSec = Taf.utils().config().getIntPropertyValue("selenide.timeout");
    Integer timoutSec = timeoutMiliSec / 1000;

    int pollingInterval = 5;
    try {
      await().atMost(timoutSec, TimeUnit.SECONDS).pollInterval(pollingInterval, TimeUnit.SECONDS)
              .until(() ->
                      getConsentSigningStatus(consentId, authorizationId).equals(SCA_STATUS_FINALISED)
              );
    } catch (ConditionTimeoutException e) {
      Taf.utils().log().error(
              "Consent was not signed withing the given time limit of '" + timoutSec
                      + "' seconds. Expected consent signing status: '" + SCA_STATUS_FINALISED + "'");
    }
  }

  @Step("Call api, get /consents/{0}")
  public static ConsentDetailsResponse getConsentDetails(String consentId) {
    Taf.utils().log().info("Getting consent details: '" + consentId + "'");
    return Taf.api().rest()
            .httpGet("/consents/%s", consentId)
            .hasStatusCode(HttpStatus.SC_OK)
            .getResponseAsJavaObject(ConsentDetailsResponse.class);
  }

  public static String getConsentId() {
    return consentId;
  }

  public static void setConsentId(String consentId) {
    Consent.consentId = consentId;
  }

  @Step("Cancel payment by signing UI")
  public static void openCancelConsentFromBrowser(String debtorAccount, String valueToMatch) {

    Taf.utils().log().info("Creating new consent request");

    String hrefLink = Taf.api().rest()
            .addHeader("Tpp-Redirect-Preferred", "true")
            .addHeader("Tpp-Redirect-URI", "https://localhost/success")
            .addHeader("Tpp-Nok-Redirect-URI", "https://localhost/fail")
            .addRequestBody(new ConsentCreationPayload(debtorAccount))
            .httpPost("/consents")
            .hasStatusCode(HttpStatus.SC_OK)
            .extractStringValue("_links.scaRedirect.href");
    String consentId = Taf.api().rest().extractStringValue("consentId");
    open(hrefLink);
    Authorization.loginToSignConsent();
    SelenideElement buttonSign = $x("//button[@class='button layout-link size-default']/span"),
            tableAccountInfo = $(".scrollable-table-wrapper.no-actions-visible");

    tableAccountInfo.shouldHave(Condition.text(Taf.utils().excel().getValueForCurrentIteration("debtorAccount")));
       buttonSign.shouldBe(Condition.visible.because("Cancel Link should be visible")).click();
    String Status = Consent.getConsentStatus(consentId);
    if (Status.equals(valueToMatch)) {
      Taf.utils().log().info("Consent is :" + Status);
    } else {
      Taf.utils().log().error("Consent is :" + Status);
    }
  }
}