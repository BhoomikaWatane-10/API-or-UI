package com.luminor.api.pojo.funds;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Setter;

@Setter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class InstructedAmount {

  private String amount;
  private String currency;

  @JsonCreator
  public InstructedAmount(String amount) {
    this.amount = amount;
    this.currency = "EUR";
  }
}
