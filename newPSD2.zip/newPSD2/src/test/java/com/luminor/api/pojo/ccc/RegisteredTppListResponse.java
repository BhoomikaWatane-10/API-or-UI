package com.luminor.api.pojo.ccc;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class RegisteredTppListResponse {

  private Long id;
  private List<Clients> clients;

  @JsonCreator
  public RegisteredTppListResponse(
      @JsonProperty("id") Long id,
      @JsonProperty("clients") List<Clients> clients) {
    this.id = id;
    this.clients = clients;
  }
}
