package com.luminor.api.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorResponse {

  private String category;
  private String code;
  private String text;

  @JsonCreator
  public ErrorResponse(@JsonProperty("category") String category,
      @JsonProperty("code") String code, @JsonProperty("text") String text) {
    this.category = category;
    this.code = code;
    this.text = text;
  }
}
