package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.ArrayList;
import java.util.List;
import lombok.ToString;

@ToString
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class PaymentFeePayload {

  private String benAcc;
  private String ordAcc;
  private double amt;
  private String crcCrc;
  private String feeAcc;
  private String info;
  private List<BeneficiaryAccount> benAccList;

  @JsonCreator
  public PaymentFeePayload(String ordAcc, String benAcc) {
    this.benAcc = benAcc;
    this.ordAcc = ordAcc;
    this.amt = Double.parseDouble(new InstructedAmount().getAmount());
    this.crcCrc = "EUR";
    this.feeAcc = ordAcc;
    this.info = "Automated API testing";
    benAccList = new ArrayList<>();
    benAccList.add(new BeneficiaryAccount(benAcc));
  }
}
