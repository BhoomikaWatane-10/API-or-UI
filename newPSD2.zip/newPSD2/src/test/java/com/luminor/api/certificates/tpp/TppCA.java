package com.luminor.api.certificates.tpp;

import com.luminor.taf.test.api.auth.utils.BouncycastleUtils;
import java.security.cert.X509Certificate;

public class TppCA {

  private static X509Certificate caCertificate;

  public static X509Certificate getCaCertificate() throws Exception {
    if (caCertificate == null) {
      caCertificate = BouncycastleUtils.getX509CertificateFromPem(caValue);
    }
    return caCertificate;
  }

  private static final String caValue = "-----BEGIN CERTIFICATE-----\n" +
      "MIIFSDCCAzCgAwIBAgIJALzpjzuHLI8yMA0GCSqGSIb3DQEBCwUAMDkxCzAJBgNV\n" +
      "BAYTAkVFMRMwEQYDVQQKDApTdXBlciBpbmMuMRUwEwYDVQQDDAxQU0QyIFRlc3Qg\n" +
      "Q0EwHhcNMTkwODA1MTk1NDU4WhcNMzQwODAxMTk1NDU4WjA5MQswCQYDVQQGEwJF\n" +
      "RTETMBEGA1UECgwKU3VwZXIgaW5jLjEVMBMGA1UEAwwMUFNEMiBUZXN0IENBMIIC\n" +
      "IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAtCtyJ1olivywPnVQoQ9rLRgq\n" +
      "FL1y0d0fTCCm+GnSDpA9/34NGM+NuGRYFQ7GSdDcoE+jZobO3dCykfAEwOAoZZ1d\n" +
      "i0jxZ6g8pZFMp6/OOTPiqSkXzHzbZ47vWBiihEmQ/aYWyqfwRxCnVnWIpFk8VAwI\n" +
      "MpASRM9KhzT8LEmLkQ/c8X7foxkitoX7qHPpvB8wZISQOjxpHpy8LIlaadPfOQ4m\n" +
      "wYVEP8Mli+3r29Blyo2iyei+Q2/K9rlHP51Maj5m8slw2LsDL6l+DKlhETiZjviK\n" +
      "IB8G55uLFdei9bMwHld+wWbGkRg5aqGVEazGd78ww8A/pReWgUMBXVnz+OYJMwhI\n" +
      "AkS68aDh2iGvjIGnV32jeltOBvyyw/yYNr+Fl1BTsu3RDOLHtEnyRaOuuEPrFKhA\n" +
      "Vjewo8EfDHcP6E/R0srBaD1LO/ixnxCyMyMoZunR018b4s81YPYBKYFDWrNY/0/R\n" +
      "8UsbF8+h/AM4zCNfYZCasJ2X7urp5BrRhsVQQSXa6lwGIV7vCBFSMqCu8Zqa6yP3\n" +
      "1sgCP6X3AdWIuQrwkgvURBrnSDgahkdwNqZPbihqOcT1Rl8dhwqCuL6Bgjc6tnPq\n" +
      "jMPNac35tQJ69fJ9dLfeQBL9uhbkcjsOfJmxBXLvmOSqZJXTyqMPbAOnpOBWZHXS\n" +
      "L5z0xN8tjjDMvG+G1ZECAwEAAaNTMFEwHQYDVR0OBBYEFLu9fS321gXRaFOI67lf\n" +
      "mFQZqsokMB8GA1UdIwQYMBaAFLu9fS321gXRaFOI67lfmFQZqsokMA8GA1UdEwEB\n" +
      "/wQFMAMBAf8wDQYJKoZIhvcNAQELBQADggIBAGWArDApPw0fKjsjvCxX5WeWpo4e\n" +
      "TdD9EwZetubN5SP6yPt2tgqZFQT7DUIcDNyZXk1pl6MGO3pL09J5moTbfFSimt93\n" +
      "jzUecZyEjK1iGTZsaUpJR/MsvacyzSWy3l6SZlCapvZfVSGSYZS0icwZ8uFrWPOe\n" +
      "L/8pajlkq6XXK7tXESYzI3jczFmGGBLxwJVwf3hBPvg2CFoceaxMl5BD26Dv9j/a\n" +
      "R/rUoy9CcSgwqntfcfaujox+L2oB66x6WKVLy8vYfw07WXiXrfiE5kafp6OOpxk0\n" +
      "dO07oldCCU7CINCPufez6mVeC7uLnjzJOqt8w+pjhD0HfGd6p86VdrmxSgG/c9AF\n" +
      "qieI+YlviXGeHWm+pDeuXhgsg5l4xjzXMAPrv2c/K8pnNsqlqGdsnY9dvxYIJfaF\n" +
      "LqqjA7B6I8uBZ9kYjRUPQIA7ed6EOWVPn8tUx5g9dzvTWGJSXRz0Adv0wMtN3xmj\n" +
      "YtUUHjENNkXQQw94SRootxC/uiO8oO3ydDnVvx2HmJAGCYnfL/6LTxQqQ1m3SGpT\n" +
      "A4PH5h+DHp5segOdLG5j6EVPCSvvUa07Qqm4hzLvVSFuRymuSctUfiHab/t6UEwh\n" +
      "B2aM5IbcF7AmEERjPKPUjljPPFHv8QOZifLCtaDW5paaQqxSH4PJAS/NXuq6DrT3\n" +
      "tV4BEmLusvdLx65W\n" +
      "-----END CERTIFICATE-----";
}
