package com.luminor.api.endpoints;

import static org.assertj.core.api.Assertions.assertThat;

import com.luminor.api.pojo.funds.ConfirmAvailableFundsPayload;
import com.luminor.api.pojo.funds.ConfirmAvailableFundsResponse;
import com.luminor.utils.RandomValueGenerator;
import com.luminor.taf.Taf;
import com.luminor.taf.utils.ExcelDataProviderApi;
import io.qameta.allure.Step;
import org.apache.http.HttpStatus;

public class Funds {

  private static ExcelDataProviderApi excel = Taf.utils().excel();

  @Step("Confirm funds are available")
  public static void checkAvailableFunds() {
    Taf.utils().log().info("Checking available funds confirmation");
    String iban = excel.getValueForCurrentIteration("debtorAccount");
    String availableAmount = RandomValueGenerator.generateRandomValueWithinRange(1, 1000);
    String notAvailableAmount = RandomValueGenerator
        .generateRandomValueWithinRange(10000000, 20000000);

    assertThat(checkAvailableFunds(iban, availableAmount).isFundsAvailable())
        .as("Amount '" + availableAmount
            + "' availability should be confirmed as 'true' for account '"
            + iban + "'")
        .isTrue();
    assertThat(checkAvailableFunds(iban, notAvailableAmount).isFundsAvailable())
        .as("Amount '" + notAvailableAmount
            + "' availability should be confirmed as 'false' for account '"
            + iban + "'")
        .isFalse();
  }

  @Step("Check confirmation of available fund is unavailable")
  public static void checkAvailableFundsUnavailable(int expectedHttpStatusCode) {
    Taf.utils().log().info("Checking that available fund confirmation is unavailable");
    Taf.api().rest()
        .addRequestBody(
            new ConfirmAvailableFundsPayload(excel.getValueForCurrentIteration("debtorAccount"),
                RandomValueGenerator.generateRandomValueWithinRange(1, 1000)))
        .httpPost("/funds-confirmations")
        .hasStatusCode(expectedHttpStatusCode);
  }

  @Step("Call api, post /funds-confirmations")
  private static ConfirmAvailableFundsResponse checkAvailableFunds(String iban, String amount) {
    Taf.utils().log()
        .info("Checking if account '" + iban + "' has funds '" + amount + "' available");
    return Taf.api().rest()
        .addRequestBody(new ConfirmAvailableFundsPayload(iban, amount))
        .httpPost("/funds-confirmations")
        .hasStatusCode(HttpStatus.SC_OK)
        .getResponseAsJavaObject(ConfirmAvailableFundsResponse.class);
  }
}