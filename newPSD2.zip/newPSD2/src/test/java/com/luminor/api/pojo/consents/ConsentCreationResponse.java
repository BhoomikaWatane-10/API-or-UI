package com.luminor.api.pojo.consents;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class ConsentCreationResponse {

  private String consentStatus;
  private String consentId;

  @JsonCreator
  public ConsentCreationResponse(@JsonProperty("consentStatus") String consentStatus,
      @JsonProperty("consentId") String consentId) {
    this.consentId = consentId;
    this.consentStatus = consentStatus;
  }
}
