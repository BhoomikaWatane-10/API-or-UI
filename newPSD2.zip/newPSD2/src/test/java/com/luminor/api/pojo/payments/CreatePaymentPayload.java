package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class CreatePaymentPayload {

  private InstructedAmount instructedAmount;
  private DebtorAccount debtorAccount;
  private String debtorName;
  private String creditorName;
  private CreditorAccount creditorAccount;
  private String remittanceInformationUnstructured;

  @JsonCreator
  public CreatePaymentPayload(String debtorAccount, String creditorAccount) {
    this.instructedAmount = new InstructedAmount();
    this.debtorAccount = new DebtorAccount(debtorAccount);
    this.creditorAccount = new CreditorAccount(creditorAccount);
    setDefaultValues();
  }

  private void setDefaultValues() {
    this.debtorName = "TestAutomation" + System.currentTimeMillis();
    this.creditorName = "CreditorName";
    this.remittanceInformationUnstructured = "Psd2Automation" + System.currentTimeMillis();
  }
}
