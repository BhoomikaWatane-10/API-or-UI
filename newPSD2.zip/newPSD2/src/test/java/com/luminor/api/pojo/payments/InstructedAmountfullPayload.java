
package com.luminor.api.pojo.payments;



import com.fasterxml.jackson.annotation.*;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class InstructedAmountfullPayload {


    public String currency;

    public Float amount;

    @JsonCreator
    public InstructedAmountfullPayload(String currency, Float amount) {
        super();
        this.currency = currency;
        this.amount = amount;
    }

}
