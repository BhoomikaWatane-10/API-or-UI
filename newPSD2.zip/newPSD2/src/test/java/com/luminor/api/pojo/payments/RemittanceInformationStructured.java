
package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Setter;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;

@Setter
//@JsonAutoDetect(fieldVisibility = ANY)
public class RemittanceInformationStructured {


    public String reference;

   @JsonCreator
    public RemittanceInformationStructured(String reference) {
        super();
        this.reference = reference;
    }

}
