package com.luminor.api.endpoints;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.api.pojo.consents.ConsentCreationPayload;
import com.luminor.pageobjects.TransactionHistoryPage;
import com.luminor.taf.Taf;
import com.luminor.taf.test.api.rest.Rest;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.Authorization;
import com.luminor.utils.models.AuthMethodRequestBodyModel;
import io.qameta.allure.Step;
import org.apache.http.HttpStatus;
import org.awaitility.core.ConditionTimeoutException;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.codeborne.selenide.Selenide.*;
import static com.luminor.utils.DateHelper.getFutureDate;
import static org.awaitility.Awaitility.await;

public class TransactionHistory {

    public static final String
            SCA_STATUS_SIGNED = "signed";
    // IBAN_INVALID = "EE571249487428281182";

    private static ExcelDataProviderApi excel = Taf.utils().excel();
   // private static String consentId;
    private static String accountId;
    private static String statementId;
    private static String authorisationId;
    private static String signingStatus;

    @Step("Create and sign new consent")
    public static String createAndSignTransactionHistory(Map<String, String> dp) throws InterruptedException {
        Taf.utils().log().info("Creating and signing new Transaction History");
        String consentId = Consent.createConsent(excel.getValueForCurrentIteration("debtorAccount"));
        String authId = Consent.initiateConsentSigning(consentId);

        AuthMethodRequestBodyModel consentBody = new AuthMethodRequestBodyModel(dp);
        Consent.selectSigningMethod(consentId, authId, consentBody);
        Consent.checkConsentSigningStatusBecomesFinalised(consentId, authId);
        Taf.utils().log().info("Consent is created with id: '" + consentId + "'");
        Consent.setConsentId(consentId);

        Taf.api().rest().addHeader("Consent-ID", consentId);
        Consent.getConsentDetails(consentId);
        Taf.utils().log().info("Creating and signing new Transaction History");
       accountId= getAccountListForTransactionHistory(consentId);
        accountId = accountId.replaceAll("[^a-zA-Z0-9]", "");

       statementId= initateTranscationHistory(accountId,getFutureDate(-2, "yyyy-MM-dd"),getFutureDate(0, "yyyy-MM-dd"),"booked");//excel.getValueForCurrentIteration("DateFrom"),excel.getValueForCurrentIteration("DateTo"),excel.getValueForCurrentIteration("BookingStatus"));

       authorisationId=createTransactionHistory(accountId,statementId);

       selectSigningMethodTransactionHistory(consentId,accountId,statementId,authorisationId,consentBody);
      //  checkTransactionSigningStatusBecomesSigned(accountId,statementId);
        signingStatus=getTransactionSigningStatus(accountId,statementId);

        return signingStatus;
    }

    @Step("Get the Account Id from the account List")
    public static String getAccountListForTransactionHistory(String consentId) {


        Taf.utils().log().info("Initiating Account List of Transaction History");
        Taf.api().rest()//addHeader("Consent-id", consentId)
                .httpGet("/accounts")
                .hasStatusCode(HttpStatus.SC_OK);
        String accountId = Taf.api().rest().extractStringValue("accounts.resourceId");

        return accountId;
    }

    @Step("Initate Tanasaction History")
    public static String initateTranscationHistory(String AccountId,String DateFrom,String DateTo,String BookingStatus) throws InterruptedException {



         AccountId=AccountId.replaceAll("[^a-zA-Z0-9]", "");

        Taf.utils().log().info("Initiating Transaction History");

        Taf.api().rest()

                .addQueryParameter("DateFrom", DateFrom)
                .addQueryParameter("DateTo", DateTo)
                .addQueryParameter("BookingStatus", BookingStatus)
                .httpPost("/accounts/%s/transactions", AccountId)
                .hasStatusCode(HttpStatus.SC_CREATED)
                .extractStringValue("statementId");
        statementId = Taf.api().rest().extractStringValue("statementId");
        System.out.println(statementId);
        return statementId; //?DateFrom=2021-08-03&DateTo=2021-08-09&BookingStatus=booked


    }

    public static String createTransactionHistory(String AccountId,
                                           String statementId) {
        String authorizationId = "";

        Taf.api().rest()
                .httpPost("/accounts/%s/transactions/%s/authorisations",AccountId,statementId)
                .hasStatusCode(HttpStatus.SC_CREATED);
         authorizationId = Taf.api().rest().extractStringValue("authorisationId");

        return authorizationId;

    }

    @Step("Call api, put /accounts/{0}/transactions/{1}/authorisations/{2}")
    public  static void  selectSigningMethodTransactionHistory(String consentId, String AccountId,
                                                               String statementId, String authorizationId, AuthMethodRequestBodyModel body) {

            Taf.utils().log().info("Selecting '" + body.getAuthMethod() + "' as signing method");
            Taf.api().rest()
                    .addRequestBody(body)
                    .httpPut("/accounts/%s/transactions/%s/authorisations/%s", AccountId, statementId,authorizationId)
                    .hasStatusCode(HttpStatus.SC_OK);


        // return statementId;

    }

    @Step("Call api, get /accounts/{0}/transactions/{1}/status")
    public static String getTransactionSigningStatus(String AccountId,
                                                     String statementId ) {
        Taf.utils().log().info("Getting transaction signing status");
        return Taf.api().rest()
                .httpGet("/accounts/%s/transactions/%s/status", AccountId, statementId)
                .hasStatusCode(HttpStatus.SC_OK)
               .extractStringValue("scaStatus");
     //String Status=  Taf.api().rest().extractStringValue("scaStatus");
       // Taf.utils().log().info("Getting transaction signing status as"+Status);
    }

    @Step("Call api, get /accounts/{0}/transactions/{1}/status")
    public static Rest getTransactionSigningDownload(String consentId,String AccountId,
                                                     String statementId ) {
        Taf.utils().log().info("Getting transaction signing download");
        return  Taf.api().rest()
                .httpGet("/accounts/%s/transactions/%s/download", AccountId, statementId)
                .hasStatusCode(HttpStatus.SC_OK);
                //.extractStringValue("transactionId");
        //String Status=  Taf.api().rest().extractStringValue("scaStatus");
        // Taf.utils().log().info("Getting transaction signing status as"+Status);
    }

    @Step("Check Transaction History status, recall api")
    public static void checkTransactionSigningStatusBecomesSigned(
                                                                  String accountId,
                                                                  String statementId) {
        Taf.utils().log()
                .info("Checking transaction signing status becomes '" + SCA_STATUS_SIGNED + "'");

        Integer timeoutMiliSec = Taf.utils().config().getIntPropertyValue("selenide.timeout");
        Integer timoutSec = timeoutMiliSec / 1000;

        int pollingInterval = 5;
        try {
            await().atMost(timoutSec, TimeUnit.SECONDS).pollInterval(pollingInterval, TimeUnit.SECONDS)
                    .until(() ->
                            getTransactionSigningStatus(accountId,statementId).equals(SCA_STATUS_SIGNED)
                    );
        } catch (ConditionTimeoutException e) {
            Taf.utils().log().error(
                    "Transaction was not signed withing the given time limit of '" + timoutSec
                            + "' seconds. Expected transaction signing status: '" + SCA_STATUS_SIGNED + "'");
        }
    }
    @Step("Call api, post /accounts")
    private static String getTransactionHistoryUrl(String accountId,String DateFrom,String DateTo,String BookingStatus) {
        Taf.utils().log().info("Creating new consent request");

        return Taf.api().rest()
                .addHeader("Tpp-Redirect-Preferred", "true")
                .addHeader("Tpp-Redirect-URI", "https://localhost/success")
                .addHeader("Tpp-Nok-Redirect-URI", "https://localhost/fail")
                . addQueryParameter("DateFrom", DateFrom).addQueryParameter("DateTo", DateTo).addQueryParameter("BookingStatus", BookingStatus)
                // .addRequestBody(new ConsentCreationPayload(iban))
                .httpPost("/accounts/%s/transactions",accountId)
                .hasStatusCode(HttpStatus.SC_CREATED)
                .extractStringValue("_links.scaRedirect.href");
    }

    @Step("Open generated transaction History url and proceed with login")
    public static TransactionHistoryPage createTransactionHistoryFromBrowser(Map<String,String> dp) {

        Taf.utils().log().info("Creating and signing new Transaction History");
        String consentId = Consent.createConsent(excel.getValueForCurrentIteration("debtorAccount"));
        String authId = Consent.initiateConsentSigning(consentId);

        AuthMethodRequestBodyModel consentBody = new AuthMethodRequestBodyModel(dp);
        Consent.selectSigningMethod(consentId, authId, consentBody);
        Consent.checkConsentSigningStatusBecomesFinalised(consentId, authId);
        Taf.utils().log().info("Consent is created with id: '" + consentId + "'");
        Consent.setConsentId(consentId);

        Taf.api().rest().addHeader("Consent-ID", consentId);
        Consent.getConsentDetails(consentId);
        Taf.utils().log().info("Creating and signing new Transaction History");
        accountId= getAccountListForTransactionHistory(consentId);
        accountId = accountId.replaceAll("[^a-zA-Z0-9]", "");
        open(getTransactionHistoryUrl(accountId,getFutureDate(-2,"yyyy-MM-dd"),getFutureDate(0,"yyyy-MM-dd"),"booked"));
        Authorization.loginToSignTransactionHistory();
        //checkTransactionSigningStatusBecomesSigned(consentId,accountId,)
        return new TransactionHistoryPage();
    }
    public static String createAndSignTransactionHistoryAndDownload(Map<String, String> dp) throws InterruptedException {
        Taf.utils().log().info("Creating and signing new Transaction History");
        String consentId = Consent.createConsent(excel.getValueForCurrentIteration("debtorAccount"));
        String authId = Consent.initiateConsentSigning(consentId);

        AuthMethodRequestBodyModel consentBody = new AuthMethodRequestBodyModel(dp);
        Consent.selectSigningMethod(consentId, authId, consentBody);
        Consent.checkConsentSigningStatusBecomesFinalised(consentId, authId);
        Taf.utils().log().info("Consent is created with id: '" + consentId + "'");
        Consent.setConsentId(consentId);

        Taf.api().rest().addHeader("Consent-ID", consentId);
        Consent.getConsentDetails(consentId);
        Taf.utils().log().info("Creating and signing new Transaction History");
        accountId= getAccountListForTransactionHistory(consentId);
        accountId = accountId.replaceAll("[^a-zA-Z0-9]", "");

        statementId= initateTranscationHistory(accountId,getFutureDate(-1,"yyyy-MM-dd"),getFutureDate(0,"yyyy-MM-dd"),"booked");

        authorisationId=createTransactionHistory(accountId,statementId);

        selectSigningMethodTransactionHistory(consentId,accountId,statementId,authorisationId,consentBody);
      //  checkTransactionSigningStatusBecomesSigned(accountId,statementId);
        signingStatus=getTransactionSigningStatus(accountId,statementId);
        getTransactionSigningDownload(consentId,accountId,statementId);
        return signingStatus;
    }

    @Step("Cancel Transaction History by signing UI")
    public static void openCancelTransactionHistoryFromBrowser(Map<String,String> dp,String debtorAccount, String valueToMatch) {

        Taf.utils().log().info("Creating and signing new Transaction History");
        String consentId = Consent.createConsent(debtorAccount);
        String authId = Consent.initiateConsentSigning(consentId);

        AuthMethodRequestBodyModel consentBody = new AuthMethodRequestBodyModel(dp);
        Consent.selectSigningMethod(consentId, authId, consentBody);
        Consent.checkConsentSigningStatusBecomesFinalised(consentId, authId);
        Taf.utils().log().info("Consent is created with id: '" + consentId + "'");
        Consent.setConsentId(consentId);

        Taf.api().rest().addHeader("Consent-ID", consentId);
        Consent.getConsentDetails(consentId);
        Taf.utils().log().info("Creating and signing new Transaction History");
        accountId= getAccountListForTransactionHistory(consentId);
        accountId = accountId.replaceAll("[^a-zA-Z0-9]", "");
        Taf.utils().log().info("Creating new consent request");

        String hrefLink= Taf.api().rest()
                .addHeader("Tpp-Redirect-Preferred", "true")
                .addHeader("Tpp-Redirect-URI", "https://localhost/success")
                .addHeader("Tpp-Nok-Redirect-URI", "https://localhost/fail")
                . addQueryParameter("DateFrom", getFutureDate(-2,"yyyy-MM-dd")).addQueryParameter("DateTo", getFutureDate(0,"yyyy-MM-dd")).addQueryParameter("BookingStatus", "booked")
                // .addRequestBody(new ConsentCreationPayload(iban))
                .httpPost("/accounts/%s/transactions",accountId)
                .hasStatusCode(HttpStatus.SC_CREATED)
                .extractStringValue("_links.scaRedirect.href");

        String statementId = Taf.api().rest().extractStringValue("statementId");
        open(hrefLink);
        Authorization.loginToSignTransactionHistory();
        SelenideElement buttonSign = $x("//button[@class='button layout-link size-default']/span");
        buttonSign.shouldBe(Condition.visible.because("Cancel Link should be visible")).click();
        String Status = TransactionHistory.getStatementStatus(accountId,statementId);
        if (Status.equalsIgnoreCase(valueToMatch)) {
            Taf.utils().log().info("Statement Status is :" + Status);
        } else {
            Taf.utils().log().error("Statement Status is :" + Status);
        }
    }

    @Step("Call api, get /transaction/{0}/authorisations/{1}/status")
    public static String getStatementStatus(String accountId,String statementId) {
        Taf.utils().log().info("Getting consent signing status");
        return Taf.api().rest()
                .httpGet("/accounts/%s/transactions/%s/status", accountId,statementId)
                .hasStatusCode(HttpStatus.SC_OK)
                .extractStringValue("statementStatus");
    }
}