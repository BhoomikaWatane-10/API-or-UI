package com.luminor.api.pojo.tpp;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.luminor.api.endpoints.Tpp;
import com.luminor.taf.Taf;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class TppRegistrationPayload {

  private String appName;
  private ArrayList<String> contacts;
  private ArrayList<String> redirectUris;

  @JsonCreator
  public TppRegistrationPayload() {
    this.appName = "AutomationApp" + Taf.utils().numbers().getRandomNumberWithNDigits(8);
    Tpp.setAppName(getAppName());
    contacts = new ArrayList<>();
    redirectUris = new ArrayList<>();
    contacts.add("admin@tpp-system-a.com");
    redirectUris.add(Taf.utils().config().getEnvironmentProperty("redirect.url"));
  }
}
