package com.luminor.api.pojo.auth;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class Value {

  private String mandateId;
  private String customerType;

  @JsonCreator
  public Value(
      @JsonProperty("mandateId") String mandateId, @JsonProperty("customerType") String customerType) {
    this.mandateId = mandateId;
    this.customerType = customerType;
  }
}
