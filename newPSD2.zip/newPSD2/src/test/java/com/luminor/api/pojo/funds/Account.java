package com.luminor.api.pojo.funds;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Setter;

@Setter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class Account {

  private String iban;

  @JsonCreator
  public Account(String iban) {
    this.iban = iban;
  }
}
