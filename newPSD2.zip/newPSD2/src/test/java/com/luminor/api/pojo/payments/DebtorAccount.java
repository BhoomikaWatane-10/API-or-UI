package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Setter;

@Setter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class DebtorAccount {

  private String iban;

  @JsonCreator
  public DebtorAccount(String debtorAccount) {
    this.iban = debtorAccount;
  }
}
