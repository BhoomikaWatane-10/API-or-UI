package com.luminor.api.endpoints;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.api.models.blob.BlobModel;
import io.qameta.allure.Step;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.util.ArrayList;
import java.util.List;
import org.apache.hc.core5.http.HttpStatus;

public class Blob {

  @Step("Update information to json blob cloud")
  public static void putJsonBlob(List<BlobModel> body, String blobId) {
    RestAssured
        .given()
        .filter(new AllureRestAssured())
        .baseUri("https://jsonblob.com")
        .basePath("/api/jsonBlob/")
        .contentType(ContentType.JSON)
        .when()
        .body(body)
        .put(blobId)
        .then()
        .statusCode(200);
  }

  @Step("Get information from jsonBlob cloud")
  public static List<BlobModel> getJsonBlob(String blobId) {
    ObjectMapper mapper = new ObjectMapper();

    Response response = RestAssured
        .given()
        .filter(new AllureRestAssured())
        .baseUri("https://jsonblob.com")
        .basePath("/api/jsonBlob/")
        .when()
        .get(blobId)
        .then()
        .statusCode(HttpStatus.SC_OK)
        .extract()
        .response();

    JsonNode jsonNode = response.as(JsonNode.class);

    return mapper.convertValue(jsonNode, new TypeReference<List>(){});
  }
}