package com.luminor.api.pojo.funds;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class ConfirmAvailableFundsResponse {

  private boolean fundsAvailable;

  @JsonCreator
  public ConfirmAvailableFundsResponse(@JsonProperty("fundsAvailable") boolean fundsAvailable) {
    this.fundsAvailable = fundsAvailable;
  }
}
