package com.luminor.api.pojo.tpp;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class ChangeTppStatusPayload {

  private String status;

  @JsonCreator
  public ChangeTppStatusPayload(String status) {
    this.status = status;
  }
}
