package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DeleteSignedPaymentResponse {

  private String paymentId;
  private String authorisationId;
  private String canceled;

  @JsonCreator
  public DeleteSignedPaymentResponse(@JsonProperty("paymentId") String paymentId,
                                     @JsonProperty("authorisationId") String authorisationId, @JsonProperty("canceled") String canceled) {
    this.paymentId = paymentId;
    this.authorisationId = authorisationId;
    this.canceled = canceled;
  }
}
