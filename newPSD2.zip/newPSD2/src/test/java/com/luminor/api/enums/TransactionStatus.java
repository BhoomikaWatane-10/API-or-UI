package com.luminor.api.enums;

public enum TransactionStatus {
  ACTC("ACTC"), //Payment order validated and accepted
  ACSP("ACSP"), //Payment is authorised and signed
  PNDG("PNDG"), //Payment order with future date waiting for processing
  CANC("CANC"), //Payment order is cancelled by customer
  RJCT("RJCT"), //Error sending payment to core (timeout, validation errors)
  ACSC("ACSC"); //Payment is successfully processed in core

  private String value;

  TransactionStatus(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
