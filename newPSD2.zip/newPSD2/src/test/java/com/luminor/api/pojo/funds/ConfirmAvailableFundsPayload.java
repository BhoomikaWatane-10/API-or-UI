package com.luminor.api.pojo.funds;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class ConfirmAvailableFundsPayload {

  private InstructedAmount instructedAmount;
  private Account account;

  @JsonCreator
  public ConfirmAvailableFundsPayload(String iban, String amount) {
    instructedAmount = new InstructedAmount(amount);
    account = new Account(iban);
  }
}
