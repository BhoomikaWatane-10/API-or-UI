package com.luminor.api.enums;

public enum Error {
  ROLE_INVALID("The TPP does not have the correct PSD2 role to access this service"),
  TOKEN_EXPIRED("The token has expired"),
  TOKEN_INVALID("CIAM authorisation failed, token not valid"),
  FORMAT_ERROR("Format of certain request fields are not matching"),
  CONSENT_UNKNOWN("The Consent-ID cannot be matched by the ASPSP relative to the TPP"),
  CONSENT_EXPIRED("The consent was created by this TPP but has expired and needs to be renewed"),
  CONSENT_INVALID_UUID("\"Consent-ID\" header value is not a valid UUID"),
  CONSENT_NOT_SET("\"Consent-ID\" header is not set"),
  STATUS_INVALID("The request could not be completed due to a conflict with the current state of the target resource"),
  SERVICE_BLOCKED("This service is not reachable for the addressed PSU"),
  TRANSACTIONS_PERIOD_INVALID("Requested time period out of bound"),
  TRANSACTIONS_PARAMETER_NOT_SUPPORTED("The parameter is not supported by the API provider");

  private String value;

  Error(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
