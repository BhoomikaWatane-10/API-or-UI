package com.luminor.api.pojo.consents;

import lombok.Getter;

@Getter
public class AccountsListResponse {

  private String iban;
  private String currency;
}
