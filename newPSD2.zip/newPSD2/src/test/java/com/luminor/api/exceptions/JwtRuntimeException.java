package com.luminor.api.exceptions;

public class JwtRuntimeException extends RuntimeException {

    public static class Constants {
        public static final String ERR_JWT_SIGN_EXCEPTION = "ERR_JWT_SIGN_EXCEPTION";
    }

    public JwtRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }
}
