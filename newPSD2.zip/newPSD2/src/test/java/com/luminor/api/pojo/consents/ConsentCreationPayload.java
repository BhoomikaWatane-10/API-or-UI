package com.luminor.api.pojo.consents;

import static com.luminor.utils.DateHelper.getFutureDate;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.List;
import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class ConsentCreationPayload {

  private Access access;
  private boolean recurringIndicator;
  private String validUntil;
  private int frequencyPerDay;
  private boolean combinedServiceIndicator;

  @JsonCreator
  public ConsentCreationPayload(String iban) {
    this.access = new Access(iban);
    setDefaultValues();
  }

  @JsonCreator
  public ConsentCreationPayload(List<String> ibanList) {
    this.access = new Access(ibanList);
    setDefaultValues();
  }

  private void setDefaultValues() {
    this.recurringIndicator = false;
    this.validUntil = getFutureDate(365, "yyyy-MM-dd");
    this.frequencyPerDay = 4;
    this.combinedServiceIndicator = false;
  }
}
