
package com.luminor.api.pojo.payments;


import com.fasterxml.jackson.annotation.*;
import lombok.Setter;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;

@Setter
@JsonAutoDetect(fieldVisibility = ANY)
public class CreditorAgent {

   public String bic;

   @JsonCreator
    public CreditorAgent(String bic) {
        super();
        this.bic = bic;
    }

}
