package com.luminor.api.endpoints;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.BasePsd2Test;
import com.luminor.pageobjects.BlankedIBANPaymentPage;
import com.luminor.pageobjects.InstantPaymentInsufficientPage;
import com.luminor.pageobjects.InstantPaymentPage;
import com.luminor.taf.test.api.rest.Rest;
import com.luminor.api.enums.TransactionStatus;
import com.luminor.api.pojo.ErrorResponse;
import com.luminor.api.pojo.payments.*;
import com.luminor.taf.Taf;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.Authorization;
import com.luminor.utils.models.AuthMethodRequestBodyModel;
import io.qameta.allure.Step;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.awaitility.core.ConditionTimeoutException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.codeborne.selenide.Selenide.*;
import static com.luminor.utils.DateHelper.getFutureDate;
import static org.awaitility.Awaitility.await;

public class InstantPayments extends BasePsd2Test {

    public static final String PAYMENT_SIGNING_STATUS_FINALISED = "finalised";
    public static final String PAYMENT_SIGNING_STATUS_CANCELED = "canceled";
    //instructedAmountfullPayload;
    private String debtorName = getPropertyFromFile("debtorName");
    // debtorAccount;
    private String debtorId = getPropertyFromFile("debtorId");
    private String debtorIdType = getPropertyFromFile("debtorIdType");
    private String debtorType = getPropertyFromFile("debtorType");
    //debtorAddress;
    private String creditorName = getPropertyFromFile("creditorName");
    // creditorAccount;
    ////creditorAgent;
    private String creditorId = getPropertyFromFile("creditorId");
    private String creditorIdType = getPropertyFromFile("creditorIdType");
    private String creditorType = getPropertyFromFile("creditorType");
    //creditorAddress;
    private String remittanceInformationUnstructured = getPropertyFromFile("remittanceInformationUnstructured");
    private String requestExecutionDate = getFutureDate(0, "yyyy-MM-dd");
    private String endToEndIdentification = getPropertyFromFile("endToEndIdentification");
    private String instructionId = getPropertyFromFile("instructionId");
    private String paymentServiceLevel = getPropertyFromFile("paymentServiceLevel");
    // private String paymentReasonCode=getPropertyFromFile("paymentReasonCode");
    private String purposeCode = getPropertyFromFile("purposeCode");
    private String chargeBearer = getPropertyFromFile("chargeBearer");
    private String ultimateDebtorName = getPropertyFromFile("ultimateDebtorName");
    private String ultimateDebtorId = getPropertyFromFile("ultimateDebtorId");
    private String ultimateDebtorType = getPropertyFromFile("ultimateDebtorType");
    private String ultimateDebtorIdType = getPropertyFromFile("ultimateDebtorIdType");
    private String ultimateCreditorName = getPropertyFromFile("ultimateCreditorName");
    private String ultimateCreditorId = getPropertyFromFile("ultimateCreditorId");
    private String ultimateCreditorType = getPropertyFromFile("ultimateCreditorType");
    private String ultimateCreditorIdType = getPropertyFromFile("ultimateCreditorIdType");
    private String debitoriban = getPropertyFromFile("debitoriban");
    private String Debitorcountry = getPropertyFromFile("Debitorcountry");
    private String Debitorstreet = getPropertyFromFile("Debitorstreet");
    private String currency = getPropertyFromFile("currency");
    private String bic = getPropertyFromFile("bic");

    private String CreditorCountry = getPropertyFromFile("CreditorCountry");
    private String Creditorstreet = getPropertyFromFile("Creditorstreet");

    private String Creditoriban = getPropertyFromFile("Creditoriban");
    private String reference = getPropertyFromFile("reference");
    private String corporateIBNLT = getPropertyFromFile("corporateIBANLT");
    private String EEIBAN = getPropertyFromFile("RetailIBANEE");
    private String LVIBAN = getPropertyFromFile("RetailIBANLV");
    private String IbanForInsufficientFund = getPropertyFromFile("IbanForInsuffientFund");
    private String CreditorBlockedIBAN = getPropertyFromFile("CreditorBlockedIBAN");

    Float AmountForInsufficentFund = Float.parseFloat(getPropertyFromFile("AmountForInsuffientFund"));

    private static ExcelDataProviderApi excel = Taf.utils().excel();
    String Exceeds35Character = RandomStringUtils.randomAlphanumeric(36).toUpperCase();

    String Exceeds70Character = RandomStringUtils.randomAlphanumeric(71).toUpperCase();
    String Exceeds140Character = RandomStringUtils.randomAlphanumeric(145).toUpperCase();
    Float amount = Float.parseFloat(getPropertyFromFile("amount"));

    InstructedAmountfullPayload instructedAmountfullPayload;
    DebtorAccount debtorAccount;
    DebtorAddress debtorAddress;
    CreditorAgent creditorAgent;
    CreditorAddress creditorAddress;
    CreditorAccount creditorAccount;
    //RemittanceInformationStructured remittanceInformationStructured;

    public InstantPayments() throws IOException {
    }

    public void fetchValuefromJsonList(List<String> value, String valueTomatch, List<String> text) {
        for (int i = 0; i < value.size(); i++) {
            if ((value.get(i)).equals(valueTomatch)) {
                Taf.utils().log().info("Expected Value: " + valueTomatch + " Actual value  :" + value.get(i) + " is Matched");
                Taf.utils().log().info("Text is:" + text.get(i));
                break;
            } else {
                Taf.utils().log().error("Expected Value: " + valueTomatch + " Actual value  :" + value.get(i) + " not matched");
            }
        }

    }

    @Step("Create and sign instant SEPA payment")
    public String createAndSignInstantSepaPayment(Map<String, String> dp) {
        debtorAccount = new DebtorAccount(debitoriban);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        Taf.utils().log().info("Creating and signing instant SEPA payment");
        String paymentId =
                createInstantSepaPayment(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel,
                        //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        AuthMethodRequestBodyModel paymentBody = new AuthMethodRequestBodyModel(dp);
        String authorisationId = InstantPayments.initiateInstantPaymentSigning(paymentId);
        InstantPayments.selectInstantPaymentSigningMethod(paymentId, authorisationId, paymentBody);
        InstantPayments.checkInstantPaymentSigningStatusBecomesFinalised(paymentId, authorisationId);
        InstantPayments.getInstantPaymentDetails(paymentId);
        InstantPayments.getInstantPaymentStatus(paymentId);
        return paymentId;
    }


    @Step("Create instatnt SEPA payment via API and sign from browser")
    public InstantPaymentPage openCreatedInstantPaymentFromBrowser() throws IOException {
        open(createInstantSepaPaymentAndReturnUrl());
        Authorization.loginToSignInstantPayment();

        return new InstantPaymentPage();
    }

    @Step("Create instatnt SEPA payment via API and sign from browser")
    public BlankedIBANPaymentPage openCreatedInstantPaymentFromBrowserForBlankIBANUsingUI() throws IOException {
        open(createInstantSepaPaymentAndReturnUrlWithBlankIBANUsingUI());
        Authorization.loginToSignInstantPayment();

        return new BlankedIBANPaymentPage();
    }

    @Step("Check transaction status becomes '{1}'")
    public static void checkInstantPaymentTransactionStatus(String paymentId,
                                                            TransactionStatus expectedTransactionStatus) {

        Integer timeoutMiliSec = Taf.utils().config().getIntPropertyValue("selenide.timeout");
        Integer timoutSec = timeoutMiliSec / 1000;

        int pollingInterval = 5;
        try {
            await().atMost(timoutSec, TimeUnit.SECONDS).pollInterval(pollingInterval, TimeUnit.SECONDS)
                    .until(() ->
                            getInstantPaymentDetails(paymentId).getTransactionStatus()
                                    .equals(expectedTransactionStatus.getValue())
                    );
        } catch (ConditionTimeoutException e) {
            Taf.utils().log().error(
                    "Payment transaction status has not changed withing the given time limit of '" + timoutSec
                            + "' seconds. Expected transaction status: '" + expectedTransactionStatus.getValue()
                            + "', but was '" + getInstantPaymentDetails(paymentId).getTransactionStatus() + "'");
        }
    }

    @Step("Get payment fee")
    public static void getPaymentFee(String debtorAccount, String creditorAccount) {
        Taf.utils().log().info(
                "Getting payment fee when payment is made from '" + debtorAccount + "' to '"
                        + creditorAccount + "' account");
        Taf.api().rest()
                .addRequestBody(new PaymentFeePayload(debtorAccount, creditorAccount))
                .httpPost("/payment_fee")
                .hasStatusCode(HttpStatus.SC_OK)
                .validateJSONSchema("testdata/schemas/rest_response_post_payment_fee.json");
    }

    @Step("Check payment creation is unavailable")
    public static ErrorResponse checkPaymentCreationUnavailable(Object body,
                                                                int expectedHttpStatusCode) {
        Taf.utils().log().info("Checking that payment creation is unavailable");
        return Taf.api().rest()
                .addRequestBody(body)
                .httpPost("/payments/instant-sepa-credit-transfers")
                .hasStatusCode(expectedHttpStatusCode)
                .extractArrayAsList("errors", ErrorResponse.class)
                .get(0);
    }

    @Step("Get payment details")
    public static PaymentDetailsResponse getInstantPaymentDetails(String paymentId) {
        Taf.utils().log().info("Getting payment details for payment with id '" + paymentId + "'");
        return Taf.api().rest()
                .httpGet("/payments/instant-sepa-credit-transfers/%s", paymentId)
                .hasStatusCode(HttpStatus.SC_OK)
                .getResponseAsJavaObject(PaymentDetailsResponse.class);
    }

    @Step("Call api, post /payments/sepa-credit-transfers")
    private String createInstantSepaPayment(InstructedAmountfullPayload instructedAmountfullPayload, String debtorName, DebtorAccount debtorAccount, String debtorId, String debtorIdType,
                                            String debtorType, DebtorAddress debtorAddress, String creditorName,
                                            CreditorAccount creditorAccount, CreditorAgent creditorAgent, String creditorId,
                                            String creditorIdType, String creditorType, CreditorAddress creditorAddress,
                                            String remittanceInformationUnstructured,
                                            String requestExecutionDate, String endToEndIdentification,
                                            String instructionId, String paymentServiceLevel,// String paymentReasonCode,
                                            String purposeCode, String chargeBearer, String ultimateDebtorName, String ultimateDebtorId, String ultimateDebtorType,
                                            String ultimateDebtorIdType, String ultimateCreditorName, String ultimateCreditorId, String ultimateCreditorType, String ultimateCreditorIdType) {
        Taf.utils().log().info(
                "Creating SEPA payment from account '" + debitoriban + "' to '" + Creditoriban
                        + "'");
        return Taf.api().rest()
                .addRequestBody(new CreatePaymentFullPayLoad(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel, //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType))
                .httpPost("/payments/instant-sepa-credit-transfers")
                .hasStatusCode(HttpStatus.SC_CREATED)
                .extractStringValue("paymentId");
    }

    @Step("Call api, post /payments/sepa-credit-transfers")
    private String createInstantSepaPaymentRemmitanceInfromationStructured(InstructedAmountfullPayload instructedAmountfullPayload, String debtorName, DebtorAccount debtorAccount, String debtorId, String debtorIdType,
                                                                           String debtorType, DebtorAddress debtorAddress, String creditorName,
                                                                           CreditorAccount creditorAccount, CreditorAgent creditorAgent, String creditorId,
                                                                           String creditorIdType, String creditorType, CreditorAddress creditorAddress,
                                                                           RemittanceInformationStructured remittanceInformationstructured,
                                                                           String requestExecutionDate, String endToEndIdentification,
                                                                           String instructionId, String paymentServiceLevel,// String paymentReasonCode,
                                                                           String purposeCode, String chargeBearer, String ultimateDebtorName, String ultimateDebtorId, String ultimateDebtorType,
                                                                           String ultimateDebtorIdType, String ultimateCreditorName, String ultimateCreditorId, String ultimateCreditorType, String ultimateCreditorIdType) {
        Taf.utils().log().info(
                "Creating SEPA payment from account '" + debitoriban + "' to '" + Creditoriban
                        + "'");
        return Taf.api().rest()
                .addRequestBody(new CreatePaymentFullPayLoadWithRemmitanceInfromationStructred(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel, //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType))
                .httpPost("/payments/instant-sepa-credit-transfers")
                .hasStatusCode(HttpStatus.SC_CREATED)
                .extractStringValue("paymentId");
    }

    @Step("Call api, post /payments/instant-sepa-credit-transfers")
    private String createInstantSepaPaymentAndReturnUrl() throws IOException {

        debtorAccount = new DebtorAccount(debitoriban);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);
        Taf.utils().log().info(
                "Creating instant SEPA payment from account '" + getPropertyFromFile("debitoriban") + "' to '" + getPropertyFromFile("Creditoriban")
                        + "'");
        return Taf.api().rest()
                .addHeader("Tpp-Redirect-Preferred", "true")
                .addHeader("Tpp-Redirect-URI", "https://www.microsoft.com")
                .addHeader("Tpp-Nok-Redirect-URI", "https://www.google.com")
                .addRequestBody(new CreatePaymentFullPayLoad(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel, //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType))
                .httpPost("/payments/instant-sepa-credit-transfers")
                .hasStatusCode(HttpStatus.SC_CREATED)
                .extractStringValue("_links.scaRedirect.href");

    }

    @Step("Call api, post /payments/sepa-credit-transfers/{0}/authorisations")
    private static String initiateInstantPaymentSigning(String paymentId) {
        Taf.utils().log().info("Initiating payment signing for payment: '" + paymentId + "'");
        return Taf.api().rest()
                .httpPost("/payments/instant-sepa-credit-transfers/%s/authorisations", paymentId)
                .hasStatusCode(HttpStatus.SC_CREATED)
                .extractStringValue("authorisationId");
    }

    @Step("Call api, put /payments/sepa-credit-transfers/{0}/authorisations/{1}")
    private static void selectInstantPaymentSigningMethod(String paymentId, String authorisationId, AuthMethodRequestBodyModel body) {
        Taf.utils().log().info("Selecting '" + body.getAuthMethod() + "' as payment signing method");
        Taf.api().rest()
                .addRequestBody(body)
                .httpPut("/payments/instant-sepa-credit-transfers/%s/authorisations/%s", paymentId,
                        authorisationId)
                .hasStatusCode(HttpStatus.SC_OK);
    }

    @Step("Call api, get /payments/sepa-credit-transfers/{0}/authorisations/{1}/status")
    private static String getInstantPaymentSigningStatus(String paymentId, String authorisationId) {
        Taf.utils().log().info("Getting payment signing status");
        return Taf.api().rest()
                .httpGet("/payments/instant-sepa-credit-transfers/%s/authorisations/%s/status", paymentId,
                        authorisationId)
                .hasStatusCode(HttpStatus.SC_OK)
                .extractStringValue("scaStatus");
    }

    @Step("Call api, get /payments/sepa-credit-transfers/{0}/authorisations/{1}/status")
    private static String getInstantPaymentStatus(String paymentId) {
        Taf.utils().log().info("Getting payment signing status");
        return Taf.api().rest()
                .httpGet("/payments/instant-sepa-credit-transfers/%s/status", paymentId)

                .hasStatusCode(HttpStatus.SC_OK)
                .extractStringValue("transactionStatus");
    }

    @Step("Check payment status, recall api")
    private static void checkInstantPaymentSigningStatusBecomesFinalised(String paymentId,
                                                                         String authorisationId) {
        Taf.utils().log()
                .info("Checking payment signing status becomes '" + PAYMENT_SIGNING_STATUS_FINALISED + "'");

        Integer timeoutMilliSec = Taf.utils().config().getIntPropertyValue("selenide.timeout");
        Integer timeoutSec = timeoutMilliSec / 1000;

        int pollingInterval = 5;
        try {
            await().atMost(timeoutSec, TimeUnit.SECONDS).pollInterval(pollingInterval, TimeUnit.SECONDS)
                    .until(() ->
                            getInstantPaymentSigningStatus(paymentId, authorisationId).equals(PAYMENT_SIGNING_STATUS_FINALISED)
                    );
        } catch (ConditionTimeoutException e) {
            Taf.utils().log().error(
                    "Payment was not signed withing the given time limit of '" + timeoutSec
                            + "' seconds. Expected payment signing status: '" + PAYMENT_SIGNING_STATUS_FINALISED
                            + "'");
        }
    }

    @Step("Call api, post /payments/instant-sepa-credit-transfers")
    private String createPaymentForFieldValidation(InstructedAmountfullPayload instructedAmountfullPayload, String debtorName, DebtorAccount debtorAccount, String debtorId, String debtorIdType,
                                                   String debtorType, DebtorAddress debtorAddress, String creditorName,
                                                   CreditorAccount creditorAccount, CreditorAgent creditorAgent, String creditorId,
                                                   String creditorIdType, String creditorType, CreditorAddress creditorAddress,
                                                   String remittanceInformationUnstructured,
                                                   String requestExecutionDate, String endToEndIdentification,
                                                   String instructionId, String paymentServiceLevel, //String paymentReasonCode,
                                                   String purposeCode, String chargeBearer, String ultimateDebtorName, String ultimateDebtorId, String ultimateDebtorType,
                                                   String ultimateDebtorIdType, String ultimateCreditorName, String ultimateCreditorId, String ultimateCreditorType, String ultimateCreditorIdType) {
        Taf.utils().log().info(
                "Creating SEPA payment from account '" + debtorAccount + "' to '" + creditorAccount
                        + "'");
        Rest createPayment = Taf.api().rest()
                .addRequestBody(new CreatePaymentFullPayLoad(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel, //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType))
                .httpPost("/payments/instant-sepa-credit-transfers");

        String responsePayment = createPayment.toString();
        Rest status = createPayment.hasStatusCode(HttpStatus.SC_BAD_REQUEST);
        Taf.utils().log().info("Status is " + status.toString());
        return responsePayment;
    }

    @Step("Call api, post /payments/instant-sepa-credit-transfers")
    private String createPaymentForFieldValidationRemmitanceInformationStructured(InstructedAmountfullPayload instructedAmountfullPayload, String debtorName, DebtorAccount debtorAccount, String debtorId, String debtorIdType,
                                                                                  String debtorType, DebtorAddress debtorAddress, String creditorName,
                                                                                  CreditorAccount creditorAccount, CreditorAgent creditorAgent, String creditorId,
                                                                                  String creditorIdType, String creditorType, CreditorAddress creditorAddress,
                                                                                  RemittanceInformationStructured remittanceInformationStructured1,
                                                                                  String requestExecutionDate, String endToEndIdentification,
                                                                                  String instructionId, String paymentServiceLevel, //String paymentReasonCode,
                                                                                  String purposeCode, String chargeBearer, String ultimateDebtorName, String ultimateDebtorId, String ultimateDebtorType,
                                                                                  String ultimateDebtorIdType, String ultimateCreditorName, String ultimateCreditorId, String ultimateCreditorType, String ultimateCreditorIdType) {
        Taf.utils().log().info(
                "Creating SEPA payment from account '" + debtorAccount + "' to '" + creditorAccount
                        + "'");
        Rest createPayment = Taf.api().rest()
                .addRequestBody(new CreatePaymentFullPayLoadWithRemmitanceInfromationStructred(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationStructured1,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel, //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType))
                .httpPost("/payments/instant-sepa-credit-transfers");

        String responsePayment = createPayment.toString();
        Rest status = createPayment.hasStatusCode(HttpStatus.SC_BAD_REQUEST);
        Taf.utils().log().info("Status is " + status.toString());
        return responsePayment;
    }


    @Step("Call api, post /payments/instant-sepa-credit-transfers")
    private String createPaymentForOtherThenLT(InstructedAmountfullPayload instructedAmountfullPayload, String debtorName, DebtorAccount debtorAccount, String debtorId, String debtorIdType,
                                               String debtorType, DebtorAddress debtorAddress, String creditorName,
                                               CreditorAccount creditorAccount, CreditorAgent creditorAgent, String creditorId,
                                               String creditorIdType, String creditorType, CreditorAddress creditorAddress,
                                               String remittanceInformationUnstructured,
                                               String requestExecutionDate, String endToEndIdentification,
                                               String instructionId, String paymentServiceLevel, //String paymentReasonCode,
                                               String purposeCode, String chargeBearer, String ultimateDebtorName, String ultimateDebtorId, String ultimateDebtorType,
                                               String ultimateDebtorIdType, String ultimateCreditorName, String ultimateCreditorId, String ultimateCreditorType, String ultimateCreditorIdType) {
        Taf.utils().log().info(
                "Creating SEPA payment from account '" + debtorAccount + "' to '" + creditorAccount
                        + "'");
        Rest createPayment = Taf.api().rest()
                .addRequestBody(new CreatePaymentFullPayLoad(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel, //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType))
                .httpPost("/payments/instant-sepa-credit-transfers");

        String responsePayment = createPayment.toString();
        Rest status = createPayment.hasStatusCode(HttpStatus.SC_FORBIDDEN);
        Taf.utils().log().info("Status is " + status.toString());
        return responsePayment;
    }

    @Step("Invalid or mising currency check for Instant Payment")
    public void InvalidMisingCurrency(String valueTomatch) throws IOException {
        debtorAccount = new DebtorAccount(debitoriban);
        String invalidCurrency = getPropertyFromFile("invalidCurrency");
        String MissingCurrency = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(invalidCurrency, amount);
        InstructedAmountfullPayload instructedAmountfullPayloadMissing;
        instructedAmountfullPayloadMissing = new InstructedAmountfullPayload("", amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalid = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel, //paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response:" + responseInvalid.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);

        String responseMissing = createPaymentForFieldValidation(instructedAmountfullPayloadMissing, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel, //paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);

        Taf.utils().log().info("Response of Missing currency:" + responseMissing.toString());

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or mising amount check for Instant Payment")
    public void AmountTobeZero(String valueTomatch) throws IOException {
        debtorAccount = new DebtorAccount(debitoriban);
        float AmountToZero = 0.0f;
        float MissingAmount = -1.0f;
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, AmountToZero);
        InstructedAmountfullPayload instructedAmountfullPayloadMissing;
        instructedAmountfullPayloadMissing = new InstructedAmountfullPayload(currency, MissingAmount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseAmountTobeZero = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel, //paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response from amount zero:" + responseAmountTobeZero.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);
    }

    @Step("Invalid or negative amount check for Instant Payment")
    public void amountTobeMissing(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);

        float MissingAmount = -1.0f;

        InstructedAmountfullPayload instructedAmountfullPayloadMissing;
        instructedAmountfullPayloadMissing = new InstructedAmountfullPayload(currency, MissingAmount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);
        String responseMissingAmmont = createPaymentForFieldValidation(instructedAmountfullPayloadMissing, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel, //paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);

        Taf.utils().log().info("Response of amount negative:" + responseMissingAmmont.toString());
        Taf.utils().log().info("Response:" + responseMissingAmmont.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);
        fetchValuefromJsonList(value, valueTomatch, text);


    }


    @Step("Invalid or mising DebitorIdType check for Instant Payment")
    public void InvalidMissingDebitorIdType(String valueTomatch) throws IOException {
        debtorAccount = new DebtorAccount(debitoriban);
        String invalidDebitorIdType = getPropertyFromFile("invalidDebitorIdType");
        String misingDebitorIdType = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidDebitorIdType = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, invalidDebitorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel, //paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response from InvalidDebitorIdType:" + responseInvalidDebitorIdType.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);

        String responseMissingDebitorIDType = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, misingDebitorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response from missing DebitorIdType:" + responseMissingDebitorIDType.toString());

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or mising Debitor Country check for Instant Payment")
    public void InvalidMissingDebitorCountry(String valueTomatch) throws IOException {
        debtorAccount = new DebtorAccount(debitoriban);
        String invalidDebitorIdCountry = "AA";
        String misingDebitorCountry = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(invalidDebitorIdCountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidDebitorCountry = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response from Invalid Debitor Country:" + responseInvalidDebitorCountry.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);

        DebtorAddress debtorAddressMissing = new DebtorAddress(misingDebitorCountry, Debitorstreet);
        String responseMissingDebitorCountry = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddressMissing, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel, //paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response from Missing DebitorCountry :" + responseMissingDebitorCountry.toString());

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Mising UltimateDebitorName check for Instant Payment")
    public void missingUltimateDebitorName(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        String missingUltimateDebitorName = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseMissingUltimateDebitorName = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,             //paymentReasonCode,
                purposeCode, chargeBearer, missingUltimateDebitorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of missing UltimateDebitorName:" + responseMissingUltimateDebitorName.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);
    }

    @Step("Invalid or mising creditor Id check for Instant Payment")
    public void MissingCreditorId(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        //  String invalidCreditorId = "2581475";
        String misingCreditorId = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseMissingCreditorId = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, misingCreditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of Inavlid CreditorId:" + responseMissingCreditorId.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or mising creditor Name check for Instant Payment")
    public void InvalidMissingCreditorName(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
      //  String invalidCreditorName = "AA";
        String misingCreditorName = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidCreditorName = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, "",
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of Invalid Creditor Name:" + responseInvalidCreditorName.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


        String responseMissingCreditorName = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, misingCreditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of missing Invalid creditor name:" + responseMissingCreditorName.toString());

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or mising creditor type check for Instant Payment")
    public void InvalidMissingCreditorType(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        String invalidCreditorType = "OrgId123";
        String misingCreditorType = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidCreditorType = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, invalidCreditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of Invalid Creditor Type:" + responseInvalidCreditorType.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


        String responseMissingCreditortype = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, misingCreditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of missing creditor Type:" + responseMissingCreditortype.toString());

        fetchValuefromJsonList(value, valueTomatch, text);


    }


    @Step("Invalid or mising creditor Id Type check for Instant Payment")
    public void InvalidMissingPurposeCode(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        String invalidPurposeCode = "Test";
        String misingPurposeCode = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidPurposeCode = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                invalidPurposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of invalid purpose code:" + responseInvalidPurposeCode.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


        String responseMissingPurposeCode = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                misingPurposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of missing purpose code:" + responseMissingPurposeCode.toString());

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or mising creditor Id Type check for Instant Payment")
    public void InvalidMissingCreditorIdType(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        String invalidCreditorIdType = "ABCD";
        String misingCreditorIdType = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidCreditorIdType = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                invalidCreditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of invalid creditor Id type:" + responseInvalidCreditorIdType.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


        String responseMissingCreditorIdtype = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                misingCreditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of missing creditor Id type:" + responseMissingCreditorIdtype.toString());

        fetchValuefromJsonList(value, valueTomatch, text);

    }

    @Step("Invalid or mising Request Execution Date Type check for Instant Payment")
    public void InvalidMissingRequestExecutionDate(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        String invalidRequestExecutionDateFuture = getFutureDate(30, "yyyy-MM-dd");
        String invalidRequestExecutionDatePast = getFutureDate(-30, "yyyy-MM-dd");
       // String misingRequestExecutionDate = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidRequestExecutiondateFuture = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                invalidRequestExecutionDateFuture, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of invalid Request Execution Date of Future Date :" + invalidRequestExecutionDateFuture + "" + responseInvalidRequestExecutiondateFuture.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);

        String responseInvalidRequestExecutiondatePast = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                invalidRequestExecutionDatePast, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of invalid Request Execution Date of Future Date :" + invalidRequestExecutionDatePast + "" + responseInvalidRequestExecutiondatePast.toString());
        List<String> value1 = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text1 = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value1, "CH04", text1);


      /*  String responseMissingRequestExecutionDate = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                misingRequestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of missing Request Execution Date:" + responseMissingRequestExecutionDate.toString());
        List<String> value2 = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text2 = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value2, "DT01", text2);*/

    }

    @Step("Invalid or mising Payment Service Level check for Instant Payment")
    public void InvalidMissingPaymentServiceLevel(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        ArrayList<String> invalidServiceLevel = new ArrayList<String>();
        invalidServiceLevel.add("SDVA");
        invalidServiceLevel.add("SVDE");
        invalidServiceLevel.add("URGP");
        invalidServiceLevel.add("URNS");

        String misingPaymentServiceLevel = "";
        for (int i = 0; i < invalidServiceLevel.size(); i++) {
            instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
            debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
            creditorAgent = new CreditorAgent(bic);
            creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
            creditorAccount = new CreditorAccount(Creditoriban);

            String responseInvalidServiceLevel = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                    debtorType, debtorAddress, creditorName,
                    creditorAccount, creditorAgent, creditorId,
                    creditorIdType, creditorType, creditorAddress,
                    remittanceInformationUnstructured,
                    requestExecutionDate, endToEndIdentification,
                    instructionId, invalidServiceLevel.get(i),// paymentReasonCode,
                    purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                    ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
            Taf.utils().log().info("Response of invalid Payment service level for param: " + invalidServiceLevel.get(i) + responseInvalidServiceLevel.toString());
            List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
            List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

            fetchValuefromJsonList(value, valueTomatch, text);
        }

        String responseMissingServiceLevel = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                debtorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, misingPaymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of missing charge Bearer:" + responseMissingServiceLevel.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");
        fetchValuefromJsonList(value, valueTomatch, text);

    }

    @Step("Invalid or mising charge bearer check for Instant Payment")
    public void InvalidMissingChargeBearer(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        ArrayList<String> invalidChargeBearer = new ArrayList<String>();
        invalidChargeBearer.add("DEBT");
        invalidChargeBearer.add("CRED");
        String misingChargeBearer = "";
        for (int i = 0; i < invalidChargeBearer.size(); i++) {
            instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
            debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
            creditorAgent = new CreditorAgent(bic);
            creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
            creditorAccount = new CreditorAccount(Creditoriban);

            String responseInvalidChargeBearer = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                    debtorType, debtorAddress, creditorName,
                    creditorAccount, creditorAgent, creditorId,
                    creditorIdType, creditorType, creditorAddress,
                    remittanceInformationUnstructured,
                    requestExecutionDate, endToEndIdentification,
                    instructionId, paymentServiceLevel,// paymentReasonCode,
                    purposeCode, invalidChargeBearer.get(i), ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                    ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
            Taf.utils().log().info("Response of invalid charge Bearer:" + responseInvalidChargeBearer.toString());
            List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
            List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

            fetchValuefromJsonList(value, valueTomatch, text);
        }

        String responseMissingChargeBearer = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, misingChargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of missing charge Bearer:" + responseMissingChargeBearer.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");
        fetchValuefromJsonList(value, valueTomatch, text);
    }

    @Step("Invalid or mising Debtor type check for Instant Payment")
    public void InvalidMissingDebtorType(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        String invalidDebtorType = "OrgId123";
        String missingDebtorType = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidDebtorType = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                invalidDebtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of Invalid Creditor Type:" + responseInvalidDebtorType.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


        String responseMissingDebtortype = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                missingDebtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of missing creditor Type:" + responseMissingDebtortype.toString());

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or Exceeds 35 RemittanceStructured check for Instant Payment")
    public void RemittanceStructuredExceeds35Character(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);

        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);


        String responseExceeds35RemittanceStructured = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, Exceeds35Character, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of exceeds 35 character RemittacnceStructured:" + responseExceeds35RemittanceStructured.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or Exceeds 70 Ultimate Debtor Name check for Instant Payment")
    public void UltimateDebtorNameExceeds70Character(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);

        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseUltimateDebtorName = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, Exceeds70Character, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of Inavlid Ultimate Debtor Name:" + responseUltimateDebtorName.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or Exceeds 70 Creditor Name check for Instant Payment")
    public void CreditorNameExceeds70Character(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);

        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseCreditorName = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, Exceeds70Character,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of Inavlid creditor Name:" + responseCreditorName.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }


    @Step("Invalid or Exceeds 35 character Id check for Instant Payment")
    public void InstructionIdExceeds35Character(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        // String Exceeds35Character =  RandomValueGenerator.generateRandomValueWithinRange(36,50);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseExceeds35charInstructionId = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                Exceeds35Character, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of exceeds 35 character instruction Id:" + responseExceeds35charInstructionId.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or Exceeds 70 debtor address Street check for Instant Payment")
    public void DebtorAddressStreetExceeds70Character(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);

        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Exceeds70Character);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseUltimateDebtorAddressStreet = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of Debtor Address Street Name:" + responseUltimateDebtorAddressStreet.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or Exceeds 35 End To end Notification Name check for Instant Payment")
    public void EndToEndNotifcationExceeds35Character(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);

        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseCreditorName = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, Exceeds35Character,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of End To End Notification:" + responseCreditorName.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or missing Remittance information unstructured check for Instant Payment")
    public void MissingOrExceeds140ChracterRemittanceInformationUnstructured(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        ArrayList<String> ListremittanceInformationUnstructured = new ArrayList();
        ListremittanceInformationUnstructured.add(Exceeds140Character);
        ListremittanceInformationUnstructured.add("");


        for (int i = 0; i < ListremittanceInformationUnstructured.size(); i++) {
            instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
            debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
            creditorAgent = new CreditorAgent(bic);
            creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
            creditorAccount = new CreditorAccount(Creditoriban);

            String responseInvalidServiceLevel = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                    debtorType, debtorAddress, creditorName,
                    creditorAccount, creditorAgent, creditorId,
                    creditorIdType, creditorType, creditorAddress,
                    ListremittanceInformationUnstructured.get(i),
                    requestExecutionDate, endToEndIdentification,
                    instructionId, paymentServiceLevel,// paymentReasonCode,
                    purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                    ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
            Taf.utils().log().info("Response of RemittanceInformationUnstructured for param: " + ListremittanceInformationUnstructured.get(i) + responseInvalidServiceLevel.toString());
            List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
            List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

            fetchValuefromJsonList(value, valueTomatch, text);
        }
    }

    @Step("Invalid or missing Remittance information structured check for Instant Payment")
    public void MissingOrExceeds140ChracterRemittanceInformationStructured(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        String missingremittanceInformationStructured = "";
        String exceedsremittanceInformationStructured = Exceeds35Character;
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);
        RemittanceInformationStructured RemittanceInformationStructuredExceeds = new RemittanceInformationStructured(exceedsremittanceInformationStructured);

        String responseExceedsremittanceInformationStructured = createPaymentForFieldValidationRemmitanceInformationStructured(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                RemittanceInformationStructuredExceeds,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of RemittanceInformationUnstructured for param: " + responseExceedsremittanceInformationStructured.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);

        RemittanceInformationStructured RemittanceInformationStructuredmissing = new RemittanceInformationStructured(missingremittanceInformationStructured);
        //  RemittanceInformationStructured remittanceStructuredExceedsChar = new RemittanceInformationStructured(exceedsremittanceInformationStructured);
        String responseMissingremittanceInformationStructured = createPaymentForFieldValidationRemmitanceInformationStructured(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                RemittanceInformationStructuredmissing,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);

        Taf.utils().log().info("Response of RemittanceInformationUnstructured for param: " + responseMissingremittanceInformationStructured.toString());
        List<String> value1 = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text1 = Taf.api().rest().extractValuesFromArrayToList("errors.text");
        fetchValuefromJsonList(value1, "RR07", text1);
    }

    @Step("Invalid or Exceeds 35 character Id check for Instant Payment")
    public void debtorIdExceeds35Character(String valueTomatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        // String Exceeds35Character =  RandomValueGenerator.generateRandomValueWithinRange(36,50);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseExceeds35charDebtorId = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, Exceeds35Character, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of exceeds 35 character Debtor Id:" + responseExceeds35charDebtorId.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Call api, post /payments/sepa-credit-transfers")
    private String createInstantSepaPaymentAndReturnUrlWithBlankIBANUsingUI() throws IOException {

        debtorAccount = new DebtorAccount(null);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);
        Taf.utils().log().info(
                "Creating SEPA payment from Blank IBAN '");
        return Taf.api().rest()
               .addHeader("Tpp-Redirect-Preferred", "true")
                .addHeader("Tpp-Redirect-URI", "https://www.microsoft.com")
                .addHeader("Tpp-Nok-Redirect-URI", "https://www.google.com")
                .addRequestBody(new CreatePaymentFullPayLoad(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel, //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType))
                .httpPost("/payments/instant-sepa-credit-transfers")
                .hasStatusCode(HttpStatus.SC_CREATED)
                .extractStringValue("_links.scaRedirect.href");
    }


    @Step("Invalid or missing creditor street check for Instant Payment")
    public void InvalidMisingExceedsCreditorStreet(String valueTomatch) throws IOException {
        debtorAccount = new DebtorAccount(debitoriban);
        String ExceedsStreet70Char = Exceeds70Character;
        String missingStreet = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        InstructedAmountfullPayload instructedAmountfullPayloadMissing;
        instructedAmountfullPayloadMissing = new InstructedAmountfullPayload("", amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, ExceedsStreet70Char);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidExceeds = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel, //paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response:" + responseInvalidExceeds.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);

        creditorAddress = new CreditorAddress(CreditorCountry, missingStreet);
        String responseMissing = createPaymentForFieldValidation(instructedAmountfullPayloadMissing, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel, //paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);

        Taf.utils().log().info("Response of Missing creditor Street:" + responseMissing.toString());

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid or missing creditor street check for Instant Payment")
    public void InvalidMisingExceedsCreditorCountry(String valueTomatch) throws IOException {
        debtorAccount = new DebtorAccount(debitoriban);
        String ExceedsCountry70Char = Exceeds70Character;
        String missingCountry = "";
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        InstructedAmountfullPayload instructedAmountfullPayloadMissing;
        instructedAmountfullPayloadMissing = new InstructedAmountfullPayload("", amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(ExceedsCountry70Char, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidExceeds = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel, //paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response:" + responseInvalidExceeds.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);

        creditorAddress = new CreditorAddress(missingCountry, Creditorstreet);
        String responseMissing = createPaymentForFieldValidation(instructedAmountfullPayloadMissing, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel, //paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);

        Taf.utils().log().info("Response of Missing creditor Street:" + responseMissing.toString());

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid Debtor IBAN check for Instant Payment")
    public void invalidMissingDebtorIban(String valueTomatch) {
        String invalidDebitorIban = "LT134010051004040891111";
        debtorAccount = new DebtorAccount(invalidDebitorIban);
        // String Exceeds35Character =  RandomValueGenerator.generateRandomValueWithinRange(36,50);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidcharDebtorIban = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of invalid Debtor IBAN:" + responseInvalidcharDebtorIban.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);
        debtorAccount = new DebtorAccount("");
        /*String responseMissingcharDebtorIban = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of missing Debtor IBAN:" + responseMissingcharDebtorIban.toString());


        fetchValuefromJsonList(value, valueTomatch, text);
*/

    }

    @Step("Invalid creditor IBAN check for Instant Payment")
    public void invalidCreditorIban(String valueTomatch) {
        String invalidCreditorIban = "Test Account";
        debtorAccount = new DebtorAccount(debitoriban);
        // String Exceeds35Character =  RandomValueGenerator.generateRandomValueWithinRange(36,50);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(invalidCreditorIban);

        String responseInvalidcharCreditorIban = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of invalid creditor IBAN:" + responseInvalidcharCreditorIban.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid debtor IBAN check for Instant Payment")
    public void DebtorIBANForCorporateIBAN(String valueTomatch) {
        //   String  invalidDebtorIban = "LT114010051002041078";
        debtorAccount = new DebtorAccount(corporateIBNLT);
        // String Exceeds35Character =  RandomValueGenerator.generateRandomValueWithinRange(36,50);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidCorporateIban = createPaymentForFieldValidation(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of invalid Debtor IBAN:" + responseInvalidCorporateIban.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Invalid EE IBAN check for Instant Payment")
    public void DebtorIBANForEEIBAN(String valueTomatch) {

        debtorAccount = new DebtorAccount(EEIBAN);

        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidCorporateIban = createPaymentForOtherThenLT(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of invalid EE IBAN:" + responseInvalidCorporateIban.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }


    @Step("Invalid LV IBAN check for Instant Payment")
    public void DebtorIBANForLVIBAN(String valueTomatch) {

        debtorAccount = new DebtorAccount(LVIBAN);

        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        String responseInvalidLVIban = createPaymentForOtherThenLT(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                debtorType, debtorAddress, creditorName,
                creditorAccount, creditorAgent, creditorId,
                creditorIdType, creditorType, creditorAddress,
                remittanceInformationUnstructured,
                requestExecutionDate, endToEndIdentification,
                instructionId, paymentServiceLevel,// paymentReasonCode,
                purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        Taf.utils().log().info("Response of invalid LV IBAN:" + responseInvalidLVIban.toString());
        List<String> value = Taf.api().rest().extractValuesFromArrayToList("errors.code");
        List<String> text = Taf.api().rest().extractValuesFromArrayToList("errors.text");

        fetchValuefromJsonList(value, valueTomatch, text);


    }

    @Step("Call API Delete Instant Payment")
    private static String deletePayment(String paymentId) {
        Taf.utils().log().info(" DELETE Payment for payment with id '" + paymentId + "'");
        return Taf.api().rest()
                .httpDelete("/payments/instant-sepa-credit-transfers/%s", paymentId)
                .hasStatusCode(HttpStatus.SC_OK)
                .extractStringValue("transactionStatus");

    }

    @Step("Delete Instant Payment")
    public void createAndDeletePayment(String valueToMatch) {
        debtorAccount = new DebtorAccount(debitoriban);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        Taf.utils().log().info("Creating and signing instant SEPA payment");
        String paymentId =
                createInstantSepaPayment(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel,// paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        InstantPayments.getInstantPaymentStatus(paymentId);
        InstantPayments.deletePayment(paymentId);
        String status = InstantPayments.getInstantPaymentStatus(paymentId);
        if (status == valueToMatch) {
            Taf.utils().log().info("payment is deleted" + status);
        }
    }

    @Step("Call api, post /payments/instant-sepa-credit-transfers")
    public Rest createInstantSepaPaymentwithInstantHeaders(String booleanValue, int statusCode) throws IOException {

        debtorAccount = new DebtorAccount(debitoriban);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);
        Taf.utils().log().info(
                "Creating SEPA payment from account '" + getPropertyFromFile("debitoriban") + "' to '" + getPropertyFromFile("Creditoriban")
                        + "'");
        Rest status = Taf.api().rest()
                .addHeader("Tpp-Redirect-Preferred", "true")
                .addHeader("Tpp-Redirect-URI", "https://www.microsoft.com")
                .addHeader("Tpp-Nok-Redirect-URI", "https://www.google.com")
                .addHeader("tpp-instant-only-preferred", booleanValue)
                .addRequestBody(new CreatePaymentFullPayLoad(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel, //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType))
                .httpPost("/payments/instant-sepa-credit-transfers")
                .hasStatusCode(statusCode);

        if (booleanValue.equals("true")) {
            PaymentDetailsResponse response = status.getResponseAsJavaObject(PaymentDetailsResponse.class);
            if ((response.getTransactionStatus()).equals("ACTC")) {
                Taf.utils().log().info("Sepa instant flag value: Payment is successful : " + booleanValue);
                status.getResponseAsJavaObject(PaymentDetailsResponse.class);
            }
        } else {
            Taf.utils().log().info("Sepa instant flag value: Payment is failed : " + booleanValue);
            status.extractStringValue("errors.code");
            status.extractStringValue("errors.text");
        }

        return status;
    }


    @Step("Create and sign instant SEPA payment")
    public String ValidateInsuffientFundViaUI(Map<String, String> dp) {
        debtorAccount = new DebtorAccount(debitoriban);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, 10000f);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        Taf.utils().log().info("Creating and signing instant SEPA payment");
        String paymentId =
                createInstantSepaPayment(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel,
                        //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        AuthMethodRequestBodyModel paymentBody = new AuthMethodRequestBodyModel(dp);
        String authorisationId = InstantPayments.initiateInstantPaymentSigning(paymentId);
        InstantPayments.selectInstantPaymentSigningMethod(paymentId, authorisationId, paymentBody);
        InstantPayments.checkInstantPaymentSigningStatusBecomesFinalised(paymentId, authorisationId);
        InstantPayments.getInstantPaymentDetails(paymentId);
        InstantPayments.getInstantPaymentStatus(paymentId);
        return paymentId;
    }


    @Step("Call api, post /payments/instant-sepa-credit-transfers")
    private String createInstantSepaPaymentAndReturnUrlForInsuffientFunds() throws IOException {

        debtorAccount = new DebtorAccount(IbanForInsufficientFund);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, AmountForInsufficentFund);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);
        Taf.utils().log().info(
                "Creating instant SEPA payment from account '" + IbanForInsufficientFund + "' to '" + getPropertyFromFile("Creditoriban")
                        + "'");
        return Taf.api().rest()
                .addHeader("Tpp-Redirect-Preferred", "true")
                .addHeader("Tpp-Redirect-URI", "https://www.microsoft.com")
                .addHeader("Tpp-Nok-Redirect-URI", "https://www.google.com")
                .addRequestBody(new CreatePaymentFullPayLoad(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel, //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType))
                .httpPost("/payments/instant-sepa-credit-transfers")
                .hasStatusCode(HttpStatus.SC_CREATED)
                .extractStringValue("_links.scaRedirect.href");
    }

    @Step("Create instatnt SEPA payment via API and sign from browser")
    public InstantPaymentInsufficientPage openCreatedInstantPaymentFromBrowserForInsufficientFunds() throws IOException {
        open(createInstantSepaPaymentAndReturnUrlForInsuffientFunds());
        Authorization.loginToSignInstantPaymentForInsufficientPage();

        return new InstantPaymentInsufficientPage();
    }


    @Step("Create and sign instant SEPA payment for Blocked IBAN")
    public String createAndSignInstantSepaPaymentForBlockedIBANViaAPI(Map<String, String> dp) {
        debtorAccount = new DebtorAccount(debitoriban);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(CreditorBlockedIBAN);

        Taf.utils().log().info("Creating and signing instant SEPA payment");
        String paymentId =
                createInstantSepaPayment(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel,
                        //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        AuthMethodRequestBodyModel paymentBody = new AuthMethodRequestBodyModel(dp);
        String authorisationId = InstantPayments.initiateInstantPaymentSigning(paymentId);
        InstantPayments.selectInstantPaymentSigningMethod(paymentId, authorisationId, paymentBody);
        InstantPayments.checkInstantPaymentSigningStatusBecomesFinalised(paymentId, authorisationId);
        InstantPayments.getInstantPaymentDetails(paymentId);
        String paymentStatus = InstantPayments.getInstantPaymentStatus(paymentId);
        if (paymentStatus.equals("RJCT")) {
            Taf.utils().log().info("Payment is Rejected, AS IBAN is Blocked");

        } else {
            Taf.utils().log().error("Failed- IBAN is not blocked and we are able to process the payment");
        }
        return paymentId;
    }

    @Step("Create and sign instant SEPA payment-Blocked IBAN")
    public String createAndSignInstantSepaPaymentForInsufficientFunds(Map<String, String> dp) {
        debtorAccount = new DebtorAccount(IbanForInsufficientFund);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, AmountForInsufficentFund);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        Taf.utils().log().info("Creating and signing instant SEPA payment");
        String paymentId =
                createInstantSepaPayment(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel,
                        //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        AuthMethodRequestBodyModel paymentBody = new AuthMethodRequestBodyModel(dp);
        String authorisationId = InstantPayments.initiateInstantPaymentSigning(paymentId);
        InstantPayments.selectInstantPaymentSigningMethod(paymentId, authorisationId, paymentBody);
        InstantPayments.checkInstantPaymentSigningStatusBecomesFinalised(paymentId, authorisationId);
        InstantPayments.getInstantPaymentDetails(paymentId);
        String paymentStatus = InstantPayments.getInstantPaymentStatus(paymentId);
        if (paymentStatus.equals("RJCT")) {
            Taf.utils().log().info("Payment is Rejected");

        } else {
            Taf.utils().log().error("Failed- Sufficent funds");
        }
        return paymentId;
    }


    @Step("Call API Delete Instant Payment After signing")
    private static String deleteSignedPayment(String paymentId, String authorisationId) {
        Taf.utils().log().info(" DELETE Signed Payment for payment with id '" + paymentId + "'");
        return  Taf.api().rest()
                .httpDelete("/payments/instant-sepa-credit-transfers/%s/authorisations/%s", paymentId, authorisationId)
                .hasStatusCode(HttpStatus.SC_OK)
                .extractStringValue("canceled");


    }




    @Step("Check payment status, recall api")
    private static void checkInstantPaymentSigningStatusBecomesCancelled(String paymentId,
                                                                         String authorisationId) {
        Taf.utils().log()
                .info("Checking payment signing status becomes '" + PAYMENT_SIGNING_STATUS_CANCELED + "'");

        Integer timeoutMilliSec = Taf.utils().config().getIntPropertyValue("selenide.timeout");
        Integer timeoutSec = timeoutMilliSec / 1000;

        int pollingInterval = 5;
        try {
            await().atMost(timeoutSec, TimeUnit.SECONDS).pollInterval(pollingInterval, TimeUnit.SECONDS)
                    .until(() ->
                            getInstantPaymentSigningStatus(paymentId, authorisationId).equals(PAYMENT_SIGNING_STATUS_CANCELED)
                    );
        } catch (ConditionTimeoutException e) {
            Taf.utils().log().error(
                    "Payment was not deleted withing the given time limit of '" + timeoutSec
                            + "' seconds. Expected payment signing status: '" + PAYMENT_SIGNING_STATUS_CANCELED
                            + "'");
        }
    }

    @Step("Create and sign instant SEPA payment")
    public String createAndDeleteSignedPayment(Map<String, String> dp) {
        debtorAccount = new DebtorAccount(debitoriban);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        Taf.utils().log().info("Creating and signing instant SEPA payment");
        String paymentId =
                createInstantSepaPayment(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel,
                        //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType);
        AuthMethodRequestBodyModel paymentBody = new AuthMethodRequestBodyModel(dp);
        String authorisationId = InstantPayments.initiateInstantPaymentSigning(paymentId);
        InstantPayments.deleteSignedPayment(paymentId,authorisationId);
        InstantPayments.checkInstantPaymentSigningStatusBecomesCancelled(paymentId,authorisationId);
        InstantPayments.getInstantPaymentSigningStatus(paymentId,authorisationId);
        return paymentId;
    }


    @Step("Create instatnt SEPA payment via API and sign from browser")
    public void openDeleteInstantPaymentFromBrowser(String valueToMatch) throws IOException {
        debtorAccount = new DebtorAccount(debitoriban);
        instructedAmountfullPayload = new InstructedAmountfullPayload(currency, amount);
        debtorAddress = new DebtorAddress(Debitorcountry, Debitorstreet);
        creditorAgent = new CreditorAgent(bic);
        creditorAddress = new CreditorAddress(CreditorCountry, Creditorstreet);
        creditorAccount = new CreditorAccount(Creditoriban);

        Taf.utils().log().info(
                "Creating instant SEPA payment from account '" + getPropertyFromFile("debitoriban") + "' to '" + getPropertyFromFile("Creditoriban")
                        + "'");
        String hrefLink= Taf.api().rest()
                .addHeader("Tpp-Redirect-Preferred", "true")
                .addHeader("Tpp-Redirect-URI", "https://www.microsoft.com")
                .addHeader("Tpp-Nok-Redirect-URI", "https://www.google.com")
                .addRequestBody(new CreatePaymentFullPayLoad(instructedAmountfullPayload, debtorName, debtorAccount, debtorId, debtorIdType,
                        debtorType, debtorAddress, creditorName,
                        creditorAccount, creditorAgent, creditorId,
                        creditorIdType, creditorType, creditorAddress,
                        remittanceInformationUnstructured,
                        requestExecutionDate, endToEndIdentification,
                        instructionId, paymentServiceLevel, //paymentReasonCode,
                        purposeCode, chargeBearer, ultimateDebtorName, ultimateDebtorId, ultimateDebtorType,
                        ultimateDebtorIdType, ultimateCreditorName, ultimateCreditorId, ultimateCreditorType, ultimateCreditorIdType))
                .httpPost("/payments/instant-sepa-credit-transfers")
                .hasStatusCode(HttpStatus.SC_CREATED)
                .extractStringValue("_links.scaRedirect.href");
      String PaymentId=Taf.api().rest().extractStringValue("paymentId");

        open(hrefLink);
        Authorization.loginToSignInstantPayment();
        SelenideElement buttonSign = $x("//button[@class='button layout-link size-default']/span"),
                tableCreditorInfo = $(".layout-wide-content.layout-wide-column2"),
                tableDebtorInfo = $(".layout-wide-content.layout-wide-column1");

        tableCreditorInfo.shouldHave(Condition.text(BasePsd2Test.getPropertyFromFile("Creditoriban")));
        tableDebtorInfo.shouldHave(Condition.text(BasePsd2Test.getPropertyFromFile("debitoriban")));
        buttonSign.shouldBe(Condition.visible.because("Cancel Link should be visible")).click();
      String Status=  InstantPayments.getInstantPaymentStatus(PaymentId);
      if(Status.equals(valueToMatch)){
          Taf.utils().log().info("Payment is :"+Status);
      }
    else {
          Taf.utils().log().error("Payment is :"+Status);
      }
    }

}