package com.luminor.api.pojo.auth;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class Callbacks {

  private String type;
  private ArrayList<Output> output;

  @JsonCreator
  public Callbacks(
      @JsonProperty("type") String type) {
    this.type = type;
    output = new ArrayList<>();
  }
}
