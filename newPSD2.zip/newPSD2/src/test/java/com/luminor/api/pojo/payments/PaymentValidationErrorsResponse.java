package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

import java.util.List;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentValidationErrorsResponse {

  private List<String> category;
  private List<String> code;
  private List<String> text;
  private List<String> fieldName;

  @JsonCreator
  public PaymentValidationErrorsResponse(
      @JsonProperty("category") List<String> category,
      @JsonProperty("code") List<String> code,
  @JsonProperty("text") List<String> text,
              @JsonProperty("fieldName") List<String> fieldName) {
    this.category = category;
    this.code = code;
    this.text = text;
    this.fieldName = fieldName;
  }
}
