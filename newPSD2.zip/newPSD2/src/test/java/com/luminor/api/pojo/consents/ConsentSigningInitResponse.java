package com.luminor.api.pojo.consents;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class ConsentSigningInitResponse {

  private String scaStatus;
  private String authorisationId;

  @JsonCreator
  public ConsentSigningInitResponse(@JsonProperty("scaStatus") String scaStatus,
      @JsonProperty("authorisationId") String authorisationId) {
    this.scaStatus = scaStatus;
    this.authorisationId = authorisationId;
  }
}
