package com.luminor.api.pojo.accounts;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BalanceAmount {

  private String currency;
  private double amount;

  @JsonCreator
  public BalanceAmount(@JsonProperty("currency") String currency,
      @JsonProperty("amount") double amount) {
    this.currency = currency;
    this.amount = amount;
  }
}
