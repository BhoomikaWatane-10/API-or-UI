
package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Setter;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;

@Setter
@JsonAutoDetect(fieldVisibility = ANY)
public class CreditorAddress {


    public String country;
    public String street;

    @JsonCreator
    public CreditorAddress(String country, String street) {
        super();
        this.country = country;
        this.street = street;
    }

}
