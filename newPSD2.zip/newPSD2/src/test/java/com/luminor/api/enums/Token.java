package com.luminor.api.enums;

import com.luminor.taf.Taf;

public enum Token {
  TOKEN_EXPIRED(
      "Bearer eyJ0eXAiOiJKV1QiLCJ6aXAiOiJOT05FIiwia2lkIjoiYzcxYjZlM2U4NjkwM2FmMzZkY2NmMWEzODc"
          + "5ODYyZDA3YTE0NjI1N2ZhMzNhZmZiYzQ3OTQ2NzczYjQzYWZhOCIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJlZ"
          + "TQyMzY3NTAiLCJjdHMiOiJPQVVUSDJfR1JBTlRfU0VUIiwiYXV0aF9sZXZlbCI6MCwiYXVkaXRUcmFja2luZ0lk"
          + "IjoiNTg4MzE2YzMtZmM2OS00YjI4LThmYTctYmM2OWUyODI3OTA5LTIwNTI4MTgyIiwiaXNzIjoiaHR0cHM6Ly9"
          + "wc2QyLnN0Zy5sdW1zb2x1dGlvbnMubmV0L3YxL29wZW5hbS9vYXV0aDIvcmVhbG1zL3Jvb3QvcmVhbG1zL3BzZD"
          + "IiLCJ0b2tlbk5hbWUiOiJhY2Nlc3NfdG9rZW4iLCJ0b2tlbl90eXBlIjoiQmVhcmVyIiwiYXV0aEdyYW50SWQiO"
          + "iJJOFBmWDhoTmZFWF8yeVhJbkZYNlFFeDhNOW8uOXNQM0p2TWdnZHgtblF2SExfRHVqSFR2YnRrIiwiYXVkIjoi"
          + "YjM1MTJlMjgtZGE3OC00YWEyLTkwMmItOGNiMjExOGYyYTZhIiwibmJmIjoxNjA1ODc3MTAwLCJncmFudF90eXB"
          + "lIjoiYXV0aG9yaXphdGlvbl9jb2RlIiwic2NvcGUiOlsidHBwIiwib3BlbmlkIiwiYXNwc3AiLCJwcm9maWxlIl"
          + "0sImF1dGhfdGltZSI6MTYwNTg3NzA5OCwicmVhbG0iOiIvcHNkMiIsImV4cCI6MTYwNTg4MDcwMCwiaWF0IjoxN"
          + "jA1ODc3MTAwLCJleHBpcmVzX2luIjozNjAwLCJqdGkiOiJJOFBmWDhoTmZFWF8yeVhJbkZYNlFFeDhNOW8uY3F1"
          + "dHFVeVF3RVY3QjRUMy1Pbktwc0l6ZVcwIiwiYmFua19jb3VudHJ5IjoiZWUiLCJjY2NfdXNlcm5hbWUiOiI0MjM"
          + "2NzUwIiwiY2NjX2N1c3RvbWVyX2lkIjoiYWIwM2U0YzEtOGM1ZC00N2Y2LWI5ZjQtMzFhZjIxODc0MTExIiwiYX"
          + "V0aF9tZXRob2QiOiJzbWFydElkIiwiYXV0aF9tZXRob2RfcmVmZXJlbmNlIjoiUE5PRUUtMTAxMDEwMTAwMDUtW"
          + "jFCMi1RIn0.pjTM02vy0m4KEbFW4M31WJTumh6-Ris-50aNOl2CtYaU0EcSgpuAg8WWTkw8MFB9j5nR3-q4ldXz"
          + "Ku09aSFK-HR2-0gtlE0-gXSICvTG6zPvmhM2ASDV9yt9SqHf1u8G_5rPv8R7-e9wVkVl58pBY25-40P2f2Tkm8c"
          + "IjkGppFz2HmNpmFoJ94I3yvuWzu6ylXNxCK3_Da_MmPAYCerokNFBMNYaGRs7oJJykBLNvisuk96u2EbFVa86Dm"
          + "ZfXqVQFuo5jnHQa6V5kvXncWYArG-ePsliajuFwwGrZNO_D6e0p_-zCCJ7SvyqMedcti7hB92ukUtNe41Mk08Gm"
          + "yfbsA"),
  TOKEN_INVALID(Taf.utils().numbers().getRandomNumberWithNDigits(20));

  private String value;

  Token(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
