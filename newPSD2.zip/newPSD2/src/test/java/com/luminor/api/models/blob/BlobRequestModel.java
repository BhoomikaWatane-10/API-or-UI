package com.luminor.api.models.blob;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.text.SimpleDateFormat;
import java.util.Date;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class BlobRequestModel {

  private String id;
  private String date;

  @JsonCreator
  public BlobRequestModel(String id) {
    this.id = id;

    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Date date = new Date();
    this.date = formatter.format(date);
  }
}
