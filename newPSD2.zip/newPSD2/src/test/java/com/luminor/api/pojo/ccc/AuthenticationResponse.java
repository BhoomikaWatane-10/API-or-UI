package com.luminor.api.pojo.ccc;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AuthenticationResponse {

  private String accessToken;
  private String idToken;

  @JsonCreator
  public AuthenticationResponse(
      @JsonProperty("id_token") String idToken,
      @JsonProperty("access_token") String accessToken) {
    this.idToken = idToken;
    this.accessToken = accessToken;
  }
}
