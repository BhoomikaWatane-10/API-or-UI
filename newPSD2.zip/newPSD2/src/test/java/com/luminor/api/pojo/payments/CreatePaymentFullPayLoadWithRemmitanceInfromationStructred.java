
package com.luminor.api.pojo.payments;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Setter;

@Setter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class CreatePaymentFullPayLoadWithRemmitanceInfromationStructred {


    private InstructedAmountfullPayload instructedAmount;

    private String debtorName;

    private DebtorAccount debtorAccount;

    private String debtorId;

    private String debtorIdType;

    private String debtorType;

    private DebtorAddress debtorAddress;

    private String creditorName;

    private CreditorAccount creditorAccount;

    private CreditorAgent creditorAgent;

    private String creditorId;

    private String creditorIdType;

    private String creditorType;

    private CreditorAddress creditorAddress;

   // private String remittanceInformationUnstructured;

    private RemittanceInformationStructured remittanceInformationStructured;

    private String requestedExecutionDate;

    private String endToEndIdentification;

    private String instructionId;

    private String paymentServiceLevel;

    private String paymentReasonCode;

    private String purposeCode;

    private String chargeBearer;

    private String ultimateDebtorName;

    private String ultimateDebtorId;

    private String ultimateDebtorType;

    private String ultimateDebtorIdType;

    private String ultimateCreditorName;

    private String ultimateCreditorId;

    private String ultimateCreditorType;

    private String ultimateCreditorIdType;

    @JsonCreator
    public CreatePaymentFullPayLoadWithRemmitanceInfromationStructred(InstructedAmountfullPayload instructedAmount, String debtorName, DebtorAccount debtorAccount, String debtorId, String debtorIdType, String debtorType, DebtorAddress debtorAddress, String creditorName, CreditorAccount creditorAccount, CreditorAgent creditorAgent, String creditorId, String creditorIdType, String creditorType, CreditorAddress creditorAddress, RemittanceInformationStructured remittanceInformationstructured,
                                                                      String requestedExecutionDate, String endToEndIdentification, String instructionId, String paymentServiceLevel, //String paymentReasonCode,
                                                                      String purposeCode, String chargeBearer, String ultimateDebtorName, String ultimateDebtorId, String ultimateDebtorType, String ultimateDebtorIdType, String ultimateCreditorName, String ultimateCreditorId, String ultimateCreditorType, String ultimateCreditorIdType) {
        this.instructedAmount = instructedAmount;
        this.debtorName = debtorName;
        this.debtorAccount = debtorAccount;
        this.debtorId = debtorId;
        this.debtorIdType = debtorIdType;
        this.debtorType = debtorType;
        this.debtorAddress = debtorAddress;
        this.creditorName = creditorName;
        this.creditorAccount = creditorAccount;
        this.creditorAgent = creditorAgent;
        this.creditorId = creditorId;
        this.creditorIdType = creditorIdType;
        this.creditorType = creditorType;
        this.creditorAddress = creditorAddress;
      // this.remittanceInformationUnstructured = remittanceInformationUnstructured;
       this.remittanceInformationStructured=remittanceInformationstructured;
        this.requestedExecutionDate = requestedExecutionDate;
        this.endToEndIdentification = endToEndIdentification;
        this.instructionId = instructionId;
        this.paymentServiceLevel = paymentServiceLevel;
       // this.paymentReasonCode = paymentReasonCode;
        this.purposeCode = purposeCode;
        this.chargeBearer = chargeBearer;
        this.ultimateDebtorName = ultimateDebtorName;
        this.ultimateDebtorId = ultimateDebtorId;
        this.ultimateDebtorType = ultimateDebtorType;
        this.ultimateDebtorIdType = ultimateDebtorIdType;
        this.ultimateCreditorName = ultimateCreditorName;
        this.ultimateCreditorId = ultimateCreditorId;
        this.ultimateCreditorType = ultimateCreditorType;
        this.ultimateCreditorIdType = ultimateCreditorIdType;
    }

}
