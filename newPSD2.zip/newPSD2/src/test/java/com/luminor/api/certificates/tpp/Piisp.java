package com.luminor.api.certificates.tpp;

import com.luminor.taf.controllers.FrameworkException;
import com.luminor.taf.test.api.auth.utils.BouncycastleUtils;
import com.luminor.taf.test.api.auth.utils.KeystoreBuilder;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;

public class Piisp {

  private static RSAPrivateKey privateKey;
  private static X509Certificate certificate;

  public static RSAPrivateKey getPrivateKey() {
    if (privateKey == null) {
      try {
        privateKey = (RSAPrivateKey) BouncycastleUtils.getPrivateKeyFromPEM(privateKeyValue);
      } catch (Exception e) {
        throw new FrameworkException(e.getMessage());
      }
    }
    return privateKey;
  }

  public static X509Certificate getCertificate() throws Exception {
    if (certificate == null) {
      certificate = BouncycastleUtils.getX509CertificateFromPem(certificateValue);
    }
    return certificate;
  }

  public static KeyStore getKeystore() throws Exception {
    KeystoreBuilder builder = new KeystoreBuilder()
        .setPrivateKey(getPrivateKey(), getCertificate(), "1")
        .setCert("tppca", TppCA.getCaCertificate())
        .setKeystorePassword("changeit");
    KeyStore keyStore = builder.build();
    return keyStore;
  }

  private static final String privateKeyValue = "-----BEGIN PRIVATE KEY-----\n"
      + "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQClaY1O19i1HzVM\n"
      + "W/wdbhXPSFaxbi9CAYBOz3+hKQfcYN0ptNsZ1HNDMTJ/uYXTlGcHx2+kdtIoOnZQ\n"
      + "7xQNWy+W4VO8kPLnKj7D9RlpRt1f3vf8g1JAHV3qHXTApGA23XCZxQvl6QUdBE/Z\n"
      + "toyWhmv3BJCQuumSUThJqrVWmEchkuAwgT2F/s2PgvYlOpKZYRrzyPYt8v8mQDL7\n"
      + "COKQHWtWONMLwg6rJh2a+vPS8BqF0p4v+nEFLIvecIPqu13mpOd9AwTjqlRTJAWm\n"
      + "zWY+nwAk0qvosOBp8dY/4a3wi16pUOYqhT0MWWNJYP4gFlGUzuCV5dJjHf2JbcWd\n"
      + "gQczb6aRAgMBAAECggEBAJEpopMwpcO90Z5jk0uYkpdIWpx3oA2DF8ESJGWghn+G\n"
      + "mlDBoQ53/XdYM4MXozRdJlYTVgy1IhWfyLmaNrTJ82er8zqm0iTAVDjQXi6fvCMo\n"
      + "n+UAsiwGGacdlpqBJta/WtP3s0tfRdeDMzhTFen7qcAsR1pcTiLUGFu97kpCdRom\n"
      + "TDk+6IpCG3SqqHKQHP5G2QB9YDf7yTwq0zb0jM7zyqXji0808onCXAxhAIRCwAgT\n"
      + "xlnl73TVD753f8HtjkLFE6hewUu/1hEvmFoLr3xABCE3q7rt8RPDJhIZYhSgjK1U\n"
      + "5k6VbPi0sySRIX2p7b85kfOmna2MNMsI0So/cYmvWekCgYEA06y7DSfk6iEYS1x5\n"
      + "RIktg4p/EW+Fw00FaXUJMD1GUrU4HYmaGSrGkFUpYCE/i83gUkpLKStw7hwEGOgn\n"
      + "DI/Kc/E1EWSwuxSe1U6m5lsOG8F3rII0ndgmOEaAxizG8YixFmItxhxqvee8PcOv\n"
      + "5qAIJiy2iHqVaYeUSuxYCC4SOG8CgYEAyAzTvS+cbmZZzSr6sLu6vRjfokq741Wa\n"
      + "CxR/P4FnpIcxylGBKPPyPionqDL4bGotieAqAAY5QlGAsjieYFjOTEfzQv1/JBrS\n"
      + "85IcwPbS2MGhZFJZoWonKLD2M/ejMpHF2i7A52yynon111M06ldaaPxxKvawQO96\n"
      + "J2F0ylClkP8CgYEAzYTFLHXSldxCKVGE0J1cGn6K91PPjRsoKQcgP70OnVkkPdGP\n"
      + "U+YrWpHFFXfSqhvfNCa8KSHriNScyc4Fs/WcfMvyWYvo6AuSV8sA02IPJbXHSzA0\n"
      + "hBkMqtERUNjC5FpyjigPB24p2W65X0Kzc/lnUCFTrNlQXmDsA37Lzk1lFXMCgYA3\n"
      + "uErpsO8zWNK+cLAutbtHnDv96i73HQqw916SA6soind10MnW7EuWwQsWsEu9dr2E\n"
      + "X6mTJCiirizYdyi10UZ0vL2m9RCKr+X97b6QiK8lrJkVZlKMwRJzJQcOZnVQSoX/\n"
      + "RXJ5gy8lNWwCM6zTcM0/3MBwpRFmpM0zVtO+3kOfZQKBgCrPaMfcICldkCcgeQ/o\n"
      + "+XDmHPlZg2C0v2JMkRySD6BB9fBUFFkQiu+ChgjzFaLOtyAAPTdjhHmonPTXHs7T\n"
      + "DemFFMzz4bmlD39wnFIUVnlX7dLkzcJ04GPZaax26UQv8yXrAc5+RzyCN00pO2/D\n"
      + "/1d3JGzX8l15HrVVrILDIdBn\n"
      + "-----END PRIVATE KEY-----";

  private static final String certificateValue = "-----BEGIN CERTIFICATE-----\n"
      + "MIIEzDCCArSgAwIBAgIEAQIDBDANBgkqhkiG9w0BAQsFADA5MQswCQYDVQQGEwJF\n"
      + "RTETMBEGA1UECgwKU3VwZXIgaW5jLjEVMBMGA1UEAwwMUFNEMiBUZXN0IENBMB4X\n"
      + "DTE5MTIwMjAzMTMwMFoXDTI1MTIwMjAzMTMwMFowYDEZMBcGA1UEYRMQUFNERVMt\n"
      + "QkRFLTNERkQwNDELMAkGA1UEBhMCRUUxFjAUBgNVBAMTDUF1dG9UZXN0UElpU1Ax\n"
      + "HjAcBgNVBAoTFVRlc3QgUGF5bWVudCBQcm92aWRlcjCCASIwDQYJKoZIhvcNAQEB\n"
      + "BQADggEPADCCAQoCggEBAKVpjU7X2LUfNUxb/B1uFc9IVrFuL0IBgE7Pf6EpB9xg\n"
      + "3Sm02xnUc0MxMn+5hdOUZwfHb6R20ig6dlDvFA1bL5bhU7yQ8ucqPsP1GWlG3V/e\n"
      + "9/yDUkAdXeoddMCkYDbdcJnFC+XpBR0ET9m2jJaGa/cEkJC66ZJROEmqtVaYRyGS\n"
      + "4DCBPYX+zY+C9iU6kplhGvPI9i3y/yZAMvsI4pAda1Y40wvCDqsmHZr689LwGoXS\n"
      + "ni/6cQUsi95wg+q7Xeak530DBOOqVFMkBabNZj6fACTSq+iw4Gnx1j/hrfCLXqlQ\n"
      + "5iqFPQxZY0lg/iAWUZTO4JXl0mMd/YltxZ2BBzNvppECAwEAAaOBtDCBsTALBgNV\n"
      + "HQ8EBAMCAcYwHQYDVR0lBBYwFAYIKwYBBQUHAwEGCCsGAQUFBwMCMIGCBggrBgEF\n"
      + "BQcBAwR2MHQwCAYGBACORgEBMAsGBgQAjkYBAwIBFDAIBgYEAI5GAQQwEwYGBACO\n"
      + "RgEGMAkGBwQAjkYBBgMwPAYGBACBmCcCMDIwEzARBgcEAIGYJwEEDAZQU1BfSUMM\n"
      + "E0NvbXBldGVudCBBdXRob3JpdHkMBkVFLVBBWTANBgkqhkiG9w0BAQsFAAOCAgEA\n"
      + "Qcu84nUD3JdtZw/V7mtUzL677o4QbWqAC4ZwPlCvirZ7BZggL54vOtlnwrws60UT\n"
      + "ddyugJIayR2o/UfjAMLyoKE6UXMGq5BTt6ILjtE/yON5Xxab/LE3NxTp7lPUkdDk\n"
      + "h4382QmvasQm18wyrjUHdrLN7vXpsvhgNUoxdrAgiGjolOrGAgE/dtsN6xObG30x\n"
      + "0Vx0VUtbsmD7F4nn5OUEnM0roRPxiZe5/93swzvmtg82ZEnyZhq+yAIrMjmByGFg\n"
      + "yYQyvBrwoL+IpvCk5PGoI6OCZVEKA1xt7AqFjTwZfTuRSI5EyJMRHX4zKyEnXXrg\n"
      + "ZNiRAJuV058FtNHcBIwlUZ00bkz9qwfnTeWhL0hkYCTyjHHXIN3pbwn16fsCaWni\n"
      + "8PGDdXerboXKzx8C4eYTrZuuBgN1m+0KWbcdLgLwx/w44BLtR6XA7Rm3/+m79Tok\n"
      + "JG6El3JStaxQjkdKI1HKtLvar9+tP3AzqBWkDr+dTnqhaLsuLvHUmFSGbe9MZSal\n"
      + "4uBY6hRwb6h2jQJk2L24fNL/fMQfDO0xZEjT2nhcAu6BraABrny3xUlAlVDKalgW\n"
      + "HRG/eC8G0o3Jy+YZcmfYZZd7ik5u70im4Ohe67pkAdlHA3sHarSx7k7Hqmy/xpEt\n"
      + "geeWsACM6N78Jsn3mn/gLaEqEBrf9Vtd3L/1KO6ru+8=\n"
      + "-----END CERTIFICATE-----";
}
