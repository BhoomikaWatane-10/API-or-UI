package com.luminor.api.certificates;

import com.luminor.api.certificates.tpp.TppCA;
import com.luminor.taf.controllers.FrameworkException;
import com.luminor.taf.test.api.auth.utils.BouncycastleUtils;
import com.luminor.taf.test.api.auth.utils.KeystoreBuilder;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;

public class Testapp {

  private static RSAPrivateKey privateKey;
  private static X509Certificate certificate;

  public static RSAPrivateKey getPrivateKey() {
    if (privateKey == null) {
      try {
        privateKey = (RSAPrivateKey) BouncycastleUtils.getPrivateKeyFromPEM(privateKeyValue);
      } catch (Exception e) {
        throw new FrameworkException(e.getMessage());
      }
    }
    return privateKey;
  }

  public static X509Certificate getCertificate() throws Exception {
    if (certificate == null) {
      certificate = BouncycastleUtils.getX509CertificateFromPem(certificateValue);
    }
    return certificate;
  }

  public static KeyStore getKeystore() throws Exception {
    KeystoreBuilder builder = new KeystoreBuilder()
        .setPrivateKey(getPrivateKey(), getCertificate(), "1")
        .setCert("tppca", TppCA.getCaCertificate())
        .setKeystorePassword("changeit");
    KeyStore keyStore = builder.build();
    return keyStore;
  }

  private static final String privateKeyValue = "-----BEGIN PRIVATE KEY-----\n"
      + "MIIJQwIBADANBgkqhkiG9w0BAQEFAASCCS0wggkpAgEAAoICAQDHlWsYoQAb+z1l\n"
      + "+QEpOIpIroQ3FIAia0x6b1DtcuaJUUnRZ8rgMjk2XK/WFeofU8ftBzY43fszpKCz\n"
      + "B/C+pwUV30Ke5OZ10Uoc6vuTNYuMhipSZViMgCHslW2zH4kBlLTH0MA5GYKWqQlo\n"
      + "+nbLOnkh+SUNM16E12MbvEdy67tjLvBeZHVEXiXz6Lj4rOTXdPi8rdeSEV24e3hy\n"
      + "ZbPdUBuA9WEKHt8ds5qcVUjc9GvZER6BJ5LZNtO4geOxys7RxF6j6tFDIlXFGy74\n"
      + "JXBZWzd77B+YZWHBMv4IqxCQ7aDo33U73w5wT1JutCMCDX622eEuaal/3VWqgCCZ\n"
      + "27q++w07dw3ZGFR+nuuq8euiGzu8FnjhkaXnL43j4TN/MFzrsgJJjeEFlAtlTwfa\n"
      + "+VvzBUcg+fPYGY1fAdBviIYfpgBFS+JOi3C+RlQOxohVL7UKl3qx3lxXrQLOPc+3\n"
      + "oLjsg+9Pt3hOxvFGXamLqipvKgzh5ERh3kdiBI9VP8rfB+JOY8o/66RliTQmyqlZ\n"
      + "iV8Cdq6H0mvNAvznVC2hvOZeZVkBtfki33doGrzCoOD4jy0xL+t3975GNt10Utv+\n"
      + "cfR3uNE0VQyRgPz1CU1Y99uj4PalwX7bLh+tm+P8EbkVWLsZaqNpeUKPVtgOdyms\n"
      + "fOP6L7nHA/PgbJKCcqzcPKtoDoNjNQIDAQABAoICAQCJsu1Q8MPCinSyBjpm1juS\n"
      + "KdXOqrY9CQqa7nJHYR7tXsgvUg0G4Z/XgdtPOY9uTb+CKZefZIgL+WlmG/RdlZ5M\n"
      + "mNy+A+99GgioKveneSnuqiJI9uNBDKZbND2beAZusMqJkd0NiCwxBi8X3rZXQOCS\n"
      + "L/MASJDN1kzqtdwVzc5bf+cXOPgvU0WcItR7vc2lWW7Dvq0ceh7PSWCwjLqr1rkj\n"
      + "ICjzcpk9RM1HTxAWYgyGlukU8ti+RLWOdw9Be0t2LqWdMkVurCHA/CBL1IjPHcAK\n"
      + "H78sxcXMJgJeuKeVVl3OTV31ENBFbHTTLDV7FRR305spCn2HWo3gNMZJYPBXE57s\n"
      + "Ti7Bjn9n5NIJfyQUOye5nXbNPO5CjxMEfFLFYZTzDb7cpQNIHU5c+JfT5qbAmZlk\n"
      + "6uRLW2OYqBrxvFl1KPVOstoQnKaR8jRycD3y0ad+fWx8Av2jA0ATZITJpVXy+Bk6\n"
      + "xnUG42L7hZVQd/D5v1z1MdNfktE88t7yYJJ1yRnhi+07xhFFCydR1yLX4X2agj/g\n"
      + "bML5Ig+K74OmDVFAL+4hHdkIwTN8WlO5Uy6UlJY9iIR2C7uG9EXhe4uBEyHVykpn\n"
      + "Tu8q/0z/26FnCYUcqVY9y+JVPVSdwdLha7xT8nrJLI1fBN+lt/TsCdVqjtnc8ZZl\n"
      + "bprqI2xGYcSsKVBPvYNkAQKCAQEA/SXQUqMXFEH/1YRUZqO0A8+bTFZWTz7DPOMA\n"
      + "EcnRXxB3wNP7E1kRL70/5owwth0XWFSgfAONBNg7n6FgTGtknmddzTN06hyqMDzQ\n"
      + "xTQ0pyHtV5u2C9IfaP+MJwMnVIzeqmlDFpGuT38ab6oVq4h7PHW+P8yLemFTIb42\n"
      + "OLJAmpb24sOnPLlOzvHKSYbHAakPJxsk3oOHRJp2CZ9MJQLi8jec7FDbfBM/BwQg\n"
      + "XHQ1Zt4cKz0QwxXJu8jKfWo9LbiGIdMEC5ecLkdM08JlvCaE6aha6b3Vjjw1KfKs\n"
      + "v1IIuc/FIIEVEpKJj0YPTr6sWYNXptNvUEzX6gXrqnXl06xDWQKCAQEAydUaXJss\n"
      + "ossazG23Va5hLngdk2wxxkdoTNtETbZQqUN4dbmgVLmbpZr6BIdt4TmghpMiPRGW\n"
      + "fx+NdZpd3TyC9s5xP6XsRvuUNaLTgEbEswwq+9PNSapN4HPfJL3JF2aAc+BoflAz\n"
      + "Rg2xG7GHa4vk2cNOy1DlvDULXCo+2OHoP/eim1/deycobwIeWlsQKDwrx48g9SNs\n"
      + "v5gfGmpS7I12kQ9kGk49jKKEpiNHDyasQbQMK+Jk1KLDw+7OUuphyiTmlUtXkVeV\n"
      + "I04j0CVYsddVu++tkA62aLEuAG10HFD+Wbw0dWORr46w8DcFJoLnlt+FnrXFXbsD\n"
      + "DHwahkV9zaovPQKCAQEAjSJZ5Nicc2Tgd3ARhi/amw1R7dtsvz2kp/t+/GviWPfb\n"
      + "bBxDLORJWq5ORAEA32eUrmBwIPPx2TOc+kCEadauAEps14zKsANPNxmQ44FZoZye\n"
      + "sGtVsX1ymZ1vzAhMEy1+rs+E4b5Symt4l6zh7AJpgqm6aeNmF9LPAE8F99IZhpaI\n"
      + "CqE+SfKeZ24Sc6+6n8hbdFgD1DLMZYkgKfkwAKp9UMGEsZPa6m/ogcbhK+p2I2XN\n"
      + "mqWvBLTPBezKR+XFOgpYbd8xsCzUnFCQGreU9LMdAxAjr5Fw0J3snfh4KypXRxD5\n"
      + "PEf7MaGVI9XRjvtrJ3S8l3vl4YUWE5k9bInSmpK98QKCAQA7zEiQMWVrIhPhh4wu\n"
      + "9YhTdUEGAaNJpLRxOPGmuKJzU8snzgSDta44xY7XsqxKc4Fs/cDCKSjWpymJM2Am\n"
      + "ARyoNQf2nJlBep4xuflB4zW5+pvtmpYTAkMqggoV36jppvPd4Rn0epyGX94eX13I\n"
      + "7lyybBw3PtOiDHE+MEIIjf36ncruj9uV9kcThKQrjxldYl5yNKTGHGXG6jIk6GWD\n"
      + "MnJzjgTRimbP+QKmGoOeKI4WtVp50gyft02bCnDUvh6U/pPWncjnBfTozejsbXQ2\n"
      + "1J7RHLTmnoVKxVvkwokJLrH9Mja0pPhv9C3WLeb3vwcQe08ic6ZzG8pOc6KEL6iT\n"
      + "O53dAoIBAGX5lUMxdruYlRxyyJ+zzA6bcDV3VilF8iy0ZJiBWgwjPPYgJA1zXKdu\n"
      + "717TNbvghdA/4sp8UP72nxdIlxYHV7vCuy2T0D70ZNwJTDBYqzs3DdGQZRHWAkXX\n"
      + "JbXWDM76GcwNIGr0MI3KWs2esG2Mv41Jwia3kUkcsB/ZtxyzKsnC1RUxrUNqENxD\n"
      + "5hfYjuMfWpPgvh7wvPp86oTHpEEYALsi50k8PK856O01vCSARnRkaxLnMTZ7vtVW\n"
      + "w4aavYrhOPBo+jhbZUVEMhenPtJ0RqqgoenVTZDhMPOp/rljd0RRGnCky4b9+MMb\n"
      + "i5QhjU90gzFXGKEiVi9NMSCtpW/0p5Y=\n"
      + "-----END PRIVATE KEY-----";

  private static final String certificateValue = "-----BEGIN CERTIFICATE-----\n"
      + "MIIGNzCCBB+gAwIBAgIJAKCkwkASL0zeMA0GCSqGSIb3DQEBCwUAMIGxMQswCQYD\n"
      + "VQQGEwJFRTEQMA4GA1UEBwwHVGFsbGlubjEkMCIGA1UECgwbTHVtaW5vciBMaWlz\n"
      + "aW5nIEFTIDEwMjM3MTQwMSIwIAYDVQQLDBlUaWV0byBFc3RvbmlhIFNlcnZpY2Vz\n"
      + "IE9VMSMwIQYDVQQDDBp0ZXN0YXBwLW5ldy5sdW1pbm9ycHJpdmF0ZTEhMB8GCSqG\n"
      + "SIb3DQEJARYSSVRfYWRtaW5AdGlldG8uY29tMB4XDTE5MDQyMzExMTEzMVoXDTIx\n"
      + "MDQyMjExMTEzMVowgbExCzAJBgNVBAYTAkVFMRAwDgYDVQQHDAdUYWxsaW5uMSQw\n"
      + "IgYDVQQKDBtMdW1pbm9yIExpaXNpbmcgQVMgMTAyMzcxNDAxIjAgBgNVBAsMGVRp\n"
      + "ZXRvIEVzdG9uaWEgU2VydmljZXMgT1UxIzAhBgNVBAMMGnRlc3RhcHAtbmV3Lmx1\n"
      + "bWlub3Jwcml2YXRlMSEwHwYJKoZIhvcNAQkBFhJJVF9hZG1pbkB0aWV0by5jb20w\n"
      + "ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDHlWsYoQAb+z1l+QEpOIpI\n"
      + "roQ3FIAia0x6b1DtcuaJUUnRZ8rgMjk2XK/WFeofU8ftBzY43fszpKCzB/C+pwUV\n"
      + "30Ke5OZ10Uoc6vuTNYuMhipSZViMgCHslW2zH4kBlLTH0MA5GYKWqQlo+nbLOnkh\n"
      + "+SUNM16E12MbvEdy67tjLvBeZHVEXiXz6Lj4rOTXdPi8rdeSEV24e3hyZbPdUBuA\n"
      + "9WEKHt8ds5qcVUjc9GvZER6BJ5LZNtO4geOxys7RxF6j6tFDIlXFGy74JXBZWzd7\n"
      + "7B+YZWHBMv4IqxCQ7aDo33U73w5wT1JutCMCDX622eEuaal/3VWqgCCZ27q++w07\n"
      + "dw3ZGFR+nuuq8euiGzu8FnjhkaXnL43j4TN/MFzrsgJJjeEFlAtlTwfa+VvzBUcg\n"
      + "+fPYGY1fAdBviIYfpgBFS+JOi3C+RlQOxohVL7UKl3qx3lxXrQLOPc+3oLjsg+9P\n"
      + "t3hOxvFGXamLqipvKgzh5ERh3kdiBI9VP8rfB+JOY8o/66RliTQmyqlZiV8Cdq6H\n"
      + "0mvNAvznVC2hvOZeZVkBtfki33doGrzCoOD4jy0xL+t3975GNt10Utv+cfR3uNE0\n"
      + "VQyRgPz1CU1Y99uj4PalwX7bLh+tm+P8EbkVWLsZaqNpeUKPVtgOdymsfOP6L7nH\n"
      + "A/PgbJKCcqzcPKtoDoNjNQIDAQABo1AwTjAdBgNVHQ4EFgQUxpboGshajE1TnjV9\n"
      + "tbqa0FS4k+swHwYDVR0jBBgwFoAUxpboGshajE1TnjV9tbqa0FS4k+swDAYDVR0T\n"
      + "BAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAgEAtzrL7ZaT9wo6p5KWTmTFndzVkUF5\n"
      + "8k/SC8+Tt0N5gOdaVrlEH3q6FYircJj9gP4mjDlg/NYshkVWNN6xDSRrj7gZc2ee\n"
      + "1BOzDFZWhWwTDEPwBmuIwUsjn6oD204c4PBYbaqtetbhidAn1qbOQ5jH7LYx7Q/h\n"
      + "pWmZMWAFpaejBiDAY6YHtl+7qOB9Oo0z71jI8tzh+Y4gG+LPFr+KsvHIFHBHNkZ0\n"
      + "rUNLb4geCemD40Kl/habWBHjYWeKJW5+d4GyMKzgWFQztLVVsqAoM9wnZ4jGKPtn\n"
      + "cn9UfaMji+HCMjeCW8wnCIBnnHgyYceEKTGoS+m+ZaDr8nZWT1AuLKArSqIS2QG9\n"
      + "40s7AueqCbs36W56WE7sDKN1MSoHGtdM/uRBfUaV0t1Vx1lFu/8Zi551wUvPV4Ze\n"
      + "5OQ/ToysMYXfnIV4ZFJ857qoPWR21hR8XYLJe+B1XISwxjOedatRoKtXdvCqacHG\n"
      + "o7Saku3/NAb68x9q3jKXcqI8zL7AAVOdWX2xk/PyMY2dn//C2qu7fA4K4yArUQCi\n"
      + "AqTygGyLQ4HPwBZLjc4gWBEF0DNTCwZOalQO6AFpfPvrPS0H5TYyiw8wOxIGoQww\n"
      + "fLJwL/0t9/KguprPGbUvrY5spxuxCQNrC/EvWb/gfmIPMCRY5g1upByWH7R+Mem8\n"
      + "sebzKq5LK2EZwBU=\n"
      + "-----END CERTIFICATE-----";
}
