package com.luminor.api.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import lombok.ToString;

@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthParams {

  private String auth_method;
  private String iss;
  private String username;
  private String lpgurl;
  private String fpgurl;
  private String spgurl;

  @JsonCreator
  public AuthParams(String auth_method, String iss,
      String username, String lpgurl, String fpgurl, String spgurl) {
    this.auth_method = auth_method;
    this.iss = iss;
    this.username = username;
    this.lpgurl = lpgurl;
    this.fpgurl = fpgurl;
    this.spgurl = spgurl;
  }

  public static class Builder {
    private String auth_method;
    private String iss;
    private String username;
    private String lpgurl;
    private String fpgurl;
    private String spgurl;

    public Builder setAuth_method(String auth_method) {
      this.auth_method = auth_method;
      return this;
    }

    public Builder setIss(String iss) {
      this.iss = iss;
      return this;
    }

    public Builder setUsername(String username) {
      this.username = username;
      return this;
    }

    public Builder setLpgurl(String lpgurl) {
      this.lpgurl = lpgurl;
      return this;
    }

    public Builder setFpgurl(String fpgurl) {
      this.fpgurl = fpgurl;
      return this;
    }

    public Builder setSpgurl(String spgurl) {
      this.spgurl = spgurl;
      return this;
    }

    public Map<String, Object> buildMap() {
      Map<String, Object> map = new HashMap<>();

      Optional.ofNullable(iss).ifPresent(o -> map.put("iss", o));
      Optional.ofNullable(username).ifPresent(o -> map.put("username", o));
      Optional.ofNullable(auth_method).ifPresent(o -> map.put("auth_method", o));
      Optional.ofNullable(spgurl).ifPresent(o -> map.put("spgurl", o));
      Optional.ofNullable(fpgurl).ifPresent(o -> map.put("fpgurl", o));
      Optional.ofNullable(lpgurl).ifPresent(o -> map.put("lpgurl", o));

      return map;
    }
  }
}
