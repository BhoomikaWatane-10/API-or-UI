package com.luminor.api.endpoints;

import static org.assertj.core.api.Assertions.assertThat;

import com.luminor.api.pojo.ErrorResponse;
import com.luminor.api.pojo.accounts.AccountBalancesResponse;
import com.luminor.api.pojo.accounts.AccountsResponse;
import com.luminor.api.pojo.accounts.TransactionListResponse;
import com.luminor.taf.Taf;
import com.luminor.taf.controllers.FrameworkException;
import com.luminor.taf.utils.ExcelDataProviderApi;
import com.luminor.utils.DateHelper;
import io.qameta.allure.Step;
import java.util.List;
import org.apache.http.HttpStatus;

public class Accounts {

  private static final ExcelDataProviderApi excel = Taf.utils().excel();

  @Step("Get account info")
  public static AccountsResponse getAccountInfo(String iban) {
    return Taf.api().rest()
        .httpGet("/accounts")
        .hasStatusCode(HttpStatus.SC_OK, "Accounts list should be returned")
        .validateJSONSchema("testdata/schemas/rest_response_get_accounts.json")
        .extractArrayAsList("accounts", AccountsResponse.class)
        .stream()
        .filter(x -> x.getIban().equals(iban))
        .findFirst()
        .orElseThrow(
            () -> new FrameworkException("Unable to get account '" + iban + "' information"));
  }

  @Step("Check accounts are unavailable")
  public static ErrorResponse checkAccountsUnavailable(int expectedHttpStatusCode) {
    Taf.utils().log().info("Checking accounts are unavailable");
    return Taf.api().rest()
        .httpGet("/accounts")
        .hasStatusCode(expectedHttpStatusCode)
        .extractArrayAsList("errors", ErrorResponse.class)
        .get(0);
  }

  @Step("Check accounts are empty")
  public static void checkAccountsAreEmpty() {
    Taf.utils().log().info("Checking accounts are empty");
    assertThat(Taf.api().rest()
        .httpGet("/accounts")
        .hasStatusCode(HttpStatus.SC_OK)
        .extractArrayAsList("accounts", AccountsResponse.class))
        .as("Accounts should be empty")
        .isEmpty();
  }

  @Step("Check account details")
  public static void checkAccountDetails(String resourceId) {
    Taf.utils().log().info("Checking details");
    assertThat(Accounts.getIbanFromAccountDetails(resourceId))
        .as("Account details IBAN should match IBAN from account list")
        .isEqualTo(excel.getValueForCurrentIteration("debtorAccount"));
  }

  @Step("Check account balances")
  public static void checkAccountBalances(String resourceId) {
    Taf.utils().log().info("Checking balances");
    assertThat(Accounts
        .getAccountBalances(resourceId)
        .getAccount()
        .getIban())
        .as("Account balances IBAN should match IBAN from account list")
        .isEqualTo(excel.getValueForCurrentIteration("debtorAccount"));
  }

  @Step("Check account transaction list")
  public static void checkAccountTransactionList(String resourceId) {
    Taf.utils().log().info("Checking transaction list");
    assertThat(Accounts
        .getTransactionListIban(resourceId))
        .as("Transaction list IBAN should match IBAN from account list")
        .isEqualTo(excel.getValueForCurrentIteration("debtorAccount"));
  }

  @Step("Check transaction list contains {0}")
  public static void checkTransactionListContainsParticularTransaction(
      String remittanceInformationUnstructured) {
    String todayDate = DateHelper.getFutureDate(0, "yyyy-MM-dd");
    assertThat(getTransactionList(
        getAccountInfo(excel.getValueForCurrentIteration("debtorAccount")).getResourceId(),
        todayDate, todayDate)
        .stream()
        .filter(
            x -> remittanceInformationUnstructured.equals(x.getRemittanceInformationUnstructured()))
        .findFirst()
        .orElseThrow(() -> new FrameworkException(
            "Unable to find transaction with remittance information '"
                + remittanceInformationUnstructured + "'"))
        .getRemittanceInformationUnstructured())
        .as("Transaction list should contain transaction with remittanceInformationUnstructured '"
            + remittanceInformationUnstructured + "'")
        .isEqualTo(remittanceInformationUnstructured);
  }

  @Step("Check transaction list unavailable")
  public static ErrorResponse checkTransactionListUnavailable(String dateFrom, String dateTo,
      String resourceId, String bookingStatus, int expectedHttpStatusCode) {
    return Taf.api().rest()
        .addQueryParameter("bookingStatus", bookingStatus)
        .addQueryParameter("dateFrom", dateFrom)
        .addQueryParameter("dateTo", dateTo)
        .httpGet("/accounts/%s/transactions", resourceId,
            dateFrom, dateTo)
        .hasStatusCode(expectedHttpStatusCode)
        .extractArrayAsList("errors", ErrorResponse.class)
        .get(0);
  }

  @Step("Call api, get /accounts/{0}")
  private static String getIbanFromAccountDetails(String resourceId) {
    Taf.utils().log().info("Getting IBAN from account details");
    return Taf.api().rest()
        .httpGet("/accounts/%s", resourceId)
        .hasStatusCode(HttpStatus.SC_OK)
        .validateJSONSchema("testdata/schemas/rest_response_get_account_details.json")
        .extractStringValue("iban");
  }

  @Step("Call api, get /accounts/{0}/balances")
  private static AccountBalancesResponse getAccountBalances(String resourceId) {
    Taf.utils().log().info("Getting account balances");
    return Taf.api().rest()
        .httpGet("/accounts/%s/balances", resourceId)
        .hasStatusCode(HttpStatus.SC_OK)
        .getResponseAsJavaObject(AccountBalancesResponse.class);
  }

  @Step("Call api, get /accounts/{0}/transactions?dateFrom={1}&dateTo={2}")
  private static List<TransactionListResponse> getTransactionList(String resourceId,
      String dateFrom, String dateTo) {
    Taf.utils().log().info("Getting first transaction from transaction list");
    return Taf.api().rest()
        .addQueryParameter("bookingStatus", "booked")
        .addQueryParameter("dateFrom", dateFrom)
        .addQueryParameter("dateTo", dateTo)
        .httpGet("/accounts/%s/transactions", resourceId,
            dateFrom, dateTo)
        .hasStatusCode(HttpStatus.SC_OK)
        .validateJSONSchema("testdata/schemas/rest_response_get_transactions.json")
        .extractArrayAsList("booked", TransactionListResponse.class);
  }

  @Step("Call api, get /accounts/{0}/transactions")
  private static String getTransactionListIban(String resourceId) {
    Taf.utils().log().info("Getting first transaction from transaction list");
    return Taf.api().rest()
        .addQueryParameter("bookingStatus", "booked")
        .addQueryParameter("dateFrom",
            DateHelper.getCurrentDateInLtFormat(DateHelper.getCurrentMonthFirstDay()))
        .addQueryParameter("dateTo", DateHelper.getFutureDate(0, "yyyy-MM-dd"))
        .httpGet("/accounts/%s/transactions", resourceId)
        .hasStatusCode(HttpStatus.SC_OK)
        .validateJSONSchema("testdata/schemas/rest_response_get_transactions.json")
        .extractStringValue("account.iban");
  }
}