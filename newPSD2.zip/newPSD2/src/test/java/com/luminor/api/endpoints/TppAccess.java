package com.luminor.api.endpoints;

import com.luminor.api.pojo.payments.CreatePaymentPayload;
import com.luminor.taf.Taf;
import com.luminor.taf.utils.ExcelDataProviderApi;
import io.qameta.allure.Step;
import org.apache.http.HttpStatus;

public class TppAccess {

  private static final String TPP_TYPE_AISP = "AISP",
      TPP_TYPE_PIISP = "PIISP",
      TPP_TYPE_PISP = "PISP",
      USER_ACCESS_RIGHTS_FULL = "full",
      USER_ACCESS_RIGHTS_INFO = "info",
      USER_ACCESS_RIGHTS_NO_ACCESS = "noaccess",
      CREDITOR_IBAN = "EE191044001008391275";


  private static ExcelDataProviderApi excel = Taf.utils().excel();

  @Step("Check service access unavailable")
  public static void checkServiceAccessUnavailable() {
    String tppType = excel.getValueForCurrentIteration("tppType").toUpperCase();
    Taf.utils().log().info("Checking TPP type '" + tppType + "' service access");
    switch (tppType) {
      case TPP_TYPE_AISP:
        Payments.checkPaymentCreationUnavailable(
            new CreatePaymentPayload(excel.getValueForCurrentIteration("debtorAccount"),
                CREDITOR_IBAN),
            HttpStatus.SC_UNAUTHORIZED);
        Funds.checkAvailableFundsUnavailable(HttpStatus.SC_UNAUTHORIZED);
        break;
      case TPP_TYPE_PIISP:
        Accounts.checkAccountsUnavailable(HttpStatus.SC_UNAUTHORIZED);
        Payments.checkPaymentCreationUnavailable(
            new CreatePaymentPayload(excel.getValueForCurrentIteration("debtorAccount"),
                CREDITOR_IBAN),
            HttpStatus.SC_UNAUTHORIZED);
        break;
      case TPP_TYPE_PISP:
        Accounts.checkAccountsUnavailable(HttpStatus.SC_UNAUTHORIZED);
        Funds.checkAvailableFundsUnavailable(HttpStatus.SC_UNAUTHORIZED);
        break;
    }
  }

  @Step("Check user rights validations")
  public static void checkUserRightsValidations(String iban) {
    String currentAccessRights = excel.getValueForCurrentIteration("currentAccessRights")
        .toLowerCase().replace(" ", "");
    Taf.utils().log().info(
        "Checking '" + iban + "' service availability with account access rights '"
            + currentAccessRights + "'");
    switch (currentAccessRights) {
      case USER_ACCESS_RIGHTS_FULL:
        Consent.checkAccountAvailableForConsentCreation(iban);
        Accounts.getAccountInfo(iban);
        break;
      case USER_ACCESS_RIGHTS_INFO:
        Consent.checkAccountUnavailableForConsentCreation(iban);
        Accounts.getAccountInfo(iban);
        Payments.checkPaymentCreationUnavailable(
            new CreatePaymentPayload(excel.getValueForCurrentIteration("debtorAccount"),
                CREDITOR_IBAN),
            HttpStatus.SC_UNAUTHORIZED);
        break;
      case USER_ACCESS_RIGHTS_NO_ACCESS:
        Consent.checkAccountUnavailableForConsentCreation(iban);
        Accounts.checkAccountsAreEmpty();
        Payments.checkPaymentCreationUnavailable(
            new CreatePaymentPayload(excel.getValueForCurrentIteration("debtorAccount"),
                CREDITOR_IBAN),
            HttpStatus.SC_UNAUTHORIZED);
        break;
    }
  }
}