package com.luminor.api.pojo.accounts;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountBalancesResponse {

  private Account account;
  private List<Balances> balances;

  @JsonCreator
  public AccountBalancesResponse(@JsonProperty("account") Account account) {
    this.account = account;
    this.balances = new ArrayList<>();
  }
}
