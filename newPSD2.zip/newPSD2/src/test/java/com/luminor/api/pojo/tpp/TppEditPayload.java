package com.luminor.api.pojo.tpp;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.luminor.api.endpoints.Tpp;
import com.luminor.taf.Taf;
import java.util.ArrayList;
import lombok.ToString;

@ToString
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class TppEditPayload {

  private String appName;
  private ArrayList<String> contacts;
  private ArrayList<String> redirectUris;

  @JsonCreator
  public TppEditPayload() {
    this.appName = Tpp.getAppName();
    contacts = new ArrayList<>();
    redirectUris = new ArrayList<>();
    contacts.add("admin@tpp-system-b.com");
    contacts.add("admin@tpp-system-c.com");
    redirectUris.add(Taf.utils().config().getEnvironmentProperty("redirect.url"));
  }
}
