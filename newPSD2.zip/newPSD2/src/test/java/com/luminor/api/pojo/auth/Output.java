package com.luminor.api.pojo.auth;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class Output {

  private String name;
  private JsonNode value;

  @JsonCreator
  public Output(
      @JsonProperty("name") String name, @JsonProperty("value") JsonNode value) {
    this.name = name;
    this.value = value;
  }
}
