package com.luminor.api.endpoints;

import static org.assertj.core.api.Assertions.assertThat;

import com.luminor.BasePsd2Test;
import com.luminor.api.models.blob.BlobModel;
import com.luminor.api.pojo.ccc.ChangeTppStatusResponse;
import com.luminor.api.pojo.ccc.RegisteredTppListResponse;
import com.luminor.api.pojo.tpp.ChangeTppStatusPayload;
import com.luminor.api.pojo.tpp.TppEditPayload;
import com.luminor.api.pojo.tpp.TppRegistrationPayload;
import com.luminor.taf.Taf;
import com.luminor.taf.utils.ExcelDataProviderApi;
import io.qameta.allure.Step;
import java.util.List;
import org.apache.http.HttpStatus;

public class Tpp {

  private static ExcelDataProviderApi excel = Taf.utils().excel();

  public static final String TPP_STATUS_PENDING = "PENDING";
  public static final String TPP_STATUS_ACTIVE = "ACTIVE";
  public static final String TPP_STATUS_BLOCKED = "BLOCKED_BY_BANK";

  private static String appName;

  @Step("Create, edit and activate new TPP")
  public static void createEditAndActivateNewTpp() {
    BasePsd2Test.setPsd2specification();
    String clientId = registerNewTpp();
    Taf.utils().log().info("New TPP client id: '" + clientId + "'");

    assertThat(editTpp(clientId).size())
        .as("Contacts list should have more than one entry")
        .isGreaterThan(1);

    Taf.utils().log().info("Activating TPP");
    BasePsd2Test.authenticateCCC();
    changeTppStatus(clientId, TPP_STATUS_ACTIVE);
  }

  @Step("Call api, post /tpp-clients")
  private static String registerNewTpp() {
    Taf.utils().log().info("Registering new TPP");
    return Taf.api().rest()
        .addRequestBody(new TppRegistrationPayload())
        .httpPost("/tpp-clients")
        .hasStatusCode(HttpStatus.SC_CREATED, "New TPP should be registered")
        .extractStringValue("clientId");
  }

  @Step("Call api, put /tpp-clients/{0}")
  private static List<String> editTpp(String clientId) {
    Taf.utils().log().info("Editing TPP");
    return Taf.api().rest()
        .addRequestBody(new TppEditPayload())
        .httpPut("/tpp-clients/" + clientId)
        .hasStatusCode(HttpStatus.SC_OK, "New TPP should be edited")
        .extractValuesFromArrayToList("contacts");
  }

  @Step("Get tpp id from tpp list by client id")
  private static Long getTppIdinCCC(String clientId) {
    Taf.utils().log().info("Getting TPP id in CCC");
    return getRegisteredTpp(clientId).getId();
  }

  @Step("Get client id, from tpp list")
  private static Long getClientIdInCCC(String tppClientId) {
    Taf.utils().log().info("Getting TPP client in CCC");
    return getRegisteredTpp(tppClientId)
        .getClients()
        .stream()
        .filter(client ->
            client.getClientId().equals(tppClientId)
        )
        .findFirst().get().getId();
  }

  @Step("Change TPP status to {1}")
  public static void changeTppStatus(String clientId,
      String tppStatus) {
    Long tppId = getTppIdinCCC(clientId);
    Long tppClientId = getClientIdInCCC(clientId);
    Taf.utils().log().info("Setting TPP status '" + tppStatus + "'");
    ChangeTppStatusResponse response = Taf.api().rest()
        .addHeader("Current-Bank-Country", "EE")
        .addRequestBody(new ChangeTppStatusPayload(tppStatus))
        .httpPatch("/tpp/%d/tpp-clients/%d", tppId, tppClientId)
        .hasStatusCode(HttpStatus.SC_OK, "TPP status should be changed to '" + tppStatus + "'")
        .getResponseAsJavaObject(ChangeTppStatusResponse.class);

    if (Tpp.TPP_STATUS_ACTIVE.equals(response.getStatus())) {
      List<BlobModel> blobModel = Blob.getJsonBlob(excel.getValueForCurrentIteration("clientIdBlob"));
      BlobModel requestModel = new BlobModel(response.getClientId());
      blobModel.add(requestModel);

      Blob.putJsonBlob(blobModel, excel.getValueForCurrentIteration("clientIdBlob"));
    }
  }

  @Step("Call api, get /tpp")
  private static RegisteredTppListResponse getRegisteredTpp(String clientId) {
    Taf.utils().log().info("Getting client id '" + clientId + "' info");
    return Taf.api().rest()
        .httpGet("/tpp")
        .hasStatusCode(HttpStatus.SC_OK)
        .extractArrayAsList("", RegisteredTppListResponse.class)
        .stream()
        .filter(tppList ->
            tppList.getClients()
                .stream()
                .anyMatch(client ->
                    client.getClientId().equals(clientId)
                )
        ).findFirst().get();
  }

  public static String getAppName() {
    return appName;
  }

  public static void setAppName(String appName) {
    Tpp.appName = appName;
  }
}