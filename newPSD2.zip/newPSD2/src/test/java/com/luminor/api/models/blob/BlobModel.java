package com.luminor.api.models.blob;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.text.SimpleDateFormat;
import java.util.Date;
import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class BlobModel {

  private String id;
  private String date;

  @JsonCreator
  public BlobModel(String id) {
    this.id = id;
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Date date = new Date();
    this.date = formatter.format(date);
  }

  @JsonCreator
  public BlobModel(@JsonProperty("id") String id,
      @JsonProperty("date") String date) {
    this.id = id;
    this.date = date;
  }
}
