package com.luminor.api.pojo.payments;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentListResponse {

  private String paymentId;
  private String transactionStatus;

  @JsonCreator
  public PaymentListResponse(@JsonProperty("paymentId") String paymentId,
      @JsonProperty("transactionStatus") String transactionStatus) {
    this.paymentId = paymentId;
    this.transactionStatus = transactionStatus;
  }
}
