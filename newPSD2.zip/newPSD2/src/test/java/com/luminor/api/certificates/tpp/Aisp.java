package com.luminor.api.certificates.tpp;

import com.luminor.taf.controllers.FrameworkException;
import com.luminor.taf.test.api.auth.utils.BouncycastleUtils;
import com.luminor.taf.test.api.auth.utils.KeystoreBuilder;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;

public class Aisp {

  private static RSAPrivateKey privateKey;
  private static X509Certificate certificate;

  public static RSAPrivateKey getPrivateKey() {
    if (privateKey == null) {
      try {
        privateKey = (RSAPrivateKey) BouncycastleUtils.getPrivateKeyFromPEM(privateKeyValue);
      } catch (Exception e) {
        throw new FrameworkException(e.getMessage());
      }
    }
    return privateKey;
  }

  public static X509Certificate getCertificate() throws Exception {
    if (certificate == null) {
      certificate = BouncycastleUtils.getX509CertificateFromPem(certificateValue);
    }
    return certificate;
  }

  public static KeyStore getKeystore() throws Exception {
    KeystoreBuilder builder = new KeystoreBuilder()
        .setPrivateKey(getPrivateKey(), getCertificate(), "1")
        .setCert("tppca", TppCA.getCaCertificate())
        .setKeystorePassword("changeit");
    KeyStore keyStore = builder.build();
    return keyStore;
  }

  private static final String privateKeyValue = "-----BEGIN PRIVATE KEY-----\n"
      + "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDcpnLCvfos/jvd\n"
      + "hAf7PvivG6gXYusj2BXCFo4BftA4RMT2JkRHqK1WYjjG/E5pPe+A76R8VB/ojno4\n"
      + "W70txMu48RokSyAX43f3YBWDUIQ3Qq2z2uM2qW4SOPrTk7PboC7CW63WKptlxRjt\n"
      + "9XiCSmFnkbecLOwE1HuaJxbYFfwbvuOojMcixP5kHoX68qQH3S8cSylpETojpZV9\n"
      + "lKXDV+upBFfhXrU+lUHQ9dVZgo9n2yiJESbLQ65ya7pe3E7KOdRutrUHn+7gcHJL\n"
      + "8ny0I2+ViBOXLUeMih5dn6wRmOwhSEwIpThfCYxuJiiSQ05p6fzHeOeC7tCiAP6c\n"
      + "1ZCH5PyZAgMBAAECggEBAMgbH9qjBf7F9i7XrZFas5fC4jeLWyqfrmPdpp2Oj3Fo\n"
      + "VKPTYnsGa2T7IPi9GrNxGwL40lh6xpFWnVr9P90BK6ym44lkpE9l2Id9GSWE4NNo\n"
      + "4jVJXmRVVeCq0jcNLcERTTawhD/FVjb+f7RWuRqYMCwIR9cYGlfrB8luh9YiYggZ\n"
      + "8C7GJDjwPAS10guHFNyiP/uhTW4S0+gvdmGw8OJHMsLgHTPLbhyxdZQAGvWxp13S\n"
      + "DwvwrfWAt4e1DJphb7AgmqEfY/8/eQ7QVMWUHWr8NAHUNCR3S6HrA+0T3m8OxT1C\n"
      + "ldtZRfgtj2tWuxU0r4QB4hce5IFSoRZ2ho8a3EGWLz0CgYEA7DMxbfCp1fQaETXf\n"
      + "eyIK1m+8bMR9ZZiTCkp7S+zl9rkqNvBZgHyAl9OvUKijwBdSq5+OabVQ6uzBMqWD\n"
      + "3xd8lrjhoP7eTuTQCRMxPHIecX20DW9DgE/LqlqzE1RODcipsb5O99z9XxlZzvmg\n"
      + "iA7BtQ3ZyWWMFkrxaYYkFXvX7dcCgYEA7yWPTELCmgCMDZAYbQJW3lPq/SIj/1yA\n"
      + "SP4Y4zhTlhvUUnvM/i0qHf1WTfJpKF1MRgMitIN5TdwcE3ChdNjjFvax3KLfBlWU\n"
      + "04zfBuGCVTcX7XbJBXnM55Lrg2kNA/char5Buge3O1AcgFglDWnphOeoQlm+A3NW\n"
      + "59hQcQxOuw8CgYEAlH+e/QLIlCYS2W0oYu7FJ4o6SZvDRsOE9nxbRiHbdqF1g/La\n"
      + "ImikJFBHMYvE37kKFbKLw7Pl+rz8vg3HedP3VX9JA4IZXDqI/JufYeRRdYLVV3jz\n"
      + "VFFWt3Ssj2N6azoUThZa6YR7m3WBvBm/LqswZ9ccbH02dLGLU4+tUgB5giMCgYEA\n"
      + "6m2zT1qSUUz//bundhS4+zDgRkxVZVpUFzmfQ/5PUfLt6/2YMgIsK0HQfJCJLRxo\n"
      + "TKl+N945521ByHy8iUKjOjuSl2rBnf/+6HJLnv8pOEfNmOa8oDWJ++g2Hpe4Po7f\n"
      + "nzfqTmaJ5AbgKaA+kiuk0rgUZRZ8Af3qz1NpZ6hc9VkCgYAiEg0jj2aLvT06rfKv\n"
      + "1MCiIZrM+Klr78gidsbtkSRIELylO+1/V1RZEWipInu0RRbtTLlDJ3xW2qYaF2xS\n"
      + "11RvulbPcn0MnwQqtjitOg6PB4lJJ6suARRvD14F/a3ozbkU3c21qKhztWn99jVU\n"
      + "DPelvyl4VHpDsYoVQzkXMg9UAQ==\n"
      + "-----END PRIVATE KEY-----";

  private static final String certificateValue = "-----BEGIN CERTIFICATE-----\n"
      + "MIIEyzCCArOgAwIBAgIEAQIDBDANBgkqhkiG9w0BAQsFADA5MQswCQYDVQQGEwJF\n"
      + "RTETMBEGA1UECgwKU3VwZXIgaW5jLjEVMBMGA1UEAwwMUFNEMiBUZXN0IENBMB4X\n"
      + "DTE5MTIwMjAzMTMwMFoXDTI1MTIwMjAzMTMwMFowXzEZMBcGA1UEYRMQUFNERVMt\n"
      + "QkRFLTNERkQwMjELMAkGA1UEBhMCRUUxFTATBgNVBAMTDEF1dG9UZXN0QUlTUDEe\n"
      + "MBwGA1UEChMVVGVzdCBQYXltZW50IFByb3ZpZGVyMIIBIjANBgkqhkiG9w0BAQEF\n"
      + "AAOCAQ8AMIIBCgKCAQEA3KZywr36LP473YQH+z74rxuoF2LrI9gVwhaOAX7QOETE\n"
      + "9iZER6itVmI4xvxOaT3vgO+kfFQf6I56OFu9LcTLuPEaJEsgF+N392AVg1CEN0Kt\n"
      + "s9rjNqluEjj605Oz26Auwlut1iqbZcUY7fV4gkphZ5G3nCzsBNR7micW2BX8G77j\n"
      + "qIzHIsT+ZB6F+vKkB90vHEspaRE6I6WVfZSlw1frqQRX4V61PpVB0PXVWYKPZ9so\n"
      + "iREmy0Oucmu6XtxOyjnUbra1B5/u4HByS/J8tCNvlYgTly1HjIoeXZ+sEZjsIUhM\n"
      + "CKU4XwmMbiYokkNOaen8x3jngu7QogD+nNWQh+T8mQIDAQABo4G0MIGxMAsGA1Ud\n"
      + "DwQEAwIBxjAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwgYIGCCsGAQUF\n"
      + "BwEDBHYwdDAIBgYEAI5GAQEwCwYGBACORgEDAgEUMAgGBgQAjkYBBDATBgYEAI5G\n"
      + "AQYwCQYHBACORgEGAzA8BgYEAIGYJwIwMjATMBEGBwQAgZgnAQMMBlBTUF9BSQwT\n"
      + "Q29tcGV0ZW50IEF1dGhvcml0eQwGRUUtUEFZMA0GCSqGSIb3DQEBCwUAA4ICAQCp\n"
      + "s8/mzIWmlC1g9l6Sa+dYgOZeWGSDTtoskd/CCtDFphl0jaUJRmSzqBWZh5rUCiKj\n"
      + "YcPvVA3KstyUkA7Qz4lt9sPUphDrTFOY5mfYDLUaKFuhvGmbXLFLF754vFeBQahw\n"
      + "NRigvV0NlOlT+9SxvYeUwa4078sYT9Xbgvjzkt5iJKL1Qruah2ztPTtk/Ps1Vxtk\n"
      + "hwzvMxwLwMfr2bfWdymVURLYhJuCSRXGCe+5qw9FdXufLoXTxhXl8rrlEK7/NqNN\n"
      + "mU5EJp+IygZiUZPVwERBpdhw4tkumC7opXkmgBLJi+lmX48UcbBEnekd4TUPinYI\n"
      + "agCJh07dYa3yfxu93Ls63ZPXs3fR5hFZ7pDwCyWZWpixNaIl6PhUxnbGZDAspt3A\n"
      + "wcc4fnwPuaPGDbiG/SvVvRQLusAH6+MgvywUtHGPaqhYv/czP1wuEE9i9tMcNhtc\n"
      + "5sZqKV7AIuebyU0BZpdkgaAw0IW9fCxQ29Mh7cWZPLXeMYKPWRwJS4Hrm4zCxzya\n"
      + "SZEaS6gcCSuFX4kCVQq9XlB4+KGLS8wX4+FXBLGmfbo+xJZN4KviT8gsGyh699St\n"
      + "NmIGutT+WKsSC7Jp5Lh2gcvyGn5CE5YJdO2pMtEFw7QJo0GkxNmLtB8+bY/5IfpV\n"
      + "hAzf7mS3W56rAef8kwgzi+2YdWk0V9NYRH1vuBR9cQ==\n"
      + "-----END CERTIFICATE-----";

}
