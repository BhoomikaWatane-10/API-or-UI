package com.luminor.pageobjects;

import static com.codeborne.selenide.Selenide.$;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import io.qameta.allure.Step;

public class PaymentPage extends Psd2 {

  SelenideElement buttonSign = $(".button.layout-default.size-default"),
      tableCreditorInfo = $(".layout-wide-content.layout-wide-column2"),
      tableDebtorInfo = $(".layout-wide-content.layout-wide-column1"),
      animationClock = $(".animation-clock");

  public PaymentPage(){
    //animationClock.shouldNotBe(Condition.visible.because("page loading has not been completed"));
    tableCreditorInfo.shouldHave(Condition.text(Taf.utils().excel().getValueForCurrentIteration("creditorAccount")));
    tableDebtorInfo.shouldHave(Condition.text(Taf.utils().excel().getValueForCurrentIteration("debtorAccount")));
  }

  @Step("Sign consent via SmartID")
  public SuccessPage signPayment() {
    buttonSign.shouldBe(Condition.visible.because("SmartID sign button should be visible")).click();

    return new SuccessPage();
  }
}
