package com.luminor.pageobjects;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import io.qameta.allure.Step;

import java.io.IOException;

public class AuthPage extends Psd2 {

  SelenideElement fieldLogin = $("#idToken4"), fieldPersonalCode = $("#idToken6"),
      buttonLogin = $("#idToken15_0"), buttonFirstRepresentative = $(".representative-button"),
      buttonConfirm = $("#idToken3_0"), buttonCancel = $("#idToken4_1"),
      iconLoadingClock = $(".fa.fa-clock-o.fa-2x");

  ElementsCollection listRepresentatives = $$(".flexbox-container");

  public AuthPage() {
    fieldLogin.shouldBe(visible.because("PSD2 auth page should be displayed"));
  }

  @Step("Set TPP login form values")
  public AuthPage setLoginDetails() {
    fieldLogin.sendKeys(Taf.utils().excel().getValueForCurrentIteration("username"));
    fieldPersonalCode.sendKeys(Taf.utils().excel().getValueForCurrentIteration("personalCode"));
    fieldPersonalCode.clear();
    fieldPersonalCode.sendKeys(Taf.utils().excel().getValueForCurrentIteration("personalCode"));

    return this;
  }

  @Step("Select customer")
  public RedirectionPage selectCustomer() {
    selectRepresentative();
    buttonConfirm.shouldBe(visible.because("confirm button should be visible")).click();

    return new RedirectionPage();
  }

  @Step("Select customer for consent signing")
  public ConsentPage selectCustomerForConsentSigning() {
    selectRepresentative();

    return new ConsentPage();
  }

  @Step("Select customer for payment signing")
  public PaymentPage selectCustomerForPaymentSigning() {
    selectRepresentative();

    return new PaymentPage();
  }
  @Step("Select customer for payment signing for Blanked IBAN")
  public BlankedIBANPaymentPage selectCustomerForPaymentSigningForBlankedIBAN() {
    selectRepresentative();

    return new BlankedIBANPaymentPage();
  }
  @Step("Select customer for instant payment signing")
  public InstantPaymentPage selectCustomerForInstantPaymentSigning() throws IOException {
    selectRepresentative();

    return new InstantPaymentPage();
  }

  @Step("Select customer for instant payment signing")
  public InstantPaymentInsufficientPage selectCustomerForInstantPaymentSigningForInsufficientPage() throws IOException {
    selectRepresentative();

    return new InstantPaymentInsufficientPage();
  }

  @Step("Press 'Login' button")
  public AuthPage pressLoginButton() {
    buttonLogin.click();

    return this;
  }

  private void selectRepresentative(){
    boolean hasRepresentatives = false;
    buttonCancel.shouldBe(visible.because("PIN input screen should be visible"));
    buttonCancel.shouldNotBe(visible.because("no code confirmation from smart ID"));
    iconLoadingClock.shouldNotBe(visible.because("page is still loading data"));

    if (listRepresentatives.size() > 0){
      hasRepresentatives = buttonFirstRepresentative.exists();
    }
    if (hasRepresentatives) {
      buttonFirstRepresentative.click();
    }
  }

  @Step("Select customer for transaction signing")
  public TransactionHistoryPage selectCustomerForTransactionSigning() {
    selectRepresentative();

    return new TransactionHistoryPage();
  }
}
