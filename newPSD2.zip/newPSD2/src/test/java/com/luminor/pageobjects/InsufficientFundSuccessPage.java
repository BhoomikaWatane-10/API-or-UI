package com.luminor.pageobjects;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.Psd2;
import io.qameta.allure.Step;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$x;

public class InsufficientFundSuccessPage extends Psd2 {

  SelenideElement
          iconSuccess =$(".generalerror-text"),
      buttonBackToServiceProvider = $(".button.layout-default.size-default");


  @Step("Verify success message is displayed")
  public InsufficientFundSuccessPage verifySuccessMessageIsDisplayedForInsufficientFund() {
    iconSuccess.shouldBe(Condition.visible.because("Insufficient Fund visible"));
    buttonBackToServiceProvider.shouldBe(Condition.visible.because("back to service provider button is not visible"));

    return this;
  }
}
