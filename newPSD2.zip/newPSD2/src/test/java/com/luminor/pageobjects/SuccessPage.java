package com.luminor.pageobjects;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;
import static org.testng.AssertJUnit.assertTrue;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import io.qameta.allure.Step;

public class SuccessPage extends Psd2 {

  SelenideElement iconSuccess = $(".animation-success"),
      buttonBackToServiceProvider = $(".button.layout-default.size-default");


  @Step("Verify success message is displayed")
  public SuccessPage verifySuccessMessageIsDisplayed() {
    iconSuccess.shouldBe(Condition.visible.because("success animation not visible"));
    buttonBackToServiceProvider.shouldBe(Condition.visible.because("back to service provider button is not visible"));

    return this;
  }
}
