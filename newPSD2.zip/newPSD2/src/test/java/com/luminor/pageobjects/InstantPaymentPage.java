package com.luminor.pageobjects;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.BasePsd2Test;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import io.qameta.allure.Step;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.$;

public class InstantPaymentPage extends Psd2 {

  SelenideElement buttonSign = $(".button.layout-default.size-default"),
      tableCreditorInfo = $(".layout-wide-content.layout-wide-column2"),
      tableDebtorInfo = $(".layout-wide-content.layout-wide-column1"),
      animationClock = $(".animation-clock");

  public InstantPaymentPage() throws IOException {
    //animationClock.shouldNotBe(Condition.visible.because("page loading has not been completed"));
    tableCreditorInfo.shouldHave(Condition.text(BasePsd2Test.getPropertyFromFile("Creditoriban")));
    tableDebtorInfo.shouldHave(Condition.text(BasePsd2Test.getPropertyFromFile("debitoriban")));
  }



  @Step("Sign consent via SmartID")
  public SuccessPage instantsignPayment() {
    buttonSign.shouldBe(Condition.visible.because("SmartID sign button should be visible")).click();

    return new SuccessPage();
  }


}
