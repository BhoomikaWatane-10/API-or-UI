package com.luminor.pageobjects;

import static com.codeborne.selenide.Selenide.$;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import io.qameta.allure.Step;

public class ConsentPage extends Psd2 {

  SelenideElement buttonSign = $(".button.layout-default.size-default"),
      tableAccountInfo = $(".scrollable-table-wrapper.no-actions-visible");

  public ConsentPage(){
    tableAccountInfo.shouldHave(Condition.text(Taf.utils().excel().getValueForCurrentIteration("debtorAccount")));
  }

  @Step("Sign consent via SmartID")
  public SuccessPage signConsent() {
    buttonSign.shouldBe(Condition.visible.because("SmartID sign button should be visible")).click();

    return new SuccessPage();
  }


}
