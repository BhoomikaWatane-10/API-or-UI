package com.luminor.pageobjects;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.BasePsd2Test;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import io.qameta.allure.Step;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$x;

public class BlankedIBANPaymentPage extends Psd2 {

  SelenideElement buttonSign = $(".button.layout-default.size-default"),
      tableCreditorInfo = $(".layout-wide-content.layout-wide-column2"),
      tableDebtorInfo = $x("//span[@class='link-with-menu-icon']"),
      animationClock = $(".animation-clock");

  public BlankedIBANPaymentPage(){
    //animationClock.shouldNotBe(Condition.visible.because("page loading has not been completed"));

    //tableDebtorInfo.shouldHave(Condition.text(Taf.utils().excel().getValueForCurrentIteration("debtorAccount")));
  }

  @Step("Sign consent via SmartID")
  public SuccessPage signPaymentForBlankedIBAN() {

    buttonSign.shouldBe(Condition.visible.because("SmartID sign button should be visible")).click();

    return new SuccessPage();
  }


}
