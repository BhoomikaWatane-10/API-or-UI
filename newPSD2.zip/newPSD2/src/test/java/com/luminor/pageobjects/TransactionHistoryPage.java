package com.luminor.pageobjects;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.Psd2;
import io.qameta.allure.Step;

import static com.codeborne.selenide.Selenide.$;

public class TransactionHistoryPage extends Psd2 {
    SelenideElement buttonSign = $(".button.layout-default.size-default"),
            //tableCreditorInfo = $(".layout-wide-content.layout-wide-column2"),
         //   tableDebtorInfo = $(".layout-wide-content.layout-wide-column1"),
            animationClock = $(".animation-clock");
    public TransactionHistoryPage(){



            //animationClock.shouldNotBe(Condition.visible.because("page loading has not been completed"));
            //tableCreditorInfo.shouldHave(Condition.text(Taf.utils().excel().getValueForCurrentIteration("creditorAccount")));
            //tableDebtorInfo.shouldHave(Condition.text(Taf.utils().excel().getValueForCurrentIteration("debtorAccount")));
        }

        @Step("Sign consent via SmartID")
        public SuccessPage signTransaction() {
            buttonSign.shouldBe(Condition.visible.because("SmartID sign button should be visible")).click();

            return new SuccessPage();
        }
    }


