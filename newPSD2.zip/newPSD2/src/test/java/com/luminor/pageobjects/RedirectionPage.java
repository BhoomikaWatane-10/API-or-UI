package com.luminor.pageobjects;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.sleep;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;
import static com.luminor.BasePsd2Test.excel;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.luminor.Psd2;
import com.luminor.taf.Taf;
import com.luminor.utils.UrlHelper;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RedirectionPage extends Psd2 {

  private SelenideElement generalError;
  private SelenideElement accountList;
  private SelenideElement confirmButton;
  private SelenideElement firstAccount;
  private SelenideElement navBar;


  @Step("Check if there are accounts to select, select first account if found")
  public RedirectionPage checkAccountSelection() {
    ExpectedCondition<Boolean> conditions = ExpectedConditions.or(
        ExpectedConditions.visibilityOf(confirmButton),
        ExpectedConditions.visibilityOf(generalError),
        ExpectedConditions.visibilityOf(accountList)
    );
    waitForConditions(conditions);

    Taf.utils().log().debug("Capturing and attaching webpage screenshot");
    Allure
        .addAttachment("Screenshot", "image/png",
            Taf.web().browser().takeScreenshot("Account list"), "png");

    ElementsCollection accounts = accountList.findAll("div[class*='btn mandate-selection']");
    SelenideElement authAccount = accounts.filter(text(excel.getValueForCurrentIteration("authMethod"))).first();
    if(authAccount.exists()){
      firstAccount = authAccount;
    }else{
      firstAccount = accounts.first();
    }

    if (generalError.exists()) {
      return this;
    }

    if (accountList.exists()) {
      firstAccount.click();
    }

    return this;
  }

  @Step("Press confirm button")
  public RedirectionPage pressConfirmButton(String url) {
    ExpectedCondition<Boolean> conditions = ExpectedConditions.or(
        ExpectedConditions.visibilityOf(confirmButton),
        ExpectedConditions.and(
            ExpectedConditions.urlContains(url),
            ExpectedConditions.urlContains("code"))
    );
    waitForConditions(conditions);

    Taf.utils().log().debug("Capturing and attaching webpage screenshot");
    Allure
        .addAttachment("Screenshot", "image/png",
            Taf.web().browser().takeScreenshot("Confirmation button"), "png");

    if (confirmButton.exists()) {
      confirmButton.click();
    }

    return this;
  }

  @Step("Get 'code' value from url")
  public String getCodeFromUrl(String redirectUrl) {
    String url = Taf.web().browser().getCurrentUrl();
    String code = "";
    ExpectedCondition<Boolean> conditions = ExpectedConditions.or(
        ExpectedConditions.and(
            ExpectedConditions.urlContains(redirectUrl),
            ExpectedConditions.urlContains("code"))
    );
    waitForConditions(conditions);

    code = UrlHelper.getValueFromUrl("code");
    if(code.equals("")){
      Taf.utils().log().error("Did not find 'code' in url: " + url);
    }

    return code;
  }

  @Step("Set up wait timeout")
  private void waitForConditions(ExpectedCondition<Boolean> conditions) {
    WebDriver driver = Taf.web().browser().getWebDriver();
    Integer timeoutMilliSec = Taf.utils().config().getIntPropertyValue("selenide.timeout");
    Integer timeoutSec = timeoutMilliSec / 1000;

    //waits for first or second condition
    WebDriverWait wait = new WebDriverWait(driver, timeoutSec);
    wait.until(conditions);
  }
}
