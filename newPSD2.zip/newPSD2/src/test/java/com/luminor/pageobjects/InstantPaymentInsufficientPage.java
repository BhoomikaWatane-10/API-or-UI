package com.luminor.pageobjects;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.luminor.BasePsd2Test;
import com.luminor.Psd2;
import io.qameta.allure.Step;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.$;

public class InstantPaymentInsufficientPage extends Psd2 {

  SelenideElement buttonSign = $(".button.layout-default.size-default"),
      tableCreditorInfo = $(".layout-wide-content.layout-wide-column2"),
      tableDebtorInfo = $(".layout-wide-content.layout-wide-column1"),
      animationClock = $(".animation-clock");

  public InstantPaymentInsufficientPage() throws IOException {
    //animationClock.shouldNotBe(Condition.visible.because("page loading has not been completed"));
    tableCreditorInfo.shouldHave(Condition.text(BasePsd2Test.getPropertyFromFile("Creditoriban")));
    tableDebtorInfo.shouldHave(Condition.text(BasePsd2Test.getPropertyFromFile("IbanForInsuffientFund")));
  }




  @Step("Sign consent via SmartID")
  public InsufficientFundSuccessPage instantsignPaymentForSufficientFund() throws IOException {

    buttonSign.shouldBe(Condition.visible.because("SmartID sign button should be visible")).click();

    return new InsufficientFundSuccessPage();
  }
}
