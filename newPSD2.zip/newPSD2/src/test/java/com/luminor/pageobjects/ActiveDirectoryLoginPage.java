/*
 * Copyright (c) 2020, Luminor Bank - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
package com.luminor.pageobjects;

import static com.codeborne.selenide.Condition.exist;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.ex.ElementNotFound;
import com.luminor.taf.Taf;
import com.luminor.taf.test.web.BaseWebPage;
import io.qameta.allure.Step;
import org.openqa.selenium.By;

public class ActiveDirectoryLoginPage extends BaseWebPage {

  private SelenideElement
      inputUsername = $("#i0116"),
      buttonNext = $("#idSIButton9"),
      inputPassword = $("#i0118"),
      buttonSignIn = $("#idSIButton9"),
      checkboxDontShowThisAgain = $("#KmsiCheckboxField"),
      buttonDoNotSignedIn = $("#idBtn_Back");

  private boolean userAlreadyLoggedIn = false;

  @Step("Enter and submit username")
  public ActiveDirectoryLoginPage enterAndSubmitDefaultUsername() {
    inputUsername.should(visible.because("1st AD login form should be visible"));
    Taf.web().browser().enterDefaultUserValueTo(inputUsername);
    buttonNext.click();

    return this;
  }

  @Step("Enter and submit password")
  public ActiveDirectoryLoginPage enterAndSubmitDefaultPassword() {
    inputPassword.shouldBe(visible.because("2nd AD login form should be visible"));
    Taf.web().browser().enterDefaultPasswordValueTo(inputPassword);
    buttonSignIn.click();

    return this;
  }

  @Step("Ignore stay logged in option")
  public ActiveDirectoryLoginPage ignoreStayLoggedInOption() {
    try {
      checkboxDontShowThisAgain.waitUntil(exist, 2);
    } catch (ElementNotFound e) {
      Taf.utils().log().info("AD stay signed in form is not displayed - skipping..");

      return this;
    }
    checkboxDontShowThisAgain.click();
    buttonDoNotSignedIn.click();

    return this;
  }

  @Step("Wait for application to load")
  public ActiveDirectoryLoginPage waitForApplicationToLoad() {
    $(By.className("frame-internalbasic"))
        .shouldBe(visible.because("Application should complete loading after AD login"));

    return this;
  }
}
