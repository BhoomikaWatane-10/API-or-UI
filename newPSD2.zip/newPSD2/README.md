PSD2 (Payment Services Directive 2) tests scope: https://confluence.luminorgroup.com/pages/viewpage.action?spaceKey=OLC&title=PSD2+test+automation

TPP - Third Party Provider: an entity authorized to access accounts on behalf of customers but that does not operate those accounts themselves. TPPs include PISPs, AISPs, and PIISPs. TPP can have more than one TPP app.
PISP - Payment Initiation Service Provider: TPP that is authorized to initiate payment services.
AISP - Account Information Service Provider: TPP that is authorized to access account information on behalf of customer.
PIISP - Payment Instrument Issuer Service Provider: TPP that is authorized for payment instrument issuance and usage of confirmation of funds service. The other abbreviation of the same TPP role used in other Open Banking Standards (e.g. Open Banking UK Standard) or communication is CBPII (Card Based Payment Instrument Issuer).
ASPSP - Account Servicing Payment Service Provider: financial institution that offers payment accounts (e.g. current accounts, credit cards) with online access (internet banking) are considered ASPSP. Under PSD2 they are obliged to open up an interface to allow authorised and registered TPPs to initiate payments and access account information. Examples of ASPSP include banks, building societies, credit unions.

More info: https://confluence.luminorgroup.com/pages/viewpage.action?spaceKey=OLC&title=PSD2+1.1