@Library('common-libraries') _
testPipelineGradleOnprem(
        product: 'aml-suite',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'new-bank-aml-suite-migration',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'ee-tst',
        gradleCommand: "cleanTest test -Psuite=kycRegressionEe -Dselenide.browser=chrome --stacktrace",
        envToCheckUrl: 'https://staging.luminor.fcc-sironafcs.com/acm',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results'
)