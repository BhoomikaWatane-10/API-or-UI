@Library('common-libraries') _
testPipelineGradle(
        product: 'aml-suite',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'new-bank-aml-suite-migration',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'devRegression',
        gradleCommand: "cleanTest test -Psuite=acmRegression -Dselenide.browser=chrome -Dacm.environment=dev --stacktrace",
        envToCheckUrl: 'https://dev.luminor.fcc-sironafcs.com/acm/',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results'
)