@Library('common-libraries') _
testPipelineGradle(
        product: 'aml-suite',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'new-bank-aml-suite-migration',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: "cleanTest test -Psuite=tcrRegression -Dselenide.browser=chrome -Dtcr.environment=stage --stacktrace",
        envToCheckUrl: 'https://tcr.staging.luminor.fcc-sironafcs.com/tcr',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results'
)