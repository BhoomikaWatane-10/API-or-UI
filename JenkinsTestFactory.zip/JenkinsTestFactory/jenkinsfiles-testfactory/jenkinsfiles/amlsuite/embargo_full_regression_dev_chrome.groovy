@Library('common-libraries') _
testPipelineGradle(
        product: 'aml-suite',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'new-bank-aml-suite-migration',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'embargo_dev_new',
        gradleCommand: "cleanTest test -Psuite=embargoFullRegression -Dselenide.browser=chrome -Dselenide.headless=true -Dembargo.environment=stage -Dselenide.headless=true --stacktrace",
        envToCheckUrl: 'https://sironembargo.staging.luminor.fcc-sironafcs.com/sironembargo',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results'
)