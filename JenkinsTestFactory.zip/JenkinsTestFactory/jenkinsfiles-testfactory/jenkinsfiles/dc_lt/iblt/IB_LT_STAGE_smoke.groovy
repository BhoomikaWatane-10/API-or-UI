@Library('common-libraries') _
testPipelineGradleOnprem(
        product: 'digital_channels_lt',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'digital_channels_lt',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'ee-tst',
        gradleCommand: 'clean test -Psuite=smoke -Dproject.environment.name=stage --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: '',
        sendEmailTo: ''
)