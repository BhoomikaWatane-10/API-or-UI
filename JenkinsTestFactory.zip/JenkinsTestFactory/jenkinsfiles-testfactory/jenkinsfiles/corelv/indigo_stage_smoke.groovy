@Library('common-libraries') _
testPipelineGradleOnprem(
        product: 'indigo',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'indigo',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'ee-tst',
        gradleCommand: 'clean test -Psuite=smoke -Dproject.environment.name=stage -Dproject.country=lv --stacktrace',
        envToCheckUrl: 'http://s1lv-platweb1.dnb.lv:8000',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: '',
        sendEmailTo: ''
)