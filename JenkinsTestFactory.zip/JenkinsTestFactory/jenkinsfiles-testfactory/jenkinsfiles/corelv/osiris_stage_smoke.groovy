@Library('common-libraries') _
testPipelineGradleOnprem(
        product: 'osiris',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'osiris',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'lv-stg',
        gradleCommand: 'clean test -Psuite=smoke -Dproject.environment.name=stage -Dproject.country=lv --stacktrace',
        envToCheckUrl: 'http://s1lv-platweb1.dnb.lv:8770/',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: '',
        sendEmailTo: ''
)
