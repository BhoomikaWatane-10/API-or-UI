@Library('common-libraries') _
testPipelineGradleOnprem(
        product: 'indigo',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'indigo',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'ee-tst',
        gradleCommand: 'clean test -Psuite=smoke -Dproject.environment.name=test -Dproject.country=lv --stacktrace',
        envToCheckUrl: 'http://t1lv-platweb1.dnb.lv:8000',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: 'https://luminorgroup.webhook.office.com/webhookb2/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/abc1ce4719314bcc801e44bdcc9a5e8f/ec799f02-acc0-49cf-a50b-1962d70e5971',
        sendEmailTo: 'simmo.soonsein@luminorgroup.com'
)