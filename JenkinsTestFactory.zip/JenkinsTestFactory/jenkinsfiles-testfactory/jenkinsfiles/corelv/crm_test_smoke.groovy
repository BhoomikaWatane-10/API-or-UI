@Library('common-libraries') _
testPipelineGradleOnprem(
        product: 'crm',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'crm',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'ee-tst',
        gradleCommand: 'clean test -Psuite=smoke -Dproject.environment.name=test -Dproject.country=lv --stacktrace',
        envToCheckUrl: 'http://t1lv-crmapp1.dnb.lv:7003/CRM',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: '',
        sendEmailTo: ''
)