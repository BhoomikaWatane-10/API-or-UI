@Library('common-libraries') _
testPipelineGradle(
        product: 'bancs',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'bancs',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test -Psuite=regression_ecommerce -Dproject.environment.name=test --stacktrace',
        envToCheckUrl: 'https://ee.tst.lumsolutions.net',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/db8b1985b76f404faec30f2ef756ca91/b719bb76-e265-45f2-b311-a39155d60d8e',
        sendEmailTo: 'vaidas.kavaliunas@luminorgroup.com, Evaldas.Sudvajus@consult.luminorgroup.com, Nimna.Krishnan@consult.luminorgroup.com, Jyothi.Bheempalli@consult.luminorgroup.com, Anil.Chaturvedy@consult.luminorgroup.com, deniss.locmelis@consult.luminorgroup.com, Vitalijs.Masans@consult.luminorgroup.com, Deniss.Ivanovs@consult.luminorgroup.com'
)