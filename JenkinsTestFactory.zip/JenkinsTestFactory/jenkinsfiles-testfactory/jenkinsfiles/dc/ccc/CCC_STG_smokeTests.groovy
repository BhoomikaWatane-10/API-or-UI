@Library('common-libraries') _
testPipelineGradle(
        product: 'ccc',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'ccc',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test -Psuite=smoke -Dproject.environment.name=stage --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: 'https://outlook.office.com/webhook/b21be1ef-00e6-4cbb-9c1f-18ceda1c2fa9@5bdfb231-1958-42c0-8a9b-0cda186703b2/IncomingWebhook/3bcd9853bca044f3bd5e5c5d6b035194/88d8a465-8d2a-4110-bdc4-b48c9be63a81',
        systemPasswordKey: 'jenkins-ccc-stg-key',
        sendEmailTo: 'vaidas.kavaliunas@luminorgroup.com, Mantas.Nugaras@consult.luminorgroup.com, Ricardas.Sliapikas@consult.luminorgroup.com, Linas.Slepikas@luminorgroup.com, Aurimas.Kanapeckas@luminorgroup.com, Albert.Klenovski@consult.luminorgroup.com, Martynas.Bajoraitis@consult.luminorgroup.com, Ruslan.Bobrov@consult.luminorgroup.com, Robertas.Kamsiukas@consult.luminorgroup.com'
)