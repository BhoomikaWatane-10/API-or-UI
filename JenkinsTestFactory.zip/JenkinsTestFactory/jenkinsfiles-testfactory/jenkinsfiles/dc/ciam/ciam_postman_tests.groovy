@Library('common-libraries') _
testPipelineNewman(
        product: 'ciam',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'postman',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        newmanCollection: 'ciam/CIAM.postman_collection.json',
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/b29b6395489a4343aacab6e1e99c3534/b719bb76-e265-45f2-b311-a39155d60d8e'

        //TODO: environments are missing, certificates non mandatory at the moment
        //newmanEnvironment: 'ciam/TST.postman_environment.json',
        //newmanArgs: '--ssl-client-cert fallback/cert/aisp.crt --ssl-client-key fallback/cert/aisp_private.key',
)