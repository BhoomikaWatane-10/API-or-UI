@Library('common-libraries') _
testPipelineGradle(
        product: 'drupal',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'drupal',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test -Psuite=sanity --tests SanityTests.checkDrupalProxy -Dproject.environment.name=test --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/c50166cf170f4ac09622a2e4a2666f8c/349a6a04-d01a-4a88-97b3-823a9c3189af',
        sendEmailTo: 'Mantas.Nugaras@consult.luminorgroup.com, Evaldas.Sudvajus@consult.luminorgroup.com'
)