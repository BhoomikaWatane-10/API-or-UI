@Library('common-libraries') _
testPipelineGradle(
        product: 'psd2-fallback',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'psd2-fallback',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test -Psuite=regression -Dproject.environment.name=stage --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/9788d6a6a849499487e9bfdf1d431f02/b719bb76-e265-45f2-b311-a39155d60d8e',
        sendEmailTo: 'Mantas.Nugaras@consult.luminorgroup.com, Ricardas.Sliapikas@consult.luminorgroup.com, Mahesh.Kumarasan@consult.luminorgroup.com'
)