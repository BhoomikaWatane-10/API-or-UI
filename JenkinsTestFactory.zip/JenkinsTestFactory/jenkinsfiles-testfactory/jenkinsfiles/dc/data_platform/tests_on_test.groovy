@Library('common-libraries') _
testPipelineNewman(
        product: 'data-platform',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'postman',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        newmanCollection: 'dataplatform/DataPlatform_ALL.json',
        newmanEnvironment: 'dataplatform/env_TEST.json',
        newmanArgs: '-d dataplatform/TestData_TEST.csv --ignore-redirects',
        projectWebhook: 'https://outlook.office.com/webhook/1fea210a-3574-411e-ae8e-5a8ae2ddb10c@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/4624e8e5c9354289b0c1860981633957/ec799f02-acc0-49cf-a50b-1962d70e5971'
)