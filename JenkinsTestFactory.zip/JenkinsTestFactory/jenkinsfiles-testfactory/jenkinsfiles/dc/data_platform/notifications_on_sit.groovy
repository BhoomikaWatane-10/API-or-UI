@Library('common-libraries') _
testPipelineGradle(
        product: 'data-platform',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'new-bank-data-platform-taf',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test -Ddev.url=https://eks-test.dp.lumsolutions.net/demo-ui/notification -Ddev.user.endpoint.url=https://ip-10-113-102-27.eu-central-1.compute.internal:9101/userDeviceEvents -Ddev.nifi.endpoint.url=s3://luminor-dataplatform-test/nifi-snapshots-qa/ --stacktrace',
        jdkVersion: 'jdk8',
        skipDocker: true,
        allureResultsPath: 'build/allure-results'
)