@Library('common-libraries') _
testPipelineNewman(
        product: 'data-platform',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'postman',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        newmanCollection: 'dataplatform/Transaction_daily_check/DP_Daily_Check_for_trx.json',
        newmanEnvironment: 'dataplatform/Transaction_daily_check/Env_STAGE.json',
        newmanArgs: '-d dataplatform/Transaction_daily_check/trx_daily_check_STAGE.csv --ignore-redirects --ssl-client-cert dataplatform/Transaction_daily_check/dp-stg-certificate.crt --ssl-client-key dataplatform/Transaction_daily_check/dp-stg-key -r allure --reporter-allure-export allure-results',
        projectWebhook: 'https://outlook.office.com/webhook/1fea210a-3574-411e-ae8e-5a8ae2ddb10c@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/267b88c459ce4582a792dd2486447125/ec799f02-acc0-49cf-a50b-1962d70e5971',
        sendEmailTo: 'vaidas.kavaliunas@luminorgroup.com, Simmo.Soonsein@luminorgroup.com, Jurijs.Jefimovs@luminorgroup.com, jaana.jegorova@luminorgroup.com',
        allureResultsPath: 'build/allure-results'
)