@Library('common-libraries') _
testPipelineGradle(
        product: 'data-platform',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'new-bank-data-platform-taf',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results'
)