@Library('common-libraries') _
testPipelineGradle(
        product: 'banklink',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'banklink',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test -Psuite=smoke -Dproject.environment.name=dev --stacktrace',
        envToCheckUrl: 'https://api.admin-ui.main.dev.lumsolutions.net',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        skipDocker: true,
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/778bf1fb0f6d4d29a25a01fcdea9bc01/b719bb76-e265-45f2-b311-a39155d60d8e'
)