@Library('common-libraries') _
testPipelineGradle(
        product: 'banklink',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'banklink',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test -Psuite=sanity --tests SanityTests.checkBlIntCust -Dproject.environment.name=test --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/9e9d727a8eb7455eba5cdeb80204e855/349a6a04-d01a-4a88-97b3-823a9c3189af',
        sendEmailTo: 'Mantas.Nugaras@consult.luminorgroup.com, Evaldas.Sudvajus@consult.luminorgroup.com'
)