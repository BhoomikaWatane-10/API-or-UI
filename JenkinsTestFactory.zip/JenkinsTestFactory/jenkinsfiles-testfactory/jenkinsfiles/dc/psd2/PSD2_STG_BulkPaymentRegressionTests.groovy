@Library('common-libraries') _
testPipelineGradle(
        product: 'psd2',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'psd2',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test -Psuite=BulkPayment_Regression -Dproject.country=ee -Dproject.environment.name=stage --stacktrace',
        envToCheckUrl: 'https://api.admin-ui.main.stg.lumsolutions.net/index.html#/ee/en/',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/9788d6a6a849499487e9bfdf1d431f02/b719bb76-e265-45f2-b311-a39155d60d8e',
        sendEmailTo: 'bhoomika.watne@consult.luminorgroup.com'
)