@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://tcr.staging.luminor.fcc-sironafcs.com/tcr/"
)