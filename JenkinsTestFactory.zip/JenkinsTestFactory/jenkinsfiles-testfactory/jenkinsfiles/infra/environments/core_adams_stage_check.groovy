@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://S1EE-PLATWEB1.dnb.lv:8770"
)