@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://ee.mig2.lumsolutions.net"
)