@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://login.stg.lumsolutions.net"
)