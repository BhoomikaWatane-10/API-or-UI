@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://api.admin-ui.main.tst.lumsolutions.net/ccc/ui/v1"
)