@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://sironembargo.staging.luminor.fcc-sironafcs.com/embargo/services/TransactionScoring03?wsdl"
)