@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://dnbuqltappp.dnbnord.net:8443/CRM"
)