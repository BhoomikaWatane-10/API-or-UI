@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://vt-alba-ee.dnb.lv:8010"
)