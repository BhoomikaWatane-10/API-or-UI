@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://tcr.dev.luminor.fcc-sironafcs.com/tcr/"
)