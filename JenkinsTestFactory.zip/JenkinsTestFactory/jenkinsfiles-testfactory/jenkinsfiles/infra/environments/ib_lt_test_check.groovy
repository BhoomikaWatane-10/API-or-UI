@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://uat-ib.dnb.lt"
)