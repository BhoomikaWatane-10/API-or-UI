@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://staging.luminor.fcc-sironafcs.com/axis2/services/KYCService01?wsdl"
)