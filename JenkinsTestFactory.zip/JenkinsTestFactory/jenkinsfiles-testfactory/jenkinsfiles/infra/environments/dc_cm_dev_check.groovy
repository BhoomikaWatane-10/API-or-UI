@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://api.dev.lumsolutions.net"
)