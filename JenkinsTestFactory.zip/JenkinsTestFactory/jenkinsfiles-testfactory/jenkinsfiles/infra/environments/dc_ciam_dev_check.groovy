@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://login.dev.lumsolutions.net"
)