@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://login.tst.lumsolutions.net"
)