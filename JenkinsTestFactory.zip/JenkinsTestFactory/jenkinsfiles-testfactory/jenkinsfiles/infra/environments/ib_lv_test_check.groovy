@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://test.vt-secure.dnb.lv/login/rid_login.php"
)