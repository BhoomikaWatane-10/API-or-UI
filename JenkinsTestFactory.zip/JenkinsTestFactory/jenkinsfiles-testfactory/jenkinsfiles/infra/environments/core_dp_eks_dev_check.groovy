@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://eks-dev.dp.lumsolutions.net/demo-ui/notification"
)