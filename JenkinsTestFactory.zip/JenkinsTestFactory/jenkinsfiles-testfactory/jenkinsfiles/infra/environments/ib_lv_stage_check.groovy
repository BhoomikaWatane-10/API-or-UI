@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://s1lv-secure.dnb.lv/login/rid_login.php"
)