@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://ee.stg.lumsolutions.net"
)