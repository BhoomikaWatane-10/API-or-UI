@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://ingress.dataplatform.dev.lumsolutions.net"
)