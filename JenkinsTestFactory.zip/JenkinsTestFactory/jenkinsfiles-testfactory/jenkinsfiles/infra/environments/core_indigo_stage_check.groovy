@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://s1ee-platweb1.dnb.lv:8000/login.html"
)