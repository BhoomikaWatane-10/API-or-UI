@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://pp-ib.dnb.lt"
)