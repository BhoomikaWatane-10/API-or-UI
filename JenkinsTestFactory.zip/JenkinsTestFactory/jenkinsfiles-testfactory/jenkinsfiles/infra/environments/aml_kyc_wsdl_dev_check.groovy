@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://dev.luminor.fcc-sironafcs.com/axis2/services/KYCService01?wsdl"
)