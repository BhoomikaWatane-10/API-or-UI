@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://dev.luminor.fcc-sironafcs.com/sironkyc"
)