@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://api.dev.lumsolutions.net/v1/openam/oauth2/access_token?realm=channels"
)