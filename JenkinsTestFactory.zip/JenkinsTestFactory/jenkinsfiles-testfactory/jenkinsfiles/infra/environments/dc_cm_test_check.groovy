@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://api.tst.lumsolutions.net"
)