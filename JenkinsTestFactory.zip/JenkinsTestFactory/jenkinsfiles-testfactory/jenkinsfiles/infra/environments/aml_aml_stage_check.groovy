@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://sironembargo.staging.luminor.fcc-sironafcs.com/sironaml"
)