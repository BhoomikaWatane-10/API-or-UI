@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://embargo.dev.luminor.fcc-sironafcs.com/sironembargo"
)