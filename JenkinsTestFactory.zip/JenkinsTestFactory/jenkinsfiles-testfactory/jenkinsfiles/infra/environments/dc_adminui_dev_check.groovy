@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://api.admin-ui.main.dev.lumsolutions.net/index.html"
)