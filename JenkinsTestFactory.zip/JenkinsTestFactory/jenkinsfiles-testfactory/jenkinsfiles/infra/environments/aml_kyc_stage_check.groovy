@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://staging.luminor.fcc-sironafcs.com/sironkyc"
)