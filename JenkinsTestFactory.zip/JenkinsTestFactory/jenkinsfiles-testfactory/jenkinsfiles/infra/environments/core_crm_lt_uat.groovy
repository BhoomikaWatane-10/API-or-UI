@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://dnbuqltapu01.dnbnord.net:8080/CRM"
)