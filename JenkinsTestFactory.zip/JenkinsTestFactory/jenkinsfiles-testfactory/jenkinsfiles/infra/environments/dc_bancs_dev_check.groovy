@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://ee.dev.lumsolutions.net"
)