@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://vt-crmapp.dnb.lv:7003/CRM"
)