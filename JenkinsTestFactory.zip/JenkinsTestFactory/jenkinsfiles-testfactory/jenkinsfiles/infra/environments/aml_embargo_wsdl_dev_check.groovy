@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://embargo.dev.luminor.fcc-sironafcs.com/embargo/LM03/services/TransactionScoring03?wsdl"
)