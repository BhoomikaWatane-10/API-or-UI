@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://ee.tst.lumsolutions.net"
)