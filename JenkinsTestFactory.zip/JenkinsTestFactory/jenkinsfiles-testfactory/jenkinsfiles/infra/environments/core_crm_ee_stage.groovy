@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "http://s1ee-crmapp3.dnb.lv:7777/CRM"
)