@Library('common-libraries') _
testPipelineCurlHealth(
        endpointUrl: "https://api.admin-ui.main.stg.lumsolutions.net/index.html"
)