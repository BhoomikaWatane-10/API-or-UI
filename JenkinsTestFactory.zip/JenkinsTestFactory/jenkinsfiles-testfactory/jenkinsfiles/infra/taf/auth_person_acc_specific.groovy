@Library('common-libraries') _
testPipelineGradle(
        product: 'taf',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'taf',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test -Psuite=auth --tests AuthTest.getSpecificAccountAsPrivate --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/600344473da843869f690d7f920bf29d/b719bb76-e265-45f2-b311-a39155d60d8e',
)