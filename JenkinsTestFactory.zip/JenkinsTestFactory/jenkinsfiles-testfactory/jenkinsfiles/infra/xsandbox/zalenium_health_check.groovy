pipeline {
    agent {
        kubernetes {
            label 'jenkinsbuilder'
            defaultContainer 'jnlp'
            yaml """
apiVersion: v1
kind: Pod
metadata:
  labels:
    product: jenkins
    env: build
spec:
  affinity:
    nodeAffinity:
      preferredDuringSchedulingIgnoredDuringExecution:
        - weight: 1
          preference:
            matchExpressions:
              - key: kubernetes.io/lifecycle
                operator: In
                values:
                  - "spot"
  containers:
  - name: curl
    image: artifactory.onelum.host/local-docker-repo/curl:latest
    command: ['cat']
    tty: true
    resources:
      requests:
        memory: 256Mi
        cpu: 0.2
      limits:
        memory: 512Mi
        cpu: 0.5
  imagePullSecrets:
  - name: luminor-registry

"""
        }
    }

    stages {
        stage('health check') {
            steps {
                container('curl') {
                    script {
                        try {
                            sh """
                                    set +x; url='http://test_zalenium:prlsjnfaj727alsndasd@zalenium.zalenium.svc.cluster.local/wd/hub/status'
                                    set +x; attempts=2; 
                                    set +x; timeout=10;
                                    set +x; online=false
                                    
                                    set +x; printf '%s\\n' "*** *** ***"
                                    set +x; printf '%s\\n' "Checking Zalenium access at \$url"
                                    i=1; while [ "\$i" -le "\$attempts" ];
                                    do
                                        set +x; printf '%s\\n' " - attempt #: \$i"
                                        code=`curl -sSL --connect-timeout 10 --max-time 30 -w "%{http_code}" "\$url" -o /dev/null`
                                        set +x; printf '%s\\n' " - response code: \$code" 
                                        
                                        if [ \$code -eq 200 ]; then
                                            set +x; printf '%s\\n' " - Zalenium is accesible."
                                            set +x; online=true
                                            break
                                        else
                                            set +x; printf '%s\\n' " - Zalenium \$url is NOT accesible. Waiting for \$timeout seconds."
                                            set +x; sleep "\$timeout"
                                        fi
                                        
                                        i="\$((i+1))";
                                    done
                                    
                                    if "\$online"; then
                                      set +x; printf '%s\\n' "Monitor success."
                                      set +x; exit 0
                                    else
                                      set +x; exit 1
                                    fi
                                """
                        } catch (Exception e) {
                            sh """
                                    set +x; printf '%s\\n' "Monitor failed. Seems Zalenium is out of reach."
                                    set +x; exit 1
                                """
                        }
                    }
                }
            }

        }
    }
}