pipeline {
    agent {
        kubernetes {
            label 'jenkinsbuilder'
            defaultContainer 'jnlp'
            yaml """
apiVersion: v1
kind: Pod
metadata:
  labels:
    product: jenkins
    env: build
spec:
  affinity:
    nodeAffinity:
      preferredDuringSchedulingIgnoredDuringExecution:
        - weight: 1
          preference:
            matchExpressions:
              - key: kubernetes.io/lifecycle
                operator: In
                values:
                  - "spot"
  containers:
  - name: curl
    image: artifactory.onelum.host/local-docker-repo/curl:latest
    command: ['cat']
    tty: true
    resources:
      requests:
        memory: 256Mi
        cpu: 0.2
      limits:
        memory: 512Mi
        cpu: 0.5
  imagePullSecrets:
  - name: luminor-registry

"""
        }
    }
    environment {
        REGISTRY_URL = "artifactory.onelum.host"
        ARTIFACTORY_CREDENTIALS = "luminor-artifactory"
        TTT = credentials('jenkins-ccc-stg-key')
    }

    stages {
        stage('test') {
            steps {
                container('jfrog-cli') {
                    script {
                        withCredentials([usernamePassword(credentialsId: ARTIFACTORY_CREDENTIALS, passwordVariable: 'ARTIFACTORY_PASSWORD', usernameVariable: 'ARTIFACTORY_USERNAME')]) {
                            println "artifactory username ${ARTIFACTORY_USERNAME}"
                            println "artifactory pswd ${ARTIFACTORY_PASSWORD}"
                        }
                        if (TTT != null) {
                            println "******** TOKEN: ${TTT} ************"
                        } else {
                            println "no token provided"
                        }
                    }
                }
            }
        }
    }
}
