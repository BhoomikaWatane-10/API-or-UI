pipeline {
    agent {
        kubernetes {
            label 'jenkinsbuilder'
            defaultContainer 'jnlp'
            yaml """
apiVersion: v1
kind: Pod
metadata:
  labels:
    product: jenkins
    env: build
spec:
  affinity:
    nodeAffinity:
      preferredDuringSchedulingIgnoredDuringExecution:
        - weight: 1
          preference:
            matchExpressions:
              - key: kubernetes.io/lifecycle
                operator: In
                values:
                  - "spot"
  containers:
  - name: curl
    image: artifactory.onelum.host/local-docker-repo/curl:latest
    command: ['cat']
    tty: true
    resources:
      requests:
        memory: 256Mi
        cpu: 0.2
      limits:
        memory: 512Mi
        cpu: 0.5
  imagePullSecrets:
  - name: luminor-registry

"""
        }
    }
    environment {
        HEALTH_URL = "https://admin.bridge.test.lumsolutions.net/lb_health_check_status"
    }

    stages {
        stage('health check') {
            steps {
                container('curl') {
                    script {
                        sh """
                        curl ${HEALTH_URL} -k -s -o /dev/null -w '> response_code: %{http_code}
                          > dns_time: %{time_namelookup}
                          > connect_time: %{time_connect}
                          > pretransfer_time: %{time_pretransfer}
                          > starttransfer_time: %{time_starttransfer}
                          > total_time: %{time_total}'
                        """
                        def status = sh returnStdout: true,
                                script: """
                                        curl -s -o /dev/null -w '%{http_code}' ${HEALTH_URL}
                                        """

                        if (!status.equals(200)) {
                            error("Environment health check: ERROR - expected response code '200' but the actual was '${status}'")
                        }
                    }
                }
            }

        }
    }
    post {
        always {
            office365ConnectorSend webhookUrl: "https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/db8b1985b76f404faec30f2ef756ca91/b719bb76-e265-45f2-b311-a39155d60d8e"
        }
    }
}


