@Library('common-libraries') _
testPipelineGradle(
        product: 'ccc',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'ccc',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'vaidas/proxy',
        gradleCommand: 'clean test -Psuite=web --tests ProxyTest --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results'
)