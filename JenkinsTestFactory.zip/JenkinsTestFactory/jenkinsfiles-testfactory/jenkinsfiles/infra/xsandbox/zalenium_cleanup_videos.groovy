pipeline {
    agent {
        kubernetes {
            label 'jenkinsbuilder'
            defaultContainer 'jnlp'
            yaml """
apiVersion: v1
kind: Pod
metadata:
  labels:
    product: jenkins
    env: build
spec:
  affinity:
    nodeAffinity:
      preferredDuringSchedulingIgnoredDuringExecution:
        - weight: 1
          preference:
            matchExpressions:
              - key: kubernetes.io/lifecycle
                operator: In
                values:
                  - "spot"
  containers:
  - name: curl
    image: artifactory.onelum.host/local-docker-repo/curl:latest
    command: ['cat']
    tty: true
    resources:
      requests:
        memory: 256Mi
        cpu: 0.2
      limits:
        memory: 512Mi
        cpu: 0.5
  imagePullSecrets:
  - name: luminor-registry

"""
        }
    }

    stages {
        stage('health check') {
            steps {
                container('curl') {
                    script {
                        try {
                            sh """
                                    set +x; url='http://zalenium.test-factory.onelum.host/dashboard/cleanup?action=doCleanup'
                                    set +x; auth='test_zalenium:prlsjnfaj727alsndasd'
                                    set +x; printf '%s\\n' "Attempting to cleanup videos in Zalenium that are older than 3 days"
                                    code=`curl -sSL --connect-timeout 30 --max-time 60 -w "%{http_code}" --user "\$auth" "\$url" -o /dev/null`
                                    
                                    if [ \$code -eq 200 ]; then
                                      set +x; printf '%s\\n' "Cleanup successful."
                                      set +x; exit 0
                                    else
                                      set +x; exit 1
                                    fi
                                """
                        } catch (Exception e) {
                            sh """
                                    set +x; printf '%s\\n' "Zalenium video cleanup failed. Error code: '\$code'"
                                    set +x; exit 1
                                """
                        }
                    }
                }
            }

        }
    }
}