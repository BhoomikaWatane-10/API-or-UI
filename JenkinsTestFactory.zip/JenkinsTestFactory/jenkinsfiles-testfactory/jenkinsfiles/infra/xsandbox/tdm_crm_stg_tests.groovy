@Library('common-libraries') _
testPipelineNewman(
        product: 'crm',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'postman',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        //testRunCommand: 'node', //TODO: if uncommented - runs collections from js file below
        //newmanCollection: 'testdata/CRM/EE/Staging/createPrivateCustomerStaging.js',
        newmanCollection: 'testdata/CRM/EE/Staging/EE_Staging_CRM-Create_private_customer_with_accounts.json',
        newmanEnvironment: 'testdata/CRM/EE/Staging/Staging_EE_Environment.json',
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/79ffcd6ec3874672b9f9c5f683f34bed/b719bb76-e265-45f2-b311-a39155d60d8e'
)