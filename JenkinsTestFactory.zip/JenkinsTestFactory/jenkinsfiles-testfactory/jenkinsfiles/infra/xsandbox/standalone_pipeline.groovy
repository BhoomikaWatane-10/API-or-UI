pipeline {
    agent {
        kubernetes {
            label 'jenkinsbuilder'
            defaultContainer 'jnlp'
            yaml """
apiVersion: "v1"
kind: "Pod"
metadata:
  labels:
    product: "jenkins"
    env: "build"
    jenkins: "slave"
    jenkins/label: "jfrog-cli-jdk8"
spec:
  containers:
  - command:
    - "cat"
    image: "artifactory.onelum.host/lds-docker-virtual/curl:latest"
    name: "curl"
    resources:
      limits:
        memory: "512Mi"
        cpu: "0.5"
      requests:
        memory: "256Mi"
        cpu: "0.2"
    tty: true
    volumeMounts:
    - mountPath: "/home/jenkins/agent"
      name: "workspace-volume"
      readOnly: false
  - command:
    - "cat"
    env:
    - name: "TESTCONTAINERS_RYUK_DISABLED"
      value: "true"
    image: "artifactory.onelum.host/lds-docker-virtual/luminor-jfrog-cli-jdk8:latest"
    name: "jfrog-cli"
    resources:
      limits:
        memory: "8096Mi"
        cpu: "4.0"
      requests:
        memory: "2048Mi"
        cpu: "1.0"
    tty: true
    volumeMounts:
    - mountPath: "/var/run/docker.sock"
      name: "docker-sock"
    - mountPath: "/home/jenkins/agent"
      name: "workspace-volume"
      readOnly: false
  - command:
    - "cat"
    image: "artifactory.onelum.host/public-docker-virtual/docker"
    name: "docker"
    resources:
      limits:
        memory: "2048Mi"
        cpu: "2.0"
      requests:
        memory: "64Mi"
        cpu: "0.2"
    tty: true
    volumeMounts:
    - mountPath: "/var/run/docker.sock"
      name: "docker-sock"
    - mountPath: "/home/jenkins/agent"
      name: "workspace-volume"
      readOnly: false
  - env:
    - name: "JENKINS_SECRET"
      value: "********"
    - name: "JENKINS_TUNNEL"
      value: "jenkins-agent.jenkins:50000"
    - name: "JENKINS_AGENT_NAME"
      value: "jfrog-cli-jdk8-jwcb9-3ts7t"
    - name: "JENKINS_NAME"
      value: "jfrog-cli-jdk8-jwcb9-3ts7t"
    - name: "JENKINS_AGENT_WORKDIR"
      value: "/home/jenkins/agent"
    - name: "JENKINS_URL"
      value: "http://jenkins.jenkins:8080/"
    image: "jenkins/jnlp-slave:4.0.1-1"
    name: "jnlp"
    resources:
      requests:
        cpu: "100m"
        memory: "256Mi"
    volumeMounts:
    - mountPath: "/home/jenkins/agent"
      name: "workspace-volume"
      readOnly: false
  imagePullSecrets:
  - name: "luminor-registry"
  nodeSelector:
    kubernetes.io/lifecycle: "spot"
  restartPolicy: "Never"
  securityContext: {}
  tolerations:
  - effect: "NoSchedule"
    key: "role"
    operator: "Equal"
    value: "builder-node"
  volumes:
  - hostPath:
      path: "/var/run/docker.sock"
    name: "docker-sock"
  - emptyDir:
      medium: ""
    name: "workspace-volume"
"""
        }
    }

    environment {
        GITREPO = "ccc"
        REGISTRY_URL = "artifactory.onelum.host"
        ARTIFACTORY_CREDENTIALS = "luminor-artifactory"
        ZALENIUM_HUB = "http://zalenium.zalenium.svc.cluster.local/wd/hub/status"
        JENKINS_SYS_PSWD_KEY = credentials('${jenkins-ccc-stg-key}')
    }

    stages {
        stage('prepare') {
            steps {
                script {
                    env.GRADLE_BUILD_PATH = "build.gradle"
                    env.GRADLE_COMMAND = "clean test -Psuite=sanity -Dproject.environment.name=stage"
                    env.GITURL = "git.onelum.host/lumta"
                    env.GITCREDS = "gitlab-credentials"
                    env.PREINSTALL_CMD = "chmod +x ./gradlew"
                }
            }
        }

        stage('select branch') {
            steps {
                script {
                    println "using pre-defined branch ${args.predefinedBranch}"
                    env.GITBRANCH = "${args.predefinedBranch}"
                }
            }
        }
        stage('checkout') {
            steps {
                script {
                    new RepositoryHelper(this).scmCheckout(GITURL, GITREPO, GITCREDS, GITBRANCH)
                    if (env.TEAM == "unknown") {
                        error("cannot identify team from repo url. contact devops")
                    } else {
                        env.DOCKER_REPOSITORY = "${env.TEAM}-docker-virtual"
                        println "Using docker repository: ${DOCKER_REPOSITORY}"
                    }
                }
            }
        }

        stage('pre-install') {
            when {
                expression { args.preInstallCmd != null }
            }
            steps {
                script {
                    sh """
                           ${PREINSTALL_CMD}
                           """
                }
            }
        }

        stage('test') {
            steps {
                container('jfrog-cli') {
                    script {
                        withCredentials([usernamePassword(credentialsId: ARTIFACTORY_CREDENTIALS, passwordVariable: 'ARTIFACTORY_PASSWORD', usernameVariable: 'ARTIFACTORY_USERNAME')]) {
                            dir(args.buildSubDirectory != null ? args.buildSubDirectory : pwd()) {
                                sh """
                                       init-artifactory https://artifactory.onelum.host/artifactory ${ARTIFACTORY_USERNAME} ${ARTIFACTORY_PASSWORD} ${TEAM}
                                       """

                                withCredentials([string('credentialsId': 'jenkins-remote-tests-trigger', variable: 'TOKEN')]) {
                                    println "*** token is ${TOKEN}"
                                }
                                if (JENKINS_SYS_PSWD_KEY != null) {
                                    println "Using secure key - it should be masked ${JENKINS_SYS_PSWD_KEY}"
                                    sh """
                                               jfrog rt gradle "${GRADLE_COMMAND} -b ${GRADLE_BUILD_PATH} -Dselenide.remote=${ZALENIUM_HUB} -Dstage.key='${JENKINS_SYS_PSWD_KEY}' -Pbuild_environment=jenkins" /home/node/gradle-config.yml --build-name=${BLD_NAME} --build-number=${BLD_NUMBER}
                                               """
                                } else {
                                    println "Using project default user"
                                    sh """
                                           jfrog rt gradle "${GRADLE_COMMAND} -b ${GRADLE_BUILD_PATH} -Dselenide.remote=${ZALENIUM_HUB} -Pbuild_environment=jenkins" /home/node/gradle-config.yml --build-name=${BLD_NAME} --build-number=${BLD_NUMBER}
                                           """
                                }

                                sh """
                                       jfrog rt bp ${BLD_NAME} ${BLD_NUMBER}
                                       """
                            }
                        }
                    }
                }
            }
            post {
                always {
                    script {
                        if (args.allureResultsPath != null) {
                            def allureResults
                            if (args.allureResultsPath instanceof String) {
                                allureResults = [[path: args.allureResultsPath]]
                            } else if (args.allureResultsPath instanceof Collection) {
                                allureResults = args.allureResultsPath.collect { allurePath -> [path: allurePath] }
                            }
                            if (allureResults != null) {
                                allure includeProperties: false, jdk: '', results: allureResults
                            }
                        }
                    }
                }
            }
        }
    }
}