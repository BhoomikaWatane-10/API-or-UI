@Library('common-libraries') _
testPerftestRedline13jmeter(
        product: 'tc24',
        gitUrl: 'git.onelum.host/lumpt',
        gitRepo: 'ee-e2e',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        jmeterMasterFile: 'scripts/TC24.jmx',
        jdkVersion: 'jdk11',
)

