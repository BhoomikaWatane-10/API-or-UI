@Library('common-libraries') _
testPipelineGradleOnprem(
        product: 'crm',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'crm',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'ee-tst',
        gradleCommand: 'clean test -Psuite=smoke -Dproject.environment.name=stage -Dproject.country=ee --stacktrace',
        envToCheckUrl: 'http://s1ee-crmapp3.dnb.lv:7777/CRM',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: '',
        sendEmailTo: ''
)