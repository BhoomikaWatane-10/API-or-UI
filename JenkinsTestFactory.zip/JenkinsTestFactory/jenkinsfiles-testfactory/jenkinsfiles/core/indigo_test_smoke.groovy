@Library('common-libraries') _
testPipelineGradleOnprem(
        product: 'indigo',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'indigo',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'ee-tst',
        gradleCommand: 'clean test -Psuite=smoke -Dproject.environment.name=test -Dproject.country=ee --stacktrace',
        envToCheckUrl: 'http://s1ee-platweb1.dnb.lv:8000',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: '',
        sendEmailTo: ''
)