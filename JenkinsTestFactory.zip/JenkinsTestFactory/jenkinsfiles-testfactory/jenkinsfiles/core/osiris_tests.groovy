@Library('common-libraries') _
testPipelineGradle(
        product: 'osiris',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'osiris',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results'
)