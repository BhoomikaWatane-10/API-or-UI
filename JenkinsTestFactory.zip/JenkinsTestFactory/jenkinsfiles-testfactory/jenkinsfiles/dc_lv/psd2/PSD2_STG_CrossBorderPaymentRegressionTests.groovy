@Library('common-libraries') _
testPipelineGradle(
        product: 'psd2',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'psd2',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: 'clean test -Psuite=CrossBorderPayment_Regression -Dproject.country=lv -Dproject.environment.name=stage --stacktrace',
        envToCheckUrl: 'https://api.admin-ui.main.stg.lumsolutions.net/index.html#/ee/en/',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        sendEmailTo: 'bhoomika.watne@consult.luminorgroup.com'
)