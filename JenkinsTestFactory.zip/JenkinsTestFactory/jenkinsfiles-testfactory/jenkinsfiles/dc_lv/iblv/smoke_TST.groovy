@Library('common-libraries') _
testPipelineGradleOnprem(
        product: 'dclv',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'digital_channels_LV',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'ee-tst',
        gradleCommand: 'clean test -Dproject.environment.name=test -Psuite=smoke --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/cf55fba1e0144d6b90439f4ef7ec2ca5/b719bb76-e265-45f2-b311-a39155d60d8e'
)