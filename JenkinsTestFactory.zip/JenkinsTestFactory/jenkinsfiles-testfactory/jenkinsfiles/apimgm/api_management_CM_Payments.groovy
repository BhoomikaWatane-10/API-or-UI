@Library('common-libraries') _
testPipelineJest(
        product: 'nbp-api-management CM Payments',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'nbp-api-management',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'ee-tst',
        //preInstallCmd: 'npm install --save-dev cross-env',
        testRunCommand: 'npm run test:all:ci cm_payments_tests',
        allureResultsPath: 'allure-results',
        sendEmailTo: 'Aleksandrs.Kodolovs@consult.luminorgroup.com',
        projectWebhook: 'https://outlook.office.com/webhook/0d31ab99-a768-4f41-bd51-beb08015f9cc@5bdfb231-1958-42c0-8a9b-0cda186703b2/IncomingWebhook/3504a42b6604496f843b9efb6ef0569a/ae2ddac9-f5d2-46d4-895b-6de09bca47ec'
)