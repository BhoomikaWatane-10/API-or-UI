@Library('common-libraries') _
testPipelineGradleOnprem(
        product: 'fms',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'fms',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        nodeLabel: 'ee-tst',
        gradleCommand: 'clean test -Psuite=healthChecks -Dproject.environment.name=dev --stacktrace',
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results',
        projectWebhook: 'https://outlook.office.com/webhook/a3028417-4236-4fd9-bbc3-c7dd0dac26c2@5bdfb231-1958-42c0-8a9b-0cda186703b2/JenkinsCI/db8b1985b76f404faec30f2ef756ca91/b719bb76-e265-45f2-b311-a39155d60d8e'
)