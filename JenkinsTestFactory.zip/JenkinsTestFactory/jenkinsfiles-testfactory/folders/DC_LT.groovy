// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('DC_LT') {
    displayName('LT Digital Channels')
    description('LT Digital Channels systems')
}
