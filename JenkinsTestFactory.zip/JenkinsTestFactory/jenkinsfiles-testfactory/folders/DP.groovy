// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('DP') {
    displayName('EE Data Platform')
    description('EE Data Platform related automated tests')
}
