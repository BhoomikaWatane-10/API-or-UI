// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('CORELT') {
    displayName('LT CORE')
    description('LT CORE systems')
}
