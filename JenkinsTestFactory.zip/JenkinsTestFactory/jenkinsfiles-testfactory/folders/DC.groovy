// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('DC') {
    displayName('EE Digital Channels')
    description('EE Digital Channels systems')
}
