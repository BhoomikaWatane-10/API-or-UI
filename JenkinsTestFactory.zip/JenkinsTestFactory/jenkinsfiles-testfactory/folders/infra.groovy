// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('infra') {
    displayName('infra')
    description('Infrastructure')
}
folder('infra/TAF') {
    displayName('TAF')
    description('Luminor Test Automation Framework')
}
folder('infra/ENV') {
    displayName('env')
    description('Environments access monitoring')
}
folder('infra/xsandbox') {
    displayName('x.sandbox')
    description('Playground project')
}