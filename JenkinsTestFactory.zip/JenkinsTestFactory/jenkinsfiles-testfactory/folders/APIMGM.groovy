// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('APIMGM') {
    displayName('EE API')
    description('New Bank API MANAGEMENT')
}
