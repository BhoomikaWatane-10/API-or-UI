folder('BaNCS_prod') {
    displayName('EE BaNCS Prod')
    description('')
}