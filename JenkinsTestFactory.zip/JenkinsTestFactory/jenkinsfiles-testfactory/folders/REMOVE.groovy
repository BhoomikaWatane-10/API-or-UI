// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('CORELV/REMOVE') {
    displayName('Removed')
    description('Jobs that will be removed')
}
