// https://jenkinsci.github.io/job-dsl-plugin/#path/folder
folder('BaNCS') {
    displayName('EE BaNCS')
    description('')
}
folder('BaNCS/stg') {
    displayName('STG regression areas')
    description('EE BaNCS regression tests for staging environment')
}
folder('BaNCS/tst') {
    displayName('TST regression areas')
    description('EE BaNCS regression tests for test environment')
}
folder('BaNCS/R15') {
    displayName('R15 regression')
    description('EE BaNCS regression tests for release R1.5')
}
