// https://jenkinsci.github.io/job-dsl-plugin/#path/folder
folder('BaNCS_sanity') {
    displayName('EE BaNCS sanity')
    description('EE BaNCS sanity tests to check deployments')
}
