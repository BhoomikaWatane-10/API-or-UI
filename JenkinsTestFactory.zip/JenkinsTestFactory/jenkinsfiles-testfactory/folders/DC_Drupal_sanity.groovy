// https://jenkinsci.github.io/job-dsl-plugin/#path/folder
folder('Drupal_sanity') {
    displayName('EE Drupal sanity')
    description('EE Drupal sanity tests to check deployments')
}
