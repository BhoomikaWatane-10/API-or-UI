// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('AMLSUITE') {
    displayName('EE AML SUITE')
    description('AML SUITE systems')
}
