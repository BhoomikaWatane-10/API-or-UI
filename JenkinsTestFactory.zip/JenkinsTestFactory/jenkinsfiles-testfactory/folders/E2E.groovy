// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('E2E') {
    displayName('EE E2E')
    description('EE E2E stage tests')
}
