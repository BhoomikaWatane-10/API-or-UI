// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('CORELV') {
    displayName('LV CORE')
    description('LV CORE systems')
}
