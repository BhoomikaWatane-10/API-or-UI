// https://jenkinsci.github.io/job-dsl-plugin/#path/folder
folder('Banklink_sanity') {
    displayName('EE Banklink sanity')
    description('EE Banklink sanity tests to check deployments')
}
