// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('CORE') {
    displayName('EE CORE')
    description('EE CORE systems')
}
