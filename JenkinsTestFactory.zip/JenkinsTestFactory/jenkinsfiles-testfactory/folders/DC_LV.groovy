// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('DC_LV') {
    displayName('LV Digital Channels')
    description('LV Digital Channels systems')
}
