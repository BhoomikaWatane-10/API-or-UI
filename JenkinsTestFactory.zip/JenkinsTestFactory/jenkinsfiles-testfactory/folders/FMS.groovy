// https://jenkinsci.github.io/job-dsl-plugin/#path/folder

folder('FMS') {
    displayName('FMS')
    description('FMS SYSTEM')
}
