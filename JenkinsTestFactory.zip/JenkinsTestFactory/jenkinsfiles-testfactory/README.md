# Repository for test automation Jenkins jobs
Jenkins is part of AWS-Shared-services and is managed as code.

### HOUSE RULES
Some basic house rules:
- "We don't block deploys/apply, but merges". We want to scale operations, not be as roadblock After merge to master, there is automated apply job
- If there is change, create Merge Request and set reviewer to one of the test automation team members: Vaidas, Simmo, Merle etc
- If all good, we will do merge, if not we wil ask you questions
- Improvements/proposals always welcome, but remember KISS always over DRY. And always example code is better than conversation "we should do this or that"


### Configuration contains:
- folders
- views
- pipelines (jenkins files + jobs)

In order to persist pipelines in case of Jenkins failure, they have to be commited into this repository where they will be picked up by seed job.
The `seed job` is a piece of configuration capable to import folders, views and pipelines properly described in this repo.


### Persisting folder
- Configuration file with folder definition has to be pushed in `folders` directory.
- Configuration file has to be with `.groovy` extension.
- Manual can be found here: https://jenkinsci.github.io/job-dsl-plugin/#path/folder
- Example:
```
folder('NBREID') {
    displayName('Project NBREID')
    description('Folder for project NBREID')
  }
```

### Persisting view
- Configuration file with view definition has to be pushed in `views` directory.
- Configuration file has to be with `.groovy` extension.
- Manual can be found here: https://jenkinsci.github.io/job-dsl-plugin/#path/listView
- Example:
```
buildMonitorView('AMLSUITE') {
    description('All AML related automated tests')
    recurse(true)
    jobs {
        regex('AMLSUITE/.*')
    }
}
```

### Persisting pipeline
Part 1. Jenkins file
- Configuration file with jenkinsfile definition has to be pushed in `jenkinsfiles` directory.
- Configuration file has to be with `.groovy` extension.
- Concept: call pipeline template with parameters of your choice. Shared libs repo - https://git.onelum.host/lds/jenkins/tree/master/vars
- At the moment, there are 3 pipeline templates to use:
-- testPipelineGradle
-- testPipelineNewman
-- testPipelineCurlHealth
- Example:
```
@Library('common-libraries') _
testPipelineGradle(
        product: 'aml-suite',
        gitUrl: 'git.onelum.host/lumta',
        gitRepo: 'new-bank-aml-suite-migration',
        gitCreds: 'gitlab-credentials',
        predefinedBranch: 'master',
        gradleCommand: "cleanTest test -Psuite=acmRegression -Dselenide.browser=chrome --stacktrace",
        jdkVersion: 'jdk8',
        allureResultsPath: 'build/allure-results'
)
```
Part 2. Job
- Configuration file with job definition has to be pushed in `jobs` directory.
- Configuration file has to be with `.groovy` extension.
- Manual can be found here: https://jenkinsci.github.io/job-dsl-plugin/#path/pipelineJob
- Example:
```
pipelineJob('AMLSUITE/acm_regression_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials(credentialsId)
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/acm_regression_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
```

### Importing configuration into Jenkins
- Find Seed job in Jenkins UI
- Click Build now
- Enjoy