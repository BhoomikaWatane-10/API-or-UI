//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('BANKLINK') {
    description('All Banklink specific jobs')
    recurse(true)
    jobs {
        regex('DC/Banklink.*Tests')
    }
}