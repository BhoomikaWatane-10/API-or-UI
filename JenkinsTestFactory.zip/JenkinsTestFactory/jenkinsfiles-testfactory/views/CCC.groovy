//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('CCC') {
    description('All CCC specific jobs')
    recurse(true)
    jobs {
        regex('ENV/CCC.*health|DC/CCC.*Tests')
    }
}