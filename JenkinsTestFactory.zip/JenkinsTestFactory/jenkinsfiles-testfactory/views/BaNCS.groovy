//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('BaNCS') {
    description('All BaNCS specific tests')
    recurse(true)
    jobs {
        regex('BaNCS/*.*|BaNCS_comp/*.*')
    }
}