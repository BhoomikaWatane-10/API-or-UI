//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('ENV E2E') {
    description('All E2E environments access monitoring checks')
    recurse(true)
    jobs {
        regex('infra/ENV/(?!.*(ib_lt|ib_lv)).*(stage|stg|STG|STAGE).*')
    }
}