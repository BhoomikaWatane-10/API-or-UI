//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('ENV DC') {
    description('All environments access monitoring checks')
    recurse(true)
    jobs {
        regex('infra/ENV/dc.*')
    }
}