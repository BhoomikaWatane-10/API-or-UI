//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('PSD2') {
    description('All PSD2 specific jobs')
    recurse(true)
    jobs {
        regex('DC/PSD2_.*Tests')
    }
}