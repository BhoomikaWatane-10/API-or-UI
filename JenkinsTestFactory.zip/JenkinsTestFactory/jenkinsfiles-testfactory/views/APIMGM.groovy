//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('APIMGM') {
    description('All API Management related tests')
    recurse(true)
    jobs {
        regex('APIMGM/*.*')
    }
}