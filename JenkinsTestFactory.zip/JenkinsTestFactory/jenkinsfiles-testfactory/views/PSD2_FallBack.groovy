//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('PSD2_FallBack') {
    description('All PSD2 FallBack specific jobs')
    recurse(true)
    jobs {
        regex('DC/PSD2FallBack.*Tests')
    }
}