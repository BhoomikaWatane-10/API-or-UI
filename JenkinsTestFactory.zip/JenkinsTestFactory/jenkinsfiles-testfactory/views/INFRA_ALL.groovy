//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('ENV ALL') {
    description('All DC environments access monitoring checks')
    recurse(true)
    jobs {
        regex('infra/ENV/(?!.*(ib_lt|ib_lv)).*')
    }
}