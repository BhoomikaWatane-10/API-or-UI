//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('AML') {
    description('All AML related automated tests')
    recurse(true)
    jobs {
        regex('AMLSUITE/.*')
    }
}