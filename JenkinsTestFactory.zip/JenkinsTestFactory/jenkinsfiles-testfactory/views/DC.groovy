//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('DC') {
    description('All DC automated tests')
    recurse(true)
    jobs {
        regex('DC/.*')
    }
}