//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('CORELV') {
    description('Core LV/EE regression jobs')
    recurse(true)
    jobs {
        regex('CORELV/.*indigo|CORELV/.*osiris')
    }
}