//https://jenkinsci.github.io/job-dsl-plugin/#path/buildMonitorView

buildMonitorView('CORE') {
    description('All CORE automated tests')
    recurse(true)
    jobs {
        regex('CORE/.*')

    }
}