def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def scheduleSmoke = 'H 6-16 * * 1-5'

pipelineJob('DC_LV/PSD2_STG_smokeTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_STG_smokeTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('DC_LV/PSD2_TST_smokeTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_TST_smokeTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('DC_LV/PSD2_TST_smokeTests_TEST') {
    definition {
        cpsScm {            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_TST_smokeTests_TEST.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('DC_LV/PSD2_STG_RegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_STG_RegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleSmoke)
                    }
                }
            }
        }
    }
}

pipelineJob('DC_LV/PSD2_TST_RegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_TST_RegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                  //  triggers {
                      //  cron(scheduleSmoke)
                  //  }
                }
            }
        }
    }
}

pipelineJob('DC_LV/PSD2_TST_PeriodicPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_TST_PeriodicPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                   // triggers {
                     //   cron(scheduleSmoke)
                  //  }
                }
            }
        }
    }
}

pipelineJob('DC_LV/PSD2_STG_PeriodicPaymentRegressionTest') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_STG_PeriodicPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                  //  triggers {
                      //  cron(scheduleSmoke)
                  //  }
                }
            }
        }
    }
}

pipelineJob('DC_LV/PSD2_TST_BulkPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_TST_BulkPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    // triggers {
                    //   cron(scheduleSmoke)
                    //  }
                }
            }
        }
    }
}

pipelineJob('DC_LV/PSD2_STG_BulkPaymentRegressionTest') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_STG_BulkPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    //  triggers {
                    //  cron(scheduleSmoke)
                    //  }
                }
            }
        }
    }
}


pipelineJob('DC_LV/PSD2_TST_CrossBorderPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_TST_CrossBorderPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    // triggers {
                    //   cron(scheduleSmoke)
                    //  }
                }
            }
        }
    }
}

pipelineJob('DC_LV/PSD2_STG_CrossBorderPaymentRegressionTest') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lv/psd2/PSD2_STG_CrossBorderPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    //  triggers {
                    //  cron(scheduleSmoke)
                    //  }
                }
            }
        }
    }
}