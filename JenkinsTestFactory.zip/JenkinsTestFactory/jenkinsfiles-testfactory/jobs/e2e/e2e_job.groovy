pipelineJob('e2e/e2e_full') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/e2e/e2e_full.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('e2e/e2e_urls_check') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/e2e/e2e_urls_check.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
    pipelineJob('e2e/e2e_specific_tests') {
        configure { project ->
            project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                            credentials('gitlab-credentials')
                        }
                        branches('master')
                        scriptPath('jenkinsfiles/e2e/e2e_specific_tests.groovy')
                        extensions {}
                        // required as otherwise it may try to tag the repo, which you may not want
                    }
                }
            }
        }
    }
}
