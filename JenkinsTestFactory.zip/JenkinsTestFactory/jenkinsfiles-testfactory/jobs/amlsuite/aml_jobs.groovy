def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def smokeSchedule = '0 22 * * *'
def dailySchedule = '0 6 * * 1-5'
def everyMondaySchedule = '0 7 * * 1'

pipelineJob('AMLSUITE/rerun_failed_tests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/rerun_failed.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
    parameters {
        stringParam('rerunJob', 'AMLSUITE/acm_regression_stage_chrome', 'Enter exact full job name to rerun failed tests for')
        stringParam('rerunBuild', 'lastCompletedBuild', 'Enter exact completed job build number or leave intact for the latest')
        stringParam('suiteName', 'smoke', 'Enter exact suite name without xml extension')
        stringParam('browser', 'chrome', 'Enter exact browser name in lowercase')
        stringParam('envName', 'stage', 'Enter environment name dev/test/stage')
        stringParam('envUrl', 'https://staging.luminor.fcc-sironafcs.com/acm', 'Enter environment url for health check')
    }
}

pipelineJob('AMLSUITE/acm_regression_stage_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/acm_regression_stage_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(everyMondaySchedule)
        }
    }
}

pipelineJob('AMLSUITE/aml_regression_stage_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/aml_regression_stage_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
            triggers {
                cron(everyMondaySchedule)
            }
        }
    }
}

pipelineJob('AMLSUITE/embargo_full_regression_stage_chrome_part1') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/embargo_full_regression_stage_chrome_part1.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('AMLSUITE/embargo_full_regression_stage_chrome_part2') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/embargo_full_regression_stage_chrome_part2.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('AMLSUITE/embargo_full_regression_dev_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/embargo_full_regression_dev_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('AMLSUITE/embargo_daily_regression_stage_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/embargo_daily_regression_stage_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
            triggers {
                cron(dailySchedule)
            }
        }
    }
}

pipelineJob('AMLSUITE/tcr_regression_stage_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/tcr_regression_stage_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
            triggers {
                cron(everyMondaySchedule)
            }
        }
    }
}

pipelineJob('AMLSUITE/tcr_regression_dev_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/tcr_regression_dev_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
            triggers {
                cron(everyMondaySchedule)
            }
        }
    }
}

pipelineJob('AMLSUITE/kyc_regression_stage_ee_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/kyc_regression_stage_ee_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
            triggers {
                cron(everyMondaySchedule)
            }
        }
    }
}

pipelineJob('AMLSUITE/kyc_regression_dev_ee_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/kyc_regression_dev_ee_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
            triggers {
                cron(everyMondaySchedule)
            }
        }
    }
}

pipelineJob('AMLSUITE/kyc_regression_stage_lv_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/kyc_regression_stage_lv_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(everyMondaySchedule)
        }
    }
}

pipelineJob('AMLSUITE/kyc_regression_dev_lv_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/kyc_regression_dev_lv_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(everyMondaySchedule)
        }
    }
}

pipelineJob('AMLSUITE/kyc_smoke_stage_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/kyc_smoke_stage_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(dailySchedule)
        }
    }
}

pipelineJob('AMLSUITE/kyc_smoke_dev_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/kyc_smoke_dev_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(dailySchedule)
        }
    }
}

pipelineJob('AMLSUITE/acm_regression_dev_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/acm_regression_dev_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(everyMondaySchedule)
        }
    }
}

pipelineJob('AMLSUITE/acm_grouping_smoke_stage_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/acm_grouping_smoke_stage_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(dailySchedule)
        }
    }
}

pipelineJob('AMLSUITE/aml_regression_dev_chrome') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/amlsuite/aml_regression_dev_chrome.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(everyMondaySchedule)
        }
    }
}


