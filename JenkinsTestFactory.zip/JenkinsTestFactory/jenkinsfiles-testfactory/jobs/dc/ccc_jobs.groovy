def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def scheduleAllTestsDev = '0 5 * * 1-5'    //daily 8:00 AM
def scheduleAllTestsTest = '30 5 * * 1-5'    //daily 8:30 AM
def scheduleAllTestsStage = '59 5 * * 1-5'    //daily 8:59 AM
def scheduleSmoke = 'H 5-15 * * 1-5'       //hourly between 8 AM - 6 PM

pipelineJob('DC/rerun_failed_tests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/ccc/rerun_failed.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
    parameters {
        stringParam('rerunJob', 'DC/CCC_TST_allTests', 'Enter exact full job name to rerun failed tests for')
        stringParam('rerunBuild', 'lastCompletedBuild', 'Enter exact completed job build number or leave intact for the latest')
        stringParam('suiteName', 'regression', 'Enter exact suite name without xml extension')
        stringParam('envName', 'test', 'Enter environment name dev/test/stage')
        stringParam('envUrl', 'https://api.admin-ui.newpsd2.tst.lumsolutions.net/index.html#/ee/en/', 'Enter environment url for health check')
    }
}
pipelineJob('DC/CCC_DEV_smokeTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/ccc/CCC_DEV_smokeTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleSmoke)
                    }
                }
            }
        }
    }
}

pipelineJob('DC/CCC_TST_smokeTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/ccc/CCC_TST_smokeTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleSmoke)
                    }
                }
            }
        }
    }
}

pipelineJob('DC/CCC_STG_smokeTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/ccc/CCC_STG_smokeTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleSmoke)
                    }
                }
            }
        }
    }
}

pipelineJob('DC/CCC_DEV_allTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/ccc/CCC_DEV_allTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleAllTestsDev)
                    }
                }
            }
        }
    }
}

pipelineJob('DC/CCC_TST_allTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/ccc/CCC_TST_allTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleAllTestsTest)
                    }
                }
            }
        }
    }
}

pipelineJob('DC/CCC_STG_allTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/ccc/CCC_STG_allTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleAllTestsStage)
                    }
                }
            }
        }
    }
}

