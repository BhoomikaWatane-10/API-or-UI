def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'

pipelineJob('Drupal_sanity/sanity_parameterized_test') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/drupal/sanity/parameterized_tests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
    parameters {
        choiceParam('testName', ['checkWeb', 'checkCms', 'checkAuthService', 'checkDrupalProxy', 'checkMiddleware'], 'Choose test you want to run')
        choiceParam('envName', ['dev', 'test', 'stage'], 'Choose environment name dev/test/stage')
    }
}

pipelineJob('Drupal_sanity/TST_sanity_all') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/drupal/sanity/TST_sanityTests_all.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('Drupal_sanity/TST_sanity_web') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/drupal/sanity/TST_sanityTests_web.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('Drupal_sanity/TST_sanity_cms') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/drupal/sanity/TST_sanityTests_cms.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('Drupal_sanity/TST_sanity_authService') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/drupal/sanity/TST_sanityTests_authService.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('Drupal_sanity/TST_sanity_drupalProxy') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/drupal/sanity/TST_sanityTests_drupalProxy.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('Drupal_sanity/TST_sanity_middleware') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/drupal/sanity/TST_sanityTests_middleware.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}