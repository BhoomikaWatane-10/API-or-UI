//visit https://crontab.guru/ for time syntax
//jenkins server time zone GMT +0
def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def scheduleAllTests = '0 6 * * 1-5'    //daily at 8 AM
def scheduleServicesTests = '0 6 * * 1-5'    //daily at 8 AM
def scheduleSmoke = 'H 6-16 * * 1-5'       //hourly between 8 AM - 6 PM

pipelineJob('DC/PSD2_TST_allTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_TST_allTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleAllTests)
                    }
                }
            }
        }
    }
}
pipelineJob('DC/PSD2_STG_allTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_STG_allTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleAllTests)
                    }
                }
            }
        }
    }
}
pipelineJob('DC/PSD2_TST_servicesTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_TST_servicesTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleServicesTests)
                    }
                }
            }
        }
    }
}
pipelineJob('DC/PSD2_STG_servicesTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_STG_servicesTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleServicesTests)
                    }
                }
            }
        }
    }
}
pipelineJob('DC/PSD2_TST_smokeTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_TST_smokeTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleSmoke)
                    }
                }
            }
        }
    }
}
pipelineJob('DC/PSD2_STG_smokeTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_STG_smokeTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleSmoke)
                    }
                }
            }
        }
    }
}

pipelineJob('DC/PSD2_STG_RegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_STG_RegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleSmoke)
                    }
                }
            }
        }
    }
}

pipelineJob('DC/PSD2_TST_RegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_TST_RegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleSmoke)
                    }
                }
            }
        }
    }
}


pipelineJob('DC/PSD2_DEV_RegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_DEV_RegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                   // triggers {
                       // cron(scheduleSmoke)
                    //}
                }
            }
        }
    }
}

pipelineJob('DC/PSD2_DEVPortal_PROD_SmokeTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_DEVPortal_PROD_SmokeTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                 //   triggers {
                      //  cron(scheduleSmoke)
                   // }
                }
            }
        }
    }
}

pipelineJob('DC/PSD2_TST_PeriodicPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_TST_PeriodicPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    //triggers {
                        //cron(scheduleSmoke)
                   // }
                }
            }
        }
    }
}

pipelineJob('DC/PSD2_STG_PeriodicPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_STG_PeriodicPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                 //   triggers {
                      //  cron(scheduleSmoke)
                  //  }
                }
            }
        }
    }
}


pipelineJob('DC/PSD2_TST_BulkPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_TST_BulkPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    //triggers {
                    //cron(scheduleSmoke)
                    // }
                }
            }
        }
    }
}

pipelineJob('DC/PSD2_STG_BulkPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_STG_BulkPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    //   triggers {
                    //  cron(scheduleSmoke)
                    //  }
                }
            }
        }
    }
}
pipelineJob('DC/PSD2_STG_PeriodicPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_STG_PeriodicPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    //   triggers {
                    //  cron(scheduleSmoke)
                    //  }
                }
            }
        }
    }
}


pipelineJob('DC/PSD2_TST_BulkPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_TST_BulkPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    //triggers {
                    //cron(scheduleSmoke)
                    // }
                }
            }
        }
    }
}

pipelineJob('DC/PSD2_STG_BulkPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_STG_BulkPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    //   triggers {
                    //  cron(scheduleSmoke)
                    //  }
                }
            }
        }
    }
}

pipelineJob('DC/PSD2_TST_CrossBorderPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_TST_CrossBorderPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    //triggers {
                    //cron(scheduleSmoke)
                    // }
                }
            }
        }
    }
}

pipelineJob('DC/PSD2_STG_CrossBorderPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2/PSD2_STG_CrossBorderPaymentRegressionTests.groovy')
                    //jenkinsfiles/dc/psd2/PSD2_STG_CrossBorderPaymentRegressionTests.groovy
                    extensions {}
                }
            }
        }
    }
}








