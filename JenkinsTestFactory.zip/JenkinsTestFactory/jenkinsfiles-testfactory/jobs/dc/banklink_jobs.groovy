def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def schedule = 'H 6 * * 1-5' // every working day around 08 AM and 20 PM

pipelineJob('DC/Banklink_DEV_allTests') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/banklink/Banklink_DEV_allTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}

pipelineJob('DC/Banklink_TST_allTests') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/banklink/Banklink_TST_allTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}
pipelineJob('DC/Banklink_STG_allTests') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/banklink/Banklink_STG_allTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}