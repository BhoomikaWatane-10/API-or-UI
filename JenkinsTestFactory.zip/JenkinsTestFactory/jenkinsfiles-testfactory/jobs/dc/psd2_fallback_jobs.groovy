//visit https://crontab.guru/ for time syntax
//jenkins server time zone GMT +0
def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def scheduleAllTests = '30 22 * * 1-5'    //monday-friday at 0:30 AM

pipelineJob('DC/PSD2FallBack_STG_allTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2_fallback/PSD2_FallBack_STG_allTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleAllTests)
                    }
                }
            }
        }
    }
}
pipelineJob('DC/PSD2FallBack_TST_allTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/psd2_fallback/PSD2_FallBack_TST_allTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(scheduleAllTests)
                    }
                }
            }
        }
    }
}
