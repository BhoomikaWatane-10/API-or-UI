def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def schedule = 'H 6 * * *' // every day between 9-10 AM EET

pipelineJob('DP/DP_DEV_allTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/data_platform/tests_on_dev.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('DP/DP_TST_allTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/data_platform/tests_on_test.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}

pipelineJob('DP/DP_STG_allTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/data_platform/tests_on_stage.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}

pipelineJob('DP/DP_SIT_REL_1_0_allTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/data_platform/tests_on_sit_rel_1_0.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('DP/DP_DEV_notificationTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/data_platform/notifications_on_dev.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('DP/DP_SIT_notificationTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/data_platform/notifications_on_sit.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('DP/DP_TST_dailyTransactionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/data_platform/transaction_daily_check_on_test.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}

pipelineJob('DP/DP_STG_dailyTransactionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/data_platform/transaction_daily_check_on_stage.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}