def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'

pipelineJob('Banklink_sanity/TST_sanity_all') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/banklink/sanity/TST_sanityTests_all.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('Banklink_sanity/TST_sanity_admin_ui') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/banklink/sanity/TST_sanityTests_admin_ui.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('Banklink_sanity/TST_sanity_cust') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/banklink/sanity/TST_sanityTests_cust.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('Banklink_sanity/TST_sanity_int_admin') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/banklink/sanity/TST_sanityTests_int_admin.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('Banklink_sanity/TST_sanity_int_cust') {
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/banklink/sanity/TST_sanityTests_int_cust.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}