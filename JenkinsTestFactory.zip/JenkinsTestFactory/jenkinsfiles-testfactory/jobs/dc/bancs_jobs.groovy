def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def smokeSchedule = 'H(10-15) 6 * * 1-5'
def regressionSchedule = 'H(10-15) 0 * * 1-5'

pipelineJob('BaNCS/parameterized_tests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/parameterized_tests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
    parameters {
        stringParam('suiteName', 'smoke', 'Enter exact suite name without xml extension')
        stringParam('testName', 'StatementsTest', 'Enter ClassName for all tests in it or ClassName.methodName for specific test')
        stringParam('envName', 'stage', 'Enter environment name dev/test/stage')
        stringParam('envUrl', 'https://ee.stg.lumsolutions.net', 'Enter environment url for health check')
    }
}

pipelineJob('BaNCS/parameterized_suite') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/parameterized_suite.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
    parameters {
        stringParam('suiteName', 'smoke', 'Enter exact suite name without xml extension')
        stringParam('envName', 'stage', 'Enter environment name dev/test/stage')
        stringParam('envUrl', 'https://ee.stg.lumsolutions.net', 'Enter environment url for health check')
    }
}

pipelineJob('BaNCS/rerun_failed_tests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/rerun_failed.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
    parameters {
        stringParam('rerunJob', 'BaNCS/STG_smokeTests', 'Enter exact full job name to rerun failed tests for')
        stringParam('rerunBuild', 'lastCompletedBuild', 'Enter exact completed job build number or leave intact for the latest')
        stringParam('suiteName', 'smoke', 'Enter exact suite name without xml extension')
        stringParam('envName', 'stage', 'Enter environment name dev/test/stage')
        stringParam('envUrl', 'https://ee.stg.lumsolutions.net', 'Enter environment url for health check')
    }
}
pipelineJob('BaNCS/MIG2_smokeTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/smoke/MIG2_smokeTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(smokeSchedule)
        }
    }
    parameters {
        nodeParam('jenkinsbuilder') {
            defaultNodes(['master'])
        }
    }
}
pipelineJob('BaNCS_prod/PROD_smoke') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/smoke/PROD_smoke.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(smokeSchedule)
        }
    }
}
pipelineJob('BaNCS/TST_smokeTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/smoke/TST_smokeTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(smokeSchedule)
        }
    }
    parameters {
        nodeParam('jenkinsbuilder') {
            defaultNodes(['master'])
        }
    }
}
pipelineJob('BaNCS/STG_smokeTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/smoke/STG_smokeTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(smokeSchedule)
        }
    }
    parameters {
        nodeParam('jenkinsbuilder') {
            defaultNodes(['master'])
        }
    }
}
pipelineJob('BaNCS/TST_regressionTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/full_regression/TST_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(regressionSchedule)
        }
    }
    parameters {
        nodeParam('jenkinsbuilder') {
            defaultNodes(['master'])
        }
    }
}

pipelineJob('BaNCS/STG_regressionTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/full_regression/STG_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(regressionSchedule)
        }
    }
    parameters {
        nodeParam('jenkinsbuilder') {
            defaultNodes(['master'])
        }
    }
}
pipelineJob('BaNCS/tst/TST_regression_cards') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/tst/cards_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/stg/STG_regression_cards') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/stg/cards_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/tst/TST_regression_deposits') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/tst/deposits_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/stg/STG_regression_deposits') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/stg/deposits_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/tst/TST_regression_ecommerce') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/tst/ecommerce_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/stg/STG_regression_ecommerce') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/stg/ecommerce_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/tst/TST_regression_einvoices') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/tst/einvoices_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/stg/STG_regression_einvoices') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/stg/einvoices_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/tst/TST_regression_investments') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/tst/investments_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/stg/STG_regression_investments') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/stg/investments_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/tst/TST_regression_loans') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/tst/loans_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/stg/STG_regression_loans') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/stg/loans_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/tst/TST_regression_overview') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/tst/overview_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/stg/STG_regression_overview') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/stg/overview_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/tst/TST_regression_payments') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/tst/payments_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/stg/STG_regression_payments') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/stg/payments_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/tst/TST_regression_settings') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/tst/settings_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/stg/STG_regression_settings') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/areas/stg/settings_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('BaNCS/STG_prodSmoke') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' {
            'string' "*"
        }
    }
    authenticationToken("jenkins-remote-tests-trigger")
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc/bancs/smoke/STG_prodSmokeTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(smokeSchedule)
        }
    }
}

