def checkSchedule = 'H 4-16/2 * * 1-5' //once per every second  UTC, during 4.00-16.00, every Monday-Friday

pipelineJob('infra/ENV/dc_adminui_dev') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_adminui_dev_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/dc_adminui_stage') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_adminui_stage_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/dc_adminui_test') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_adminui_test_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/dc_bancs_dev') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_bancs_dev_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/dc_bancs_test') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_bancs_test_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/dc_bancs_stage') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_bancs_stage_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/dc_bancs_mig2') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_bancs_mig2_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}