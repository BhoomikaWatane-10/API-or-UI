def checkSchedule = 'H 3 * * *' //UTC - once every day at 7 EET

pipelineJob('infra/ENV/core_adams_stage') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_adams_stage_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/core_adams_test') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_adams_test_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/core_crm_ee_stage') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_crm_ee_stage.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron('H 7 * * *') //UTC - once every day at 7 hour
        }
    }
}
pipelineJob('infra/ENV/core_crm_ee_test') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_crm_ee_test.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron('H 7 * * *') //UTC - once every day at 7 hour
        }
    }
}
pipelineJob('infra/ENV/core_crm_lt_preprod') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_crm_lt_preprod.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron('H 7 * * *') //UTC - once every day at 7 hour
        }
    }
}
pipelineJob('infra/ENV/core_crm_lt_uat') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_crm_lt_uat.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron('H 7 * * *') //UTC - once every day at 7 hour
        }
    }
}
pipelineJob('infra/ENV/core_crm_lv_test') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_crm_lv_test.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron('H 7 * * *') //UTC - once every day at 7 hour
        }
    }
}
pipelineJob('infra/ENV/core_dp_api_dev') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_dp_api_dev_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/core_dp_ingress_dev') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_dp_ingress_dev_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/core_dp_eks_dev') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_dp_eks_dev_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/core_indigo_stage') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_indigo_stage_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/core_indigo_test') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_indigo_test_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/core_osiris_stage') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_osiris_stage_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/core_osiris_test') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/core_osiris_test_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
