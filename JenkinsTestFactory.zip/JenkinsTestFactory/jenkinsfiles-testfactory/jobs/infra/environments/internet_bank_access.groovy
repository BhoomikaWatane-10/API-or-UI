def checkSchedule = 'H 3 * * *' //UTC - once every day at 7 EET

pipelineJob('infra/ENV/ib_lt_stage') {
    disabled()  //TODO: no access to project env - temp disabling time trigger
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/ib_lt_stage_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/ib_lt_test') {
    disabled()  //TODO: no access to project env - temp disabling time trigger
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/ib_lt_test_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/ib_lv_stage') {
    disabled()  //TODO: no access to project env - temp disabling time trigger
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/ib_lv_stage_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/ib_lv_test') {
    disabled()  //TODO: no access to project env - temp disabling time trigger
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/ib_lv_test_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
