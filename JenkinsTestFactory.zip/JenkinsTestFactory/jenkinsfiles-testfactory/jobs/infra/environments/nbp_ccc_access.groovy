def checkSchedule = 'H/30 4-16 * * 1-5' //every 30min, during 4.00-16.00, every Monday-Friday UTC

pipelineJob('infra/ENV/CCC_DEV_health') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_ccc_dev_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/CCC_STG_health') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_ccc_stage_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/CCC_TST_health') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_ccc_test_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/CIAM_DEV_health') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_ciam_dev_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/CIAM_STAGE_health') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_ciam_stage_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/CIAM_TEST_health') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_ciam_test_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/dc_cm_dev') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_cm_dev_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/dc_cm_stage') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_cm_stage_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}
pipelineJob('infra/ENV/dc_cm_test') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/environments/dc_cm_test_check.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron(checkSchedule)
        }
    }
}