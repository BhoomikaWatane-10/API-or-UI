pipelineJob('infra/xsandbox/url_access_check') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/xsandbox/url_access_check.groovy')
                    extensions {}   // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
    parameters {
        stringParam('urlParam', null, 'Enter url to check access to')
    }
}
