pipelineJob('infra/xsandbox/zalenium_cleanup_videos') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/xsandbox/zalenium_cleanup_videos.groovy')
                    extensions {}   // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
        triggers {
            cron('@midnight')
        }
    }
}
