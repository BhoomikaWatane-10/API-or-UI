folder('redline-tests') {
    displayName('redline-tests')
    description('redline-tests')
}

pipelineJob('redline-tests/test') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/redline-tests/test.groovy')
                    extensions {}   // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
