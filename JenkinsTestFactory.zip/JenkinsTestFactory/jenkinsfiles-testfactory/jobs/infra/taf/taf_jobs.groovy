pipelineJob('infra/TAF/taf_build') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/taf/taf_build.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('infra/TAF/auth_person') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/taf/auth_person.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('infra/TAF/auth_corp') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/taf/auth_corp.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('infra/TAF/auth_corp_fail') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/taf/auth_corp_fail.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('infra/TAF/auth_person_fail') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/taf/auth_person_fail.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('infra/TAF/auth_person_acc_list') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/taf/auth_person_acc_list.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('infra/TAF/auth_person_acc_specific') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/infra/taf/auth_person_acc_specific.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}