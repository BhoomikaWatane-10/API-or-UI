def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def schedule = '0 5 * * 1-5' // every working day around 08 AM

pipelineJob('FMS/fms_tst_regressionTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/fms/regression/fms_tst_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}

pipelineJob('FMS/fms_dev_regressionTests') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/fms/regression/fms_dev_regressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}

