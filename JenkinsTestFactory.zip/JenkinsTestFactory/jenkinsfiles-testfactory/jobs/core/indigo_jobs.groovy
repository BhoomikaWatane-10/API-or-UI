pipelineJob('CORE/indigo_test_smoke') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/core/indigo_test_smoke.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
pipelineJob('CORE/indigo_stage_smoke') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/core/indigo_stage_smoke.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}
