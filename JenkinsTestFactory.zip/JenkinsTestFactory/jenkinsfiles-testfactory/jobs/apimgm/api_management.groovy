def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def schedule = 'H 6 * * 1-5' // every working day around 09 AM

pipelineJob('APIMGM/api_management_CM_component') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/apimgm/api_management_CM.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}

pipelineJob('APIMGM/api_management_CM_Loans_component') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/apimgm/api_management_CM_Loans.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}

pipelineJob('APIMGM/api_management_CM_Payments_component') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/apimgm/api_management_CM_Payments.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}

pipelineJob('APIMGM/api_management_CM_Deposit_component') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/apimgm/api_management_CM_Depoist.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                    triggers {
                        cron(schedule)
                    }
                }
            }
        }
    }
}
