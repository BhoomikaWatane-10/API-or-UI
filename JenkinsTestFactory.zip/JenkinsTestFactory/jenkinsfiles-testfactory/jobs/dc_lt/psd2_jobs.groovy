def repoUrl = 'https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git'
def scheduleSmoke = 'H 6-16 * * 1-5'

pipelineJob('DC_LT/PSD2_STG_smokeTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_STG_smokeTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_TST_smokeTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_TST_smokeTests.groovy')
                    extensions {}  // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_STG_RegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_STG_RegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                  //  triggers {
                    //    cron(scheduleSmoke)
                   // }
                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_TST_RegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_TST_RegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                //    triggers {
                 //       cron(scheduleSmoke)
                 //   }
                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_STG_PeriodicPaymentRegressionTest') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_STG_PeriodicPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                   // triggers {
                       // cron(scheduleSmoke)
                   // }
                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_TST_PeriodicPaymentRegressionTest') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_TST_PeriodicPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                   // triggers {
                     //   cron(scheduleSmoke)
                  //  }
                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_TST_InstantPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_TST_InstantPaymentRegressionTests.groovy')
                    extensions {}

                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_STG_InstantPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_STG_InstantPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want

                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_TST_BulkPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_TST_BulkPaymentRegressionTests.groovy')
                    extensions {}

                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_STG_BulkPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_STG_BulkPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want

                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_TST_CrossBorderPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_TST_CrossBorderPaymentRegressionTests.groovy')
                    extensions {}

                }
            }
        }
    }
}

pipelineJob('DC_LT/PSD2_STG_CrossBorderPaymentRegressionTests') {
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(repoUrl)
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/psd2/PSD2_STG_CrossBorderPaymentRegressionTests.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want

                }
            }
        }
    }
}
