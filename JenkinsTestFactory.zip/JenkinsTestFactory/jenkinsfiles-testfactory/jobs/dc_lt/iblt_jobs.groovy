pipelineJob('DC_LT/IB_LT_STAGE_full') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/iblt/IB_LT_STAGE_full.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}

pipelineJob('DC_LT/IB_LT_STAGE_smoke') {
    configure { project ->
        project / 'properties' / 'hudson.plugins.copyartifact.CopyArtifactPermissionProperty' / 'projectNameList' { 'string' "*" }
    }
    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url('https://svc_jenkins@git.onelum.host/lds/jenkinsfiles-testfactory.git')
                        credentials('gitlab-credentials')
                    }
                    branches('master')
                    scriptPath('jenkinsfiles/dc_lt/iblt/IB_LT_STAGE_smoke.groovy')
                    extensions {}
                    // required as otherwise it may try to tag the repo, which you may not want
                }
            }
        }
    }
}